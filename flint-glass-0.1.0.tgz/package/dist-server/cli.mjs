#!/usr/bin/env node
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// flint-mcp/src/core/init/componentIndexer.ts
var componentIndexer_exports = {};
__export(componentIndexer_exports, {
  indexComponents: () => indexComponents
});
import { parse } from "@babel/parser";
import _traverse from "@babel/traverse";
import * as t from "@babel/types";
import fs from "node:fs";
import path2 from "node:path";
function extractJsDocDescription(node) {
  const comments = node.leadingComments;
  if (!comments || comments.length === 0) return void 0;
  let jsDocComment;
  for (let i = comments.length - 1; i >= 0; i--) {
    const c = comments[i];
    if (c.type === "CommentBlock" && c.value.startsWith("*")) {
      jsDocComment = c;
      break;
    }
  }
  if (!jsDocComment) return void 0;
  const rawLines = jsDocComment.value.split("\n");
  const lines = rawLines.map((line) => {
    return line.replace(/^\s*\*\s?/, "").trimEnd();
  });
  const proseParts = [];
  for (const line of lines) {
    if (line.startsWith("@")) break;
    if (line === "" && proseParts.length > 0) break;
    if (line !== "") proseParts.push(line);
  }
  if (proseParts.length === 0) return void 0;
  let description = proseParts.join(" ");
  if (description.length > JSDOC_MAX_LENGTH) {
    description = description.slice(0, JSDOC_MAX_LENGTH) + "...";
  }
  return description;
}
async function indexComponents(projectRoot, srcDir) {
  const warnings = [];
  let scanRoot;
  if (srcDir) {
    scanRoot = path2.isAbsolute(srcDir) ? srcDir : path2.join(projectRoot, srcDir);
  } else {
    const defaultSrc = path2.join(projectRoot, "src");
    scanRoot = fs.existsSync(defaultSrc) ? defaultSrc : projectRoot;
  }
  const usesAtAlias = detectAtAlias(projectRoot);
  const files = [];
  collectFiles(scanRoot, files);
  const componentsMap = {};
  const filePaths = [];
  for (const filePath of files) {
    const relPath = path2.relative(projectRoot, filePath);
    filePaths.push(relPath);
    let source;
    try {
      source = fs.readFileSync(filePath, "utf-8");
    } catch {
      warnings.push(`Could not read ${relPath} \u2014 skipped.`);
      continue;
    }
    try {
      const found = extractComponents(source, filePath, projectRoot, usesAtAlias);
      for (const entry of found) {
        componentsMap[entry.name] = entry;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      warnings.push(`Parse error in ${relPath}: ${msg} \u2014 skipped.`);
    }
  }
  const count = Object.keys(componentsMap).length;
  return {
    count,
    components: componentsMap,
    filePaths,
    totalFiles: files.length,
    warnings
  };
}
function collectFiles(dir, results) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    const fullPath = path2.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!EXCLUDED_DIRS.has(entry.name)) {
        collectFiles(fullPath, results);
      }
      continue;
    }
    if (!entry.isFile()) continue;
    const name = entry.name;
    const isTsxOrJsx = name.endsWith(".tsx") || name.endsWith(".jsx");
    if (!isTsxOrJsx) continue;
    if (EXCLUDED_FILE_SUFFIXES.some((suffix) => name.endsWith(suffix))) continue;
    results.push(fullPath);
  }
}
function extractComponents(source, absoluteFilePath, projectRoot, usesAtAlias) {
  const ast = parse(source, {
    sourceType: "module",
    plugins: ["jsx", "typescript"],
    errorRecovery: true,
    attachComment: true
  });
  const typeMap = buildTypeMap(ast);
  const results = [];
  const relFilePath = path2.relative(projectRoot, absoluteFilePath);
  const pendingForwardRefs = /* @__PURE__ */ new Map();
  const constBindings = /* @__PURE__ */ new Map();
  traverse(ast, {
    // ── export default function ComponentName(...) ───────────────────────
    ExportDefaultDeclaration(nodePath) {
      const decl = nodePath.node.declaration;
      const description = extractJsDocDescription(nodePath.node);
      if (t.isFunctionDeclaration(decl) || t.isArrowFunctionExpression(decl)) {
        const name = t.isFunctionDeclaration(decl) && decl.id ? decl.id.name : null;
        if (name && isComponentName(name)) {
          const props = extractPropsFromFunction(decl, typeMap);
          results.push(
            makeEntry(name, relFilePath, props, projectRoot, usesAtAlias, description)
          );
        }
        return;
      }
      if (t.isIdentifier(decl)) {
        const name = decl.name;
        if (!isComponentName(name)) return;
        const pending = pendingForwardRefs.get(name);
        if (pending) {
          const resolvedDescription = description ?? pending.description;
          results.push(
            makeEntry(name, relFilePath, pending.props, projectRoot, usesAtAlias, resolvedDescription)
          );
          pendingForwardRefs.delete(name);
          return;
        }
        const binding = constBindings.get(name);
        if (binding && binding.isComponent) {
          const resolvedDescription = description ?? binding.description;
          results.push(
            makeEntry(name, relFilePath, binding.props, projectRoot, usesAtAlias, resolvedDescription)
          );
        }
      }
    },
    // ── export function ComponentName(...) ───────────────────────────────
    // ── export const ComponentName = (...) ──────────────────────────────
    ExportNamedDeclaration(nodePath) {
      const decl = nodePath.node.declaration;
      if (!decl) return;
      const description = extractJsDocDescription(nodePath.node);
      if (t.isFunctionDeclaration(decl)) {
        const name = decl.id?.name;
        if (!name || !isComponentName(name)) return;
        const props = extractPropsFromFunction(decl, typeMap);
        results.push(makeEntry(name, relFilePath, props, projectRoot, usesAtAlias, description));
        return;
      }
      if (t.isVariableDeclaration(decl)) {
        for (const declarator of decl.declarations) {
          if (!t.isIdentifier(declarator.id)) continue;
          const name = declarator.id.name;
          if (!isComponentName(name)) continue;
          const fn = declarator.init;
          if (!fn) continue;
          if (t.isArrowFunctionExpression(fn) || t.isFunctionExpression(fn)) {
            const props = extractPropsFromFunction(fn, typeMap);
            results.push(
              makeEntry(name, relFilePath, props, projectRoot, usesAtAlias, description)
            );
          }
        }
      }
    },
    // ── const Foo = React.forwardRef(...) ────────────────────────────────
    // ── const Foo = (...) => <JSX> ──────────────────────────────────────
    VariableDeclaration(nodePath) {
      if (!t.isProgram(nodePath.parent)) return;
      const description = extractJsDocDescription(nodePath.node);
      for (const declarator of nodePath.node.declarations) {
        if (!t.isIdentifier(declarator.id)) continue;
        const name = declarator.id.name;
        if (!isComponentName(name)) continue;
        const init = declarator.init;
        if (!init) continue;
        if (isForwardRefCall(init)) {
          const inner = getForwardRefCallback(init);
          const props = inner ? extractPropsFromFunction(inner, typeMap) : [];
          pendingForwardRefs.set(name, { props, description });
          constBindings.set(name, { props, isComponent: true, description });
          continue;
        }
        if (t.isArrowFunctionExpression(init) || t.isFunctionExpression(init)) {
          const props = extractPropsFromFunction(init, typeMap);
          constBindings.set(name, { props, isComponent: true, description });
        }
      }
    }
  });
  return results;
}
function extractPropsFromFunction(fn, typeMap) {
  const firstParam = fn.params[0];
  if (!firstParam) return [];
  if (t.isObjectPattern(firstParam)) {
    return extractObjectPatternProps(firstParam, typeMap);
  }
  if (t.isIdentifier(firstParam)) {
    const annotation = firstParam.typeAnnotation;
    if (t.isTSTypeAnnotation(annotation)) {
      const typeName = resolveTypeName(annotation.typeAnnotation);
      if (typeName) {
        return typeMap.get(typeName) ?? [];
      }
    }
  }
  if (t.isAssignmentPattern(firstParam) && t.isObjectPattern(firstParam.left)) {
    return extractObjectPatternProps(firstParam.left, typeMap);
  }
  return [];
}
function extractObjectPatternProps(pattern, typeMap) {
  const props = [];
  const seen = /* @__PURE__ */ new Set();
  if (pattern.typeAnnotation && t.isTSTypeAnnotation(pattern.typeAnnotation)) {
    const typeName = resolveTypeName(pattern.typeAnnotation.typeAnnotation);
    if (typeName) {
      const resolved = typeMap.get(typeName) ?? [];
      for (const p of resolved) {
        props.push(p);
        seen.add(p.name);
      }
    }
  }
  for (const prop of pattern.properties) {
    if (t.isObjectProperty(prop) && t.isIdentifier(prop.key)) {
      if (!seen.has(prop.key.name)) {
        props.push({ name: prop.key.name, type: "unknown", required: false });
        seen.add(prop.key.name);
      }
    }
  }
  return props;
}
function resolveTypeName(typeNode) {
  if (t.isTSTypeReference(typeNode)) {
    const typeName = typeNode.typeName;
    if (t.isIdentifier(typeName)) return typeName.name;
  }
  return null;
}
function extractPropType(member) {
  if (!member.typeAnnotation || !t.isTSTypeAnnotation(member.typeAnnotation)) return "unknown";
  const tsType = member.typeAnnotation.typeAnnotation;
  if (t.isTSStringKeyword(tsType)) return "string";
  if (t.isTSNumberKeyword(tsType)) return "number";
  if (t.isTSBooleanKeyword(tsType)) return "boolean";
  if (t.isTSAnyKeyword(tsType)) return "any";
  if (t.isTSVoidKeyword(tsType)) return "void";
  if (t.isTSNullKeyword(tsType)) return "null";
  if (t.isTSUndefinedKeyword(tsType)) return "undefined";
  if (t.isTSUnionType(tsType)) {
    const parts = tsType.types.map((u) => {
      if (t.isTSLiteralType(u)) {
        if (t.isStringLiteral(u.literal)) return `'${u.literal.value}'`;
        if (t.isNumericLiteral(u.literal)) return String(u.literal.value);
        if (t.isBooleanLiteral(u.literal)) return String(u.literal.value);
      }
      if (t.isTSStringKeyword(u)) return "string";
      if (t.isTSNumberKeyword(u)) return "number";
      if (t.isTSBooleanKeyword(u)) return "boolean";
      if (t.isTSNullKeyword(u)) return "null";
      if (t.isTSUndefinedKeyword(u)) return "undefined";
      if (t.isTSTypeReference(u) && t.isIdentifier(u.typeName)) return u.typeName.name;
      return "unknown";
    });
    return parts.join(" | ");
  }
  if (t.isTSTypeReference(tsType)) {
    if (t.isIdentifier(tsType.typeName)) return tsType.typeName.name;
    if (t.isTSQualifiedName(tsType.typeName)) {
      const left = t.isIdentifier(tsType.typeName.left) ? tsType.typeName.left.name : "";
      return `${left}.${tsType.typeName.right.name}`;
    }
  }
  if (t.isTSArrayType(tsType)) {
    if (t.isTSStringKeyword(tsType.elementType)) return "string[]";
    if (t.isTSNumberKeyword(tsType.elementType)) return "number[]";
    return "unknown[]";
  }
  if (t.isTSFunctionType(tsType)) return "(...args: any[]) => any";
  return "unknown";
}
function extractPropInfos(members) {
  return members.filter((m) => t.isTSPropertySignature(m) && t.isIdentifier(m.key)).map((m) => ({
    name: m.key.name,
    type: extractPropType(m),
    required: !m.optional
  }));
}
function buildTypeMap(ast) {
  const map = /* @__PURE__ */ new Map();
  for (const node of ast.program.body) {
    if (t.isTSInterfaceDeclaration(node)) {
      map.set(node.id.name, extractPropInfos(node.body.body));
      continue;
    }
    if (t.isTSTypeAliasDeclaration(node) && t.isTSTypeLiteral(node.typeAnnotation)) {
      map.set(node.id.name, extractPropInfos(node.typeAnnotation.members));
    }
    if (t.isExportNamedDeclaration(node) && node.declaration) {
      const inner = node.declaration;
      if (t.isTSInterfaceDeclaration(inner)) {
        map.set(inner.id.name, extractPropInfos(inner.body.body));
      } else if (t.isTSTypeAliasDeclaration(inner) && t.isTSTypeLiteral(inner.typeAnnotation)) {
        map.set(inner.id.name, extractPropInfos(inner.typeAnnotation.members));
      }
    }
  }
  return map;
}
function isForwardRefCall(node) {
  if (t.isCallExpression(node) && t.isMemberExpression(node.callee) && t.isIdentifier(node.callee.object, { name: "React" }) && t.isIdentifier(node.callee.property, { name: "forwardRef" })) {
    return true;
  }
  if (t.isCallExpression(node) && t.isIdentifier(node.callee, { name: "forwardRef" })) {
    return true;
  }
  return false;
}
function getForwardRefCallback(node) {
  if (!t.isCallExpression(node)) return null;
  const arg = node.arguments[0];
  if (!arg) return null;
  if (t.isFunctionExpression(arg) || t.isArrowFunctionExpression(arg)) {
    return arg;
  }
  return null;
}
function isComponentName(name) {
  return name.length > 0 && name[0] === name[0].toUpperCase() && name[0] !== "_";
}
function makeEntry(name, relFilePath, propInfos, projectRoot, usesAtAlias, description) {
  const importPath = buildImportPath(relFilePath, projectRoot, usesAtAlias);
  const props = {};
  for (const pi of propInfos) {
    props[pi.name] = { type: pi.type, required: pi.required };
  }
  const entry = {
    name,
    importPath,
    props
  };
  if (description !== void 0) {
    entry.description = description;
  }
  return entry;
}
function buildImportPath(relFilePath, _projectRoot, usesAtAlias) {
  const withoutExt = relFilePath.replace(/\.(tsx|jsx|ts|js)$/, "");
  if (usesAtAlias && (withoutExt.startsWith("src/") || withoutExt.startsWith("src\\"))) {
    return "@/" + withoutExt.slice("src/".length);
  }
  return "./" + withoutExt;
}
function detectAtAlias(projectRoot) {
  const tsconfigPath = path2.join(projectRoot, "tsconfig.json");
  if (!fs.existsSync(tsconfigPath)) return false;
  try {
    const raw = fs.readFileSync(tsconfigPath, "utf-8");
    const cfg = JSON.parse(raw);
    const paths = cfg.compilerOptions?.paths;
    if (!paths) return false;
    return "@/*" in paths;
  } catch {
    return false;
  }
}
var traverse, JSDOC_MAX_LENGTH, EXCLUDED_DIRS, EXCLUDED_FILE_SUFFIXES;
var init_componentIndexer = __esm({
  "flint-mcp/src/core/init/componentIndexer.ts"() {
    "use strict";
    traverse = typeof _traverse === "function" ? _traverse : _traverse.default;
    JSDOC_MAX_LENGTH = 500;
    EXCLUDED_DIRS = /* @__PURE__ */ new Set([
      "node_modules",
      "dist",
      "build",
      ".next",
      "out",
      "__tests__",
      ".git"
    ]);
    EXCLUDED_FILE_SUFFIXES = [
      ".test.tsx",
      ".test.jsx",
      ".test.ts",
      ".test.js",
      ".spec.tsx",
      ".spec.jsx",
      ".spec.ts",
      ".spec.js",
      ".stories.tsx",
      ".stories.jsx",
      ".stories.ts",
      ".stories.js",
      ".d.ts"
    ];
  }
});

// server/mcpClient.ts
var mcpClient_exports = {};
__export(mcpClient_exports, {
  MCPClient: () => MCPClient
});
import { spawn } from "node:child_process";
import { existsSync as existsSync2 } from "node:fs";
import path3 from "node:path";
import { fileURLToPath } from "node:url";
import { createInterface } from "node:readline";
var __dirname, CALL_TIMEOUT_MS, SHUTDOWN_GRACE_MS, MAX_RETRIES, RETRY_BASE_MS, MCPClient;
var init_mcpClient = __esm({
  "server/mcpClient.ts"() {
    __dirname = path3.dirname(fileURLToPath(import.meta.url));
    CALL_TIMEOUT_MS = 3e4;
    SHUTDOWN_GRACE_MS = 5e3;
    MAX_RETRIES = 5;
    RETRY_BASE_MS = 1e3;
    MCPClient = class {
      proc = null;
      projectRoot = null;
      connected = false;
      nextId = 1;
      pendingCalls = /* @__PURE__ */ new Map();
      retryCount = 0;
      retryTimer = null;
      _stderrBuffer = "";
      /**
       * Resolves the path to flint-mcp/dist/server.js.
       * In the web server context, we're always in development mode —
       * the server directory is a sibling of flint-mcp/.
       */
      get serverEntry() {
        return path3.resolve(__dirname, "..", "flint-mcp", "dist", "server.js");
      }
      // ── Public API ─────────────────────────────────────────────────────────────
      async start(projectRoot) {
        if (this.proc !== null) {
          await this.stop();
        }
        this.projectRoot = projectRoot;
        this.retryCount = 0;
        this._spawn();
      }
      async stop() {
        if (this.retryTimer !== null) {
          clearTimeout(this.retryTimer);
          this.retryTimer = null;
        }
        if (!this.proc) return;
        const proc = this.proc;
        this.proc = null;
        this.connected = false;
        this._rejectAllPending(new Error("MCP client stopped"));
        await new Promise((resolve) => {
          const killTimer = setTimeout(() => {
            proc.kill("SIGKILL");
            resolve();
          }, SHUTDOWN_GRACE_MS);
          proc.once("exit", () => {
            clearTimeout(killTimer);
            resolve();
          });
          proc.kill("SIGTERM");
        });
      }
      async callTool(name, args) {
        this._assertConnected();
        const result = await this._rpc("tools/call", { name, arguments: args });
        return result;
      }
      async readResource(uri) {
        this._assertConnected();
        const result = await this._rpc("resources/read", { uri });
        return result;
      }
      status() {
        return {
          connected: this.connected,
          serverPid: this.proc?.pid ?? null
        };
      }
      reconnect() {
        if (this.retryTimer !== null) {
          clearTimeout(this.retryTimer);
          this.retryTimer = null;
        }
        this.retryCount = 0;
        if (this.projectRoot !== null) {
          void this.start(this.projectRoot);
        }
      }
      // ── Internal ──────────────────────────────────────────────────────────────
      _spawn() {
        if (this.projectRoot === null) return;
        const entry = this.serverEntry;
        if (!existsSync2(entry)) {
          console.warn(
            "[Flint] mcpClient: flint-mcp server not built at %s. Run `cd flint-mcp && npm run build` to enable governance tools.",
            entry
          );
          return;
        }
        this._stderrBuffer = "";
        const proc = spawn(process.execPath, [entry], {
          cwd: this.projectRoot,
          env: {
            ...process.env,
            FLINT_PROJECT_ROOT: this.projectRoot,
            NO_COLOR: "1"
          },
          stdio: ["pipe", "pipe", "pipe"]
        });
        this.proc = proc;
        this.connected = false;
        const rl = createInterface({ input: proc.stdout });
        rl.on("line", (line) => {
          const trimmed = line.trim();
          if (!trimmed) return;
          try {
            const msg = JSON.parse(trimmed);
            this._handleResponse(msg);
          } catch {
          }
        });
        proc.stderr?.on("data", (chunk) => {
          const text = chunk.toString();
          this._stderrBuffer += text;
          if (!this.connected && this._stderrBuffer.includes("Flint MCP Server listening")) {
            this.connected = true;
            this.retryCount = 0;
            if (this.retryTimer !== null) {
              clearTimeout(this.retryTimer);
              this.retryTimer = null;
            }
            console.log("[Flint] mcpClient: connected (pid=%d)", proc.pid);
          }
          process.stderr.write("[flint-mcp] " + text);
        });
        proc.once("error", (err) => {
          console.error("[Flint] mcpClient: spawn error", err);
          this._handleCrash();
        });
        proc.once("exit", (code, signal) => {
          if (this.proc !== proc) return;
          console.warn("[Flint] mcpClient: server exited (code=%s signal=%s)", code, signal);
          this._handleCrash();
        });
        this._sendHandshake();
      }
      _sendHandshake() {
        const handshakeId = this.nextId++;
        const req = {
          jsonrpc: "2.0",
          id: handshakeId,
          method: "initialize",
          params: {
            protocolVersion: "2024-11-05",
            capabilities: {},
            clientInfo: { name: "flint-glass-web", version: "1.0.0" }
          }
        };
        const timer = setTimeout(() => {
          const entry = this.pendingCalls.get(handshakeId);
          if (entry) {
            this.pendingCalls.delete(handshakeId);
            entry.reject(new Error("handshake timeout"));
          }
          console.error("[Flint] mcpClient: initialize handshake timed out \u2014 triggering retry");
          this._handleCrash();
        }, 15e3);
        this.pendingCalls.set(handshakeId, {
          resolve: () => {
            this._sendInitializedNotification();
            if (!this.connected) {
              this.connected = true;
              this.retryCount = 0;
              if (this.retryTimer !== null) {
                clearTimeout(this.retryTimer);
                this.retryTimer = null;
              }
              console.log("[Flint] mcpClient: connected via handshake (pid=%d)", this.proc?.pid);
            }
          },
          reject: (err) => {
            console.error("[Flint] mcpClient: handshake failed \u2014", err.message);
          },
          timer
        });
        this._send(req);
      }
      _sendInitializedNotification() {
        if (!this.proc?.stdin?.writable) return;
        const notification = { jsonrpc: "2.0", method: "notifications/initialized" };
        this.proc.stdin.write(JSON.stringify(notification) + "\n");
      }
      _handleResponse(msg) {
        const pending = this.pendingCalls.get(msg.id);
        if (!pending) return;
        clearTimeout(pending.timer);
        this.pendingCalls.delete(msg.id);
        if (msg.error) {
          pending.reject(new Error(`MCP RPC error ${msg.error.code}: ${msg.error.message}`));
        } else {
          pending.resolve(msg.result);
        }
      }
      _handleCrash() {
        this.connected = false;
        if (this.proc) {
          try {
            this.proc.kill("SIGTERM");
          } catch {
          }
          this.proc = null;
        }
        this._rejectAllPending(new Error("MCP server process exited unexpectedly"));
        if (this.retryCount >= MAX_RETRIES) {
          console.error("[Flint] mcpClient: giving up after %d attempts", this.retryCount);
          return;
        }
        const delay = Math.min(RETRY_BASE_MS * 2 ** this.retryCount, 3e4);
        this.retryCount++;
        console.warn("[Flint] mcpClient: scheduling restart in %d ms (attempt %d/%d)\u2026", delay, this.retryCount, MAX_RETRIES);
        this.retryTimer = setTimeout(() => {
          this.retryTimer = null;
          if (this.projectRoot !== null) {
            this._spawn();
          }
        }, delay);
      }
      _rpc(method, params) {
        const id = this.nextId++;
        const req = { jsonrpc: "2.0", id, method, params };
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            this.pendingCalls.delete(id);
            reject(new Error(`MCP call '${method}' timed out after ${CALL_TIMEOUT_MS}ms`));
          }, CALL_TIMEOUT_MS);
          this.pendingCalls.set(id, { resolve, reject, timer });
          this._send(req);
        });
      }
      _send(req) {
        if (!this.proc?.stdin?.writable) {
          console.warn("[Flint] mcpClient: cannot send \u2014 stdin not writable");
          return;
        }
        const line = JSON.stringify(req) + "\n";
        this.proc.stdin.write(line);
      }
      _assertConnected() {
        if (!this.connected) {
          throw new Error(
            "MCP server is not connected. Ensure flint-mcp is built (cd flint-mcp && npm run build)."
          );
        }
      }
      _rejectAllPending(reason) {
        for (const [id, pending] of this.pendingCalls) {
          clearTimeout(pending.timer);
          pending.reject(reason);
          this.pendingCalls.delete(id);
        }
      }
    };
  }
});

// server/services/ingestionServer.ts
var ingestionServer_exports = {};
__export(ingestionServer_exports, {
  createIngestionServer: () => createIngestionServer
});
import http from "node:http";
import { existsSync as existsSync3, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path4 from "node:path";
function setCorsHeaders(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", `Content-Type, ${SECRET_HEADER}`);
  res.setHeader("Access-Control-Max-Age", "86400");
}
function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(payload)
  });
  res.end(payload);
}
function readBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    let rawBody = "";
    req.on("data", (chunk) => {
      rawBody += chunk.toString("utf8");
      if (rawBody.length > maxBytes) {
        req.destroy();
        reject(new Error("Payload too large"));
      }
    });
    req.on("end", () => resolve(rawBody));
    req.on("error", (err) => reject(err));
  });
}
function createIngestionServer() {
  let server = null;
  let activePort = DEFAULT_PORT;
  let projectRoot = "";
  let secret = "";
  let lastWebhookAt = null;
  let tokenCount = 0;
  const ingestCallbacks = [];
  const errorCallbacks = [];
  function emitIngest(data) {
    for (const cb of ingestCallbacks) {
      try {
        cb(data);
      } catch {
      }
    }
  }
  function emitError(data) {
    for (const cb of errorCallbacks) {
      try {
        cb(data);
      } catch {
      }
    }
  }
  function ensureTokensDir() {
    const tokensDir = path4.join(projectRoot, ".flint", "tokens");
    if (!existsSync3(tokensDir)) {
      mkdirSync(tokensDir, { recursive: true });
    }
    return tokensDir;
  }
  function countStoredTokens() {
    try {
      const tokensFile = path4.join(projectRoot, ".flint", "design-tokens.json");
      if (existsSync3(tokensFile)) {
        const raw = readFileSync(tokensFile, "utf8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.length;
        if (typeof parsed === "object" && parsed !== null) {
          const vars = parsed.variables;
          if (Array.isArray(vars)) return vars.length;
          return Object.keys(parsed).length;
        }
      }
    } catch {
    }
    return tokenCount;
  }
  function storeTokenPayload(payload) {
    const flintDir = path4.join(projectRoot, ".flint");
    if (!existsSync3(flintDir)) {
      mkdirSync(flintDir, { recursive: true });
    }
    const tokensDir = ensureTokensDir();
    const timestamp = Date.now();
    writeFileSync(
      path4.join(tokensDir, `ingest-${timestamp}.json`),
      JSON.stringify(payload, null, 2)
    );
    const tokensFile = path4.join(flintDir, "design-tokens.json");
    const payloadObj = payload;
    let count = 0;
    if (payloadObj.variables && typeof payloadObj.variables === "object") {
      count = Object.keys(payloadObj.variables).length;
    } else if (payloadObj.tokens && Array.isArray(payloadObj.tokens)) {
      count = payloadObj.tokens.length;
    } else if (Array.isArray(payload)) {
      count = payload.length;
    }
    writeFileSync(tokensFile, JSON.stringify(payload, null, 2));
    return count;
  }
  function storeAstPayload(payload) {
    const flintDir = path4.join(projectRoot, ".flint");
    if (!existsSync3(flintDir)) {
      mkdirSync(flintDir, { recursive: true });
    }
    writeFileSync(path4.join(flintDir, "last-ingest-ast.json"), payload);
  }
  async function handleRequest(req, res) {
    setCorsHeaders(res);
    if (req.method === "OPTIONS") {
      res.writeHead(200);
      res.end();
      return;
    }
    if (req.method === "GET" && req.url === "/health") {
      sendJson(res, 200, { ok: true });
      return;
    }
    const headerSecret = req.headers[SECRET_HEADER];
    if (!headerSecret || headerSecret !== secret) {
      const reason = `Unauthorized: missing or invalid ${SECRET_HEADER}`;
      sendJson(res, 401, { error: reason });
      emitError({ statusCode: 401, reason, timestamp: Date.now() });
      return;
    }
    if (req.method === "POST" && req.url === "/ingest") {
      try {
        const rawBody = await readBody(req, MAX_BODY_BYTES);
        const payload = JSON.parse(rawBody);
        const count = storeTokenPayload(payload);
        if (count === 0) {
          const reason = "No tokens extracted from payload. Stored raw data for MCP normalization.";
          sendJson(res, 200, { success: true, count: 0, warning: reason });
        } else {
          tokenCount = count;
          lastWebhookAt = Date.now();
          emitIngest({ tokenCount: count, timestamp: lastWebhookAt });
          console.log(`${LOG_PREFIX2} /ingest: stored ${count} tokens`);
          sendJson(res, 200, { success: true, count });
        }
      } catch (err) {
        const reason = err instanceof Error && err.message === "Payload too large" ? "Payload exceeds 10 MB limit" : "Invalid JSON payload";
        sendJson(res, 400, { error: reason });
        emitError({ statusCode: 400, reason, timestamp: Date.now() });
      }
      return;
    }
    if (req.method === "POST" && req.url === "/ingest-ast") {
      try {
        const rawBody = await readBody(req, MAX_BODY_BYTES);
        JSON.parse(rawBody);
        let figmaPayload = rawBody;
        try {
          const parsed = JSON.parse(rawBody);
          if (parsed && parsed.type === "application/x-flint-figma-ast") {
            figmaPayload = typeof parsed.payload === "string" ? parsed.payload : JSON.stringify(parsed.payload);
          }
        } catch {
        }
        storeAstPayload(figmaPayload);
        console.log(`${LOG_PREFIX2} /ingest-ast: payload stored`);
        sendJson(res, 200, { success: true });
      } catch (err) {
        const reason = err instanceof Error && err.message === "Payload too large" ? "Payload exceeds 10 MB limit" : "Invalid JSON payload";
        sendJson(res, 400, { error: reason });
        emitError({ statusCode: 400, reason, timestamp: Date.now() });
      }
      return;
    }
    sendJson(res, 404, { error: `Route not found: ${req.method} ${req.url}` });
  }
  function tryListen(port, resolve, reject) {
    if (port > DEFAULT_PORT + MAX_PORT_ATTEMPTS) {
      reject(new Error(
        `Could not bind to any port in range ${DEFAULT_PORT}-${DEFAULT_PORT + MAX_PORT_ATTEMPTS}`
      ));
      return;
    }
    const attempt = http.createServer((req, res) => {
      handleRequest(req, res).catch((err) => {
        console.error(`${LOG_PREFIX2} Unhandled request error:`, err);
        if (!res.headersSent) {
          sendJson(res, 500, { error: "Internal server error" });
        }
      });
    });
    attempt.listen(port, "127.0.0.1", () => {
      server = attempt;
      activePort = port;
      console.log(`${LOG_PREFIX2} Ingestion server listening on http://127.0.0.1:${port}`);
      resolve({ port });
    });
    attempt.on("error", (err) => {
      attempt.close();
      if (err.code === "EADDRINUSE") {
        console.warn(`${LOG_PREFIX2} Port ${port} in use, trying ${port + 1}...`);
        tryListen(port + 1, resolve, reject);
      } else {
        reject(err);
      }
    });
  }
  return {
    start(root, options) {
      if (server) {
        return Promise.reject(new Error("Ingestion server is already running"));
      }
      if (!options.secret || options.secret.length < 16) {
        return Promise.reject(new Error("Secret must be at least 16 characters"));
      }
      projectRoot = root;
      secret = options.secret;
      const startPort = options.port ?? DEFAULT_PORT;
      return new Promise((resolve, reject) => {
        tryListen(startPort, resolve, reject);
      });
    },
    stop() {
      return new Promise((resolve) => {
        if (!server) {
          resolve();
          return;
        }
        const srv = server;
        server = null;
        secret = "";
        srv.close(() => {
          console.log(`${LOG_PREFIX2} Ingestion server stopped.`);
          resolve();
        });
      });
    },
    status() {
      return {
        running: server !== null && server.listening,
        port: activePort,
        lastWebhookAt,
        tokenCount: server !== null ? countStoredTokens() : tokenCount
      };
    },
    onIngest(callback) {
      ingestCallbacks.push(callback);
    },
    onError(callback) {
      errorCallbacks.push(callback);
    }
  };
}
var LOG_PREFIX2, SECRET_HEADER, DEFAULT_PORT, MAX_PORT_ATTEMPTS, MAX_BODY_BYTES;
var init_ingestionServer = __esm({
  "server/services/ingestionServer.ts"() {
    LOG_PREFIX2 = "[Flint]";
    SECRET_HEADER = "x-flint-secret";
    DEFAULT_PORT = 4545;
    MAX_PORT_ATTEMPTS = 10;
    MAX_BODY_BYTES = 10 * 1024 * 1024;
  }
});

// server/services/aiChat.ts
var aiChat_exports = {};
__export(aiChat_exports, {
  createAIChatService: () => createAIChatService
});
import Anthropic from "@anthropic-ai/sdk";
import { readFileSync as readFileSync2, existsSync as existsSync4 } from "node:fs";
function readConfigFile(configPath) {
  try {
    if (existsSync4(configPath)) {
      const raw = readFileSync2(configPath, "utf-8");
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn(`${LOG_PREFIX3} Could not read config at ${configPath}:`, err);
  }
  return {};
}
function resolveApiKey(config) {
  return config.apiKey || process.env.ANTHROPIC_API_KEY;
}
function convertMessages(raw) {
  const messages = [];
  for (const item of raw) {
    const m = item;
    if (!m || !m.role) continue;
    if (m.role === "user" || m.role === "assistant") {
      const content = m.content ?? "";
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.role === m.role) {
        if (typeof lastMsg.content === "string") {
          lastMsg.content = [
            { type: "text", text: lastMsg.content },
            { type: "text", text: content }
          ];
        } else if (Array.isArray(lastMsg.content)) {
          ;
          lastMsg.content.push({ type: "text", text: content });
        }
      } else {
        messages.push({ role: m.role, content });
      }
    } else if (m.role === "tool_call") {
      const toolUseBlock = {
        type: "tool_use",
        id: m.toolUseId ?? `tool_${Date.now()}`,
        name: m.toolName ?? "unknown",
        input: m.toolInput ?? {}
      };
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.role === "assistant") {
        if (typeof lastMsg.content === "string") {
          lastMsg.content = [{ type: "text", text: lastMsg.content }];
        }
        ;
        lastMsg.content.push(toolUseBlock);
      } else {
        messages.push({ role: "assistant", content: [toolUseBlock] });
      }
    } else if (m.role === "tool_result") {
      const toolResultBlock = {
        type: "tool_result",
        tool_use_id: m.toolUseId ?? `tool_${Date.now()}`,
        content: m.content ?? ""
      };
      const lastMsg = messages[messages.length - 1];
      if (lastMsg && lastMsg.role === "user") {
        if (typeof lastMsg.content === "string") {
          lastMsg.content = [{ type: "text", text: lastMsg.content }];
        }
        ;
        lastMsg.content.push(toolResultBlock);
      } else {
        messages.push({ role: "user", content: [toolResultBlock] });
      }
    }
  }
  return messages;
}
function formatContextBlock(context) {
  if (!context || typeof context !== "object") return "";
  const ctx = context;
  const parts = [];
  if (ctx.activeFile && typeof ctx.activeFile === "string") {
    parts.push(`Active file: ${ctx.activeFile}`);
  }
  if (ctx.canvasMode && typeof ctx.canvasMode === "string") {
    parts.push(`Canvas mode: ${ctx.canvasMode}`);
  }
  if (Array.isArray(ctx.violations) && ctx.violations.length > 0) {
    parts.push(`Active violations: ${ctx.violations.length}`);
    const summaries = ctx.violations.slice(0, 5).map((v) => {
      const viol = v;
      return `  - [${viol.severity ?? "warn"}] ${viol.ruleId ?? "unknown"}: ${viol.message ?? ""}`;
    });
    parts.push(summaries.join("\n"));
  }
  if (Array.isArray(ctx.tokens) && ctx.tokens.length > 0) {
    parts.push(`Design tokens loaded: ${ctx.tokens.length}`);
  }
  if (ctx.healthScore !== void 0) {
    parts.push(`Design health score: ${ctx.healthScore}`);
  }
  if (parts.length === 0) return "";
  return `

---
Current Glass State:
${parts.join("\n")}
---`;
}
function createAIChatService(configPath) {
  async function chat(messages, context, onChunk) {
    const config = readConfigFile(configPath);
    const apiKey = resolveApiKey(config);
    if (!apiKey) {
      onChunk({
        type: "error",
        message: "No API key configured. Set ANTHROPIC_API_KEY or add apiKey to ~/.flint/config.json."
      });
      onChunk({ type: "done" });
      return;
    }
    const model = config.model ?? DEFAULT_MODEL;
    try {
      const client = new Anthropic({
        apiKey,
        ...config.baseURL ? { baseURL: config.baseURL } : {}
      });
      const contextBlock = formatContextBlock(context);
      const systemPrompt = SYSTEM_PROMPT + contextBlock;
      const anthropicMessages = convertMessages(Array.isArray(messages) ? messages : []);
      if (anthropicMessages.length === 0) {
        onChunk({ type: "error", message: "No valid messages provided." });
        onChunk({ type: "done" });
        return;
      }
      const stream = await client.messages.stream({
        model,
        max_tokens: MAX_TOKENS,
        system: systemPrompt,
        messages: anthropicMessages
      });
      for await (const event of stream) {
        if (event.type === "content_block_delta") {
          if (event.delta.type === "text_delta") {
            onChunk({ type: "text_delta", text: event.delta.text });
          }
        } else if (event.type === "content_block_start") {
          if (event.content_block.type === "tool_use") {
            onChunk({
              type: "tool_call",
              name: event.content_block.name,
              input: {}
            });
          }
        } else if (event.type === "message_stop") {
          const finalMsg = await stream.finalMessage();
          for (const block of finalMsg.content) {
            if (block.type === "tool_use") {
              onChunk({
                type: "tool_call",
                name: block.name,
                input: block.input
              });
            }
          }
        }
      }
      onChunk({ type: "done" });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error(`${LOG_PREFIX3} Chat error:`, errorMessage);
      if (errorMessage.includes("401") || errorMessage.includes("authentication")) {
        onChunk({ type: "error", message: "Invalid API key. Check your Anthropic API key." });
      } else if (errorMessage.includes("429") || errorMessage.includes("rate")) {
        onChunk({ type: "error", message: "Rate limited by Anthropic. Please wait a moment and try again." });
      } else if (errorMessage.includes("overloaded") || errorMessage.includes("529")) {
        onChunk({ type: "error", message: "Anthropic API is overloaded. Please try again shortly." });
      } else {
        onChunk({ type: "error", message: `AI request failed: ${errorMessage}` });
      }
      onChunk({ type: "done" });
    }
  }
  function getConfig() {
    const config = readConfigFile(configPath);
    const apiKey = resolveApiKey(config);
    return {
      hasKey: !!apiKey,
      provider: config.provider ?? "anthropic",
      model: config.model ?? DEFAULT_MODEL,
      baseURL: config.baseURL ?? null
    };
  }
  return {
    chat,
    getConfig
  };
}
var LOG_PREFIX3, DEFAULT_MODEL, MAX_TOKENS, SYSTEM_PROMPT;
var init_aiChat = __esm({
  "server/services/aiChat.ts"() {
    LOG_PREFIX3 = "[Flint AI]";
    DEFAULT_MODEL = "claude-sonnet-4-20250514";
    MAX_TOKENS = 4096;
    SYSTEM_PROMPT = `You are Flint, a design system governance assistant. You help users understand their design tokens, component registry, accessibility requirements, and governance rules.

You can answer questions about:
- Design tokens and their usage
- Component documentation and props
- Accessibility (WCAG 2.1 AA) best practices
- Governance rules and violation explanations
- Design system architecture

You do NOT perform code mutations directly. For code changes, users should use the MCP tools via their IDE (Claude Code, Cursor, VS Code).`;
  }
});

// server/services/ragStore.ts
var ragStore_exports = {};
__export(ragStore_exports, {
  createRAGService: () => createRAGService
});
import * as sqliteVec from "sqlite-vec";
import { readFile, readdir, lstat } from "node:fs/promises";
import path5 from "node:path";
function fnv1a(str) {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = hash * 16777619 >>> 0;
  }
  return hash;
}
function embedText(text) {
  const vec = new Float32Array(EMBED_DIM);
  const normalized = text.toLowerCase().trim();
  if (normalized.length === 0) {
    return vec;
  }
  for (let i = 0; i <= normalized.length - 3; i++) {
    const gram = normalized.substring(i, i + 3);
    const bucket = fnv1a(gram) % EMBED_DIM;
    vec[bucket] += 1;
  }
  for (let i = 0; i <= normalized.length - 4; i++) {
    const gram = normalized.substring(i, i + 4);
    const bucket = fnv1a("4:" + gram) % EMBED_DIM;
    vec[bucket] += 0.5;
  }
  const words = normalized.split(/\s+/).filter((w) => w.length > 2);
  for (const word of words) {
    const bucket = fnv1a("w:" + word) % EMBED_DIM;
    vec[bucket] += 2;
  }
  let magnitude = 0;
  for (let i = 0; i < EMBED_DIM; i++) {
    magnitude += vec[i] * vec[i];
  }
  magnitude = Math.sqrt(magnitude);
  if (magnitude > 0) {
    for (let i = 0; i < EMBED_DIM; i++) {
      vec[i] /= magnitude;
    }
  }
  return vec;
}
function formatComponentChunk(entry) {
  const lines = [];
  lines.push(`## Component: ${entry.name}`);
  lines.push("");
  if (entry.description) {
    lines.push(entry.description);
    lines.push("");
  }
  if (entry.importPath) {
    lines.push(`**Import:** \`import { ${entry.name} } from '${entry.importPath}'\``);
    lines.push("");
  }
  if (entry.props && Object.keys(entry.props).length > 0) {
    lines.push("**Props:**");
    lines.push("");
    lines.push("| Prop | Type | Required |");
    lines.push("|------|------|----------|");
    for (const [propName, def] of Object.entries(entry.props)) {
      const req = def.required ? "yes" : "no";
      const defVal = def.default ? ` (default: ${def.default})` : "";
      lines.push(`| ${propName} | ${def.type}${defVal} | ${req} |`);
    }
    lines.push("");
  }
  if (entry.variants && entry.variants.length > 0) {
    lines.push(`**Variants:** ${entry.variants.join(", ")}`);
    lines.push("");
  }
  if (entry.tokens && entry.tokens.length > 0) {
    lines.push(`**Design tokens:** ${entry.tokens.join(", ")}`);
    lines.push("");
  }
  if (entry.usageExample) {
    lines.push("**Usage example:**");
    lines.push("```tsx");
    lines.push(entry.usageExample);
    lines.push("```");
    lines.push("");
  }
  if (entry.compositionNotes) {
    lines.push(`**Composition notes:** ${entry.compositionNotes}`);
    lines.push("");
  }
  if (entry.a11yNotes) {
    lines.push(`**Accessibility notes:** ${entry.a11yNotes}`);
    lines.push("");
  }
  if (entry.relatedComponents && entry.relatedComponents.length > 0) {
    lines.push(`**Related components:** ${entry.relatedComponents.join(", ")}`);
    lines.push("");
  }
  return lines.join("\n").trim();
}
function createRAGService(db) {
  sqliteVec.load(db);
  console.log(`${BRAND.logPrefix} sqlite-vec extension loaded`);
  db.exec(`
    CREATE VIRTUAL TABLE IF NOT EXISTS vec_design_system USING vec0(
      chunk_id INTEGER PRIMARY KEY,
      embedding float[${EMBED_DIM}]
    )
  `);
  const columns = db.prepare("PRAGMA table_info(rag_chunks)").all();
  const hasEmbedding = columns.some((c) => c.name === "embedding");
  if (!hasEmbedding) {
    db.exec("ALTER TABLE rag_chunks ADD COLUMN embedding BLOB");
  }
  const insertChunkStmt = db.prepare(`
    INSERT INTO rag_chunks (content, source, chunk_type, embedding)
    VALUES (?, ?, ?, ?)
  `);
  const insertVecStmt = db.prepare(`
    INSERT INTO vec_design_system (chunk_id, embedding) VALUES (?, ?)
  `);
  const searchStmt = db.prepare(`
    SELECT
      v.chunk_id,
      v.distance,
      r.content,
      r.source,
      r.chunk_type
    FROM vec_design_system v
    JOIN rag_chunks r ON r.id = v.chunk_id
    WHERE v.embedding MATCH ? AND k = ?
    ORDER BY v.distance
  `);
  const deleteVecStmt = db.prepare("DELETE FROM vec_design_system WHERE chunk_id = ?");
  const deleteChunkStmt = db.prepare("DELETE FROM rag_chunks WHERE id = ?");
  const allChunkIdsStmt = db.prepare("SELECT id FROM rag_chunks");
  const countStmt = db.prepare("SELECT COUNT(*) as cnt FROM rag_chunks");
  async function query(queryText, limit = 5) {
    const currentCount = countStmt.get().cnt;
    if (currentCount === 0) return [];
    const queryVec = embedText(queryText);
    const vecBuffer = Buffer.from(queryVec.buffer);
    try {
      const rows = searchStmt.all(vecBuffer, limit);
      return rows.map((r) => ({
        id: r.chunk_id,
        content: r.content,
        source: r.source,
        chunkType: r.chunk_type,
        distance: r.distance
      }));
    } catch (err) {
      console.error(`${BRAND.logPrefix} query failed:`, err);
      return [];
    }
  }
  async function ingest(chunks) {
    let ingested = 0;
    const tx = db.transaction(() => {
      for (const chunk of chunks) {
        const vector = embedText(chunk.content);
        const vecBuffer = Buffer.from(vector.buffer);
        const info = insertChunkStmt.run(
          chunk.content,
          chunk.source ?? "",
          chunk.chunkType ?? "documentation",
          vecBuffer
        );
        const chunkId = info.lastInsertRowid;
        insertVecStmt.run(chunkId, vecBuffer);
        ingested++;
      }
    });
    tx();
    return { ingested };
  }
  async function clear() {
    const ids = allChunkIdsStmt.all();
    const tx = db.transaction(() => {
      for (const { id } of ids) {
        deleteVecStmt.run(id);
        deleteChunkStmt.run(id);
      }
    });
    tx();
  }
  async function count() {
    const row = countStmt.get();
    return row.cnt;
  }
  async function seedFromProject(projectRoot) {
    const chunks = [];
    const sources = [];
    const manifestPath = path5.join(projectRoot, BRAND.manifestFile);
    try {
      const raw = await readFile(manifestPath, "utf-8");
      const manifest = JSON.parse(raw);
      const components = manifest.components ?? {};
      const entries = Object.values(components);
      if (entries.length > 0) {
        for (const entry of entries) {
          const content = formatComponentChunk(entry);
          if (content.length > 0) {
            chunks.push({
              content,
              source: "manifest",
              chunkType: "component"
            });
          }
        }
        sources.push("manifest");
      }
    } catch (err) {
      if (err.code === "ENOENT") {
        console.warn(`${BRAND.logPrefix} flint-manifest.json not found, skipping component chunks`);
      } else {
        console.warn(`${BRAND.logPrefix} Could not read flint-manifest.json:`, err);
      }
    }
    const tokensPath = path5.join(projectRoot, BRAND.configDir, "design-tokens.json");
    try {
      const raw = await readFile(tokensPath, "utf-8");
      const tokens = JSON.parse(raw);
      if (Array.isArray(tokens) && tokens.length > 0) {
        const groups = /* @__PURE__ */ new Map();
        for (const token of tokens) {
          if (typeof token.token_path === "string" && typeof token.token_type === "string" && typeof token.token_value === "string") {
            const group = groups.get(token.token_type) ?? [];
            group.push(token);
            groups.set(token.token_type, group);
          }
        }
        for (const [type, group] of groups) {
          const typeLabel = type.charAt(0).toUpperCase() + type.slice(1);
          const tokenList = group.map((t3) => `${t3.token_path} = ${t3.token_value}`).join("\n");
          const content = `Design Tokens \u2014 ${typeLabel}:
${tokenList}`;
          chunks.push({
            content,
            source: "tokens",
            chunkType: "tokens"
          });
        }
        if (groups.size > 0) {
          sources.push("tokens");
        }
      }
    } catch (err) {
      if (err.code === "ENOENT") {
        console.warn(`${BRAND.logPrefix} .flint/design-tokens.json not found, skipping token chunks`);
      } else {
        console.warn(`${BRAND.logPrefix} Could not read design-tokens.json:`, err);
      }
    }
    const docsDir = path5.join(projectRoot, BRAND.configDir, "docs");
    try {
      const dirEntries = await readdir(docsDir);
      const mdFiles = dirEntries.filter((f) => f.endsWith(".md"));
      for (const filename of mdFiles) {
        const filePath = path5.join(docsDir, filename);
        try {
          const stat = await lstat(filePath);
          if (stat.isSymbolicLink()) {
            console.warn(`${BRAND.logPrefix} Skipping symlink: docs/${filename}`);
            continue;
          }
          const content = (await readFile(filePath, "utf-8")).trim();
          if (content.length > 0) {
            chunks.push({
              content,
              source: `docs/${filename}`,
              chunkType: "documentation"
            });
            sources.push(`docs/${filename}`);
          }
        } catch (err) {
          console.warn(`${BRAND.logPrefix} Could not read docs/${filename}:`, err);
        }
      }
    } catch (err) {
      if (err.code === "ENOENT") {
      } else {
        console.warn(`${BRAND.logPrefix} Could not read .flint/docs/:`, err);
      }
    }
    if (chunks.length === 0) {
      return { ingested: 0, sources: [] };
    }
    await clear();
    const result = await ingest(chunks);
    console.log(`${BRAND.logPrefix} Seeded: ${result.ingested} chunks from [${sources.join(", ")}]`);
    return { ingested: result.ingested, sources };
  }
  return {
    query,
    ingest,
    clear,
    count,
    seedFromProject
  };
}
var EMBED_DIM, BRAND;
var init_ragStore = __esm({
  "server/services/ragStore.ts"() {
    EMBED_DIM = 384;
    BRAND = {
      logPrefix: "[Flint RAG]",
      configDir: ".flint",
      manifestFile: "flint-manifest.json"
    };
  }
});

// flint-mcp/src/core/errorTaxonomy.ts
function getErrorEntryByRuleId(ruleId) {
  for (const entry of Object.values(REGISTRY)) {
    if (entry.ruleId === ruleId) return entry;
  }
  return null;
}
var REGISTRY;
var init_errorTaxonomy = __esm({
  "flint-mcp/src/core/errorTaxonomy.ts"() {
    "use strict";
    REGISTRY = {
      // ── Mithril rules ──────────────────────────────────────────────────────────
      "FLINT-MITH-001": {
        code: "FLINT-MITH-001",
        ruleId: "MITHRIL-COL",
        category: "mithril",
        severity: "error",
        title: "Color Token Drift",
        explanation: "An arbitrary hex color value in a Tailwind class does not correspond to a registered design token. Design systems rely on a controlled color palette to maintain visual consistency across products and brands. Unregistered colors erode that consistency and make future rebrand or theming operations unreliable.",
        recovery: "Replace the arbitrary color class (e.g. `bg-[#e53e3e]`) with the nearest semantic token class (e.g. `bg-error-500`). Run `flint_sync_tokens` to ensure your token set is current. If no token fits, add the new color to your design token file and re-run `flint_fix`.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling); Flint Commandment 9 (CIEDE2000 Delta-E Logic)",
        regulatoryRef: "CIEDE2000 \u0394E > 2.0 threshold"
      },
      "FLINT-MITH-002": {
        code: "FLINT-MITH-002",
        ruleId: "MITHRIL-TYP-001",
        category: "mithril",
        severity: "warning",
        title: "Font Family Not in Token Set",
        explanation: "An arbitrary font-family value is applied directly in a Tailwind class rather than via a typography token. Font families are a core brand asset; hardcoding them bypasses the design system and creates divergence whenever the brand typeface changes.",
        recovery: "Replace the arbitrary `font-[...]` class with a token-backed utility class registered in your `fontFamily` tokens. If the typeface is intentional and new, add a `fontFamily` token entry and re-run the audit.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-003": {
        code: "FLINT-MITH-003",
        ruleId: "MITHRIL-TYP-002",
        category: "mithril",
        severity: "warning",
        title: "Font Size Not in Token Set",
        explanation: "An arbitrary font-size value (px/rem/em) is applied via a Tailwind bracket notation rather than a dimension token. Type scales defined in design tokens ensure visual rhythm and make system-wide size adjustments safe. Hardcoded sizes fragment the scale and make responsive or accessibility-driven resize operations error-prone.",
        recovery: "Replace the arbitrary `text-[...]` class with a token-backed text-size utility. If the size is valid for the scale, register it as a `dimension` token and re-run the audit.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-004": {
        code: "FLINT-MITH-004",
        ruleId: "MITHRIL-TYP-003",
        category: "mithril",
        severity: "warning",
        title: "Font Weight Not in Token Set",
        explanation: "An arbitrary font-weight value is applied via Tailwind bracket notation rather than a `fontWeight` token. Weight steps communicate hierarchy and emphasis; arbitrary weights introduce visual inconsistency across components that share typographic intent.",
        recovery: "Replace the arbitrary `font-[400]` style class with a token-backed weight utility. Register the weight as a `fontWeight` token if it belongs in the design system.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-005": {
        code: "FLINT-MITH-005",
        ruleId: "MITHRIL-TYP-004",
        category: "mithril",
        severity: "warning",
        title: "Line Height Not in Token Set",
        explanation: "An arbitrary line-height value is applied via Tailwind bracket notation rather than a `lineHeight` token. Consistent vertical rhythm depends on controlled line-height steps. Arbitrary values break paragraph density and make cross-component reading flow unpredictable.",
        recovery: "Replace the arbitrary `leading-[...]` class with a token-backed line-height utility. Add the value as a `lineHeight` token if it is an intentional design system addition.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-006": {
        code: "FLINT-MITH-006",
        ruleId: "MITHRIL-TYP-005",
        category: "mithril",
        severity: "warning",
        title: "Letter Spacing Not in Token Set",
        explanation: "An arbitrary letter-spacing value is applied via Tailwind bracket notation rather than a `letterSpacing` token. Letter-spacing affects legibility and brand feel. Arbitrary values outside the token set create micro-inconsistencies that accumulate into visible brand drift.",
        recovery: "Replace the arbitrary `tracking-[...]` class with a token-backed tracking utility. Register the value as a `letterSpacing` token if it is part of the design system specification.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-007": {
        code: "FLINT-MITH-007",
        ruleId: "MITHRIL-SPC-001",
        category: "mithril",
        severity: "warning",
        title: "Spacing Value Not in Token Set",
        explanation: "An arbitrary spacing value (padding, margin, gap, width, height) is applied via Tailwind bracket notation rather than a registered `dimension` token. Spacing tokens define the grid and layout rhythm of the design system; arbitrary values break alignment and make components impossible to maintain across breakpoints.",
        recovery: "Replace the arbitrary spacing class (e.g. `p-[18px]`) with a token-backed spacing utility. If the value is a legitimate design system spacing step, add it as a `dimension` token.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-008": {
        code: "FLINT-MITH-008",
        ruleId: "MITHRIL-SHD-001",
        category: "mithril",
        severity: "warning",
        title: "Shadow Not in Token Set",
        explanation: "An arbitrary box-shadow value is applied via Tailwind bracket notation rather than a registered `shadow` token. Shadow definitions control depth hierarchy and material language across the UI. Hardcoded shadows break the elevation system and make UI reskinning brittle.",
        recovery: "Replace the arbitrary `shadow-[...]` class with a token-backed shadow utility. Register the shadow definition as a `shadow` token if it is an intentional design system elevation step.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-009": {
        code: "FLINT-MITH-009",
        ruleId: "MITHRIL-OPC-001",
        category: "mithril",
        severity: "warning",
        title: "Opacity Not in Token Set",
        explanation: "An arbitrary opacity value is applied via Tailwind bracket notation rather than a registered `opacity` token. Opacity tokens define the transparency vocabulary of the design system (disabled states, overlays, ghost elements). Arbitrary values create inconsistent transparency behavior across components.",
        recovery: "Replace the arbitrary `opacity-[...]` class with a token-backed opacity utility. Register the value as an `opacity` token if it is a legitimate transparency step.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      // ── Mithril Inline Style rules (MITHRIL-IST-*) ────────────────────────────
      // These mirror the className visitors but fire on `style={{ ... }}` object props.
      "FLINT-MITH-010": {
        code: "FLINT-MITH-010",
        ruleId: "MITHRIL-IST-COL",
        category: "mithril",
        severity: "error",
        title: "Inline Style Color Not in Token Set",
        explanation: "A hardcoded hex or rgb() color value appears in a `style={{}}` prop rather than referencing a design token. Inline style colors bypass the design system entirely: they are invisible to theme switching, brand audits, and rebranding operations. CIEDE2000 perceptual distance confirms the color is not equivalent to any registered token.",
        recovery: "Replace the hardcoded color value with a CSS variable or token reference (e.g. `color: tokens.colorOnSurface` or `color: var(--color-on-surface)`). If the color is intentional and new, add it as a `color` design token first.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling); Flint Commandment 9 (CIEDE2000 Delta-E Logic)",
        regulatoryRef: "CIEDE2000 \u0394E > 2.0 threshold"
      },
      "FLINT-MITH-011": {
        code: "FLINT-MITH-011",
        ruleId: "MITHRIL-IST-TYP",
        category: "mithril",
        severity: "warning",
        title: "Inline Style Typography Value Not in Token Set",
        explanation: "A hardcoded typography value (fontSize, fontWeight, lineHeight, letterSpacing, or fontFamily) appears in a `style={{}}` prop rather than referencing a design token. Hardcoded type values fragment the type scale and prevent system-wide accessibility or brand adjustments from propagating to this element.",
        recovery: "Replace the hardcoded value with a token reference (e.g. `fontSize: tokens.typeSizeSm` or `fontWeight: tokens.typeWeightBold`). If the value is a legitimate type scale step, add it as a typography token and re-run the audit.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-012": {
        code: "FLINT-MITH-012",
        ruleId: "MITHRIL-IST-SPC",
        category: "mithril",
        severity: "warning",
        title: "Inline Style Spacing Value Not in Token Set",
        explanation: "A hardcoded spacing or dimension value (margin, padding, gap, width, height, borderRadius, etc.) appears in a `style={{}}` prop rather than referencing a dimension token. Spacing tokens define the layout grid and rhythm; arbitrary inline values break alignment and make components impossible to maintain across breakpoints or design system updates.",
        recovery: "Replace the hardcoded value with a token reference (e.g. `marginTop: tokens.spacingSm` or `padding: tokens.spacing4`). If the value belongs in the spacing scale, add it as a `dimension` token.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-013": {
        code: "FLINT-MITH-013",
        ruleId: "MITHRIL-IST-SHD",
        category: "mithril",
        severity: "warning",
        title: "Inline Style Shadow Not in Token Set",
        explanation: "A hardcoded `boxShadow` or `textShadow` value appears in a `style={{}}` prop rather than referencing a shadow token. Shadow definitions control the elevation language and material depth of the UI. Hardcoded shadows break the elevation system and prevent retheming.",
        recovery: "Replace the hardcoded shadow with a token reference (e.g. `boxShadow: tokens.shadowMd`). Register the shadow definition as a `shadow` token if it is an intentional elevation step.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      "FLINT-MITH-014": {
        code: "FLINT-MITH-014",
        ruleId: "MITHRIL-IST-OPC",
        category: "mithril",
        severity: "warning",
        title: "Inline Style Opacity Not in Token Set",
        explanation: "A hardcoded `opacity` value appears in a `style={{}}` prop rather than referencing an opacity token. Opacity tokens define the transparency vocabulary of the design system (disabled states, overlays, ghost elements). Arbitrary inline values create inconsistent transparency behaviour across components.",
        recovery: "Replace the hardcoded opacity with a token reference (e.g. `opacity: tokens.opacityDisabled`). Register the value as an `opacity` token if it is a legitimate transparency step.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      // ── Mithril Local Token Object rule (MITHRIL-DTO-001) ─────────────────────
      "FLINT-MITH-015": {
        code: "FLINT-MITH-015",
        ruleId: "MITHRIL-DTO-001",
        category: "mithril",
        severity: "warning",
        title: "Local Token Object Shadows Design System",
        explanation: "A module-scoped object literal contains hardcoded values that duplicate entries in the Flint token store. If the design system changes, this local copy will not update, causing silent drift. Flint's CIEDE2000 engine cannot track drift through local object indirection.",
        recovery: "Remove the local token object. Reference design tokens via CSS custom properties (var(--color-primary)) or use the project's Tailwind token classes.",
        sourceAuthority: "Flint Commandment 2 (No Hallucinated Styling)"
      },
      // ── A11y rules — Names & Labels ────────────────────────────────────────────
      "FLINT-A11Y-001": {
        code: "FLINT-A11Y-001",
        ruleId: "A11Y-001",
        category: "a11y",
        severity: "critical",
        title: "Image Missing Alt Text",
        explanation: "Screen readers announce the content of `alt` attributes to blind and low-vision users. An `<img>` without an `alt` attribute provides no information about the image, causing assistive technologies to read out the file path or skip the image entirely. This is a Level A requirement and blocks WCAG 2.1 AA conformance.",
        recovery: 'Add `alt=""` for purely decorative images (the screen reader will skip them). For informational images, write a concise description of the image content and purpose. Never use the filename as the alt text (see A11Y-011).',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.1.1 Non-text Content (Level A)"
      },
      "FLINT-A11Y-002": {
        code: "FLINT-A11Y-002",
        ruleId: "A11Y-002",
        category: "a11y",
        severity: "critical",
        title: "Button Missing Accessible Name",
        explanation: 'Buttons without an accessible name are announced as "button" by screen readers, giving users no information about the action they trigger. Icon-only buttons are the most common source of this violation. This prevents keyboard and AT users from operating interactive controls.',
        recovery: 'Add text content inside the button, or add `aria-label="[action description]"` for icon-only buttons. Alternatively, add `title="[action description]"` or `aria-labelledby="[id of label element]"`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-003": {
        code: "FLINT-A11Y-003",
        ruleId: "A11Y-003",
        category: "a11y",
        severity: "critical",
        title: "Link Missing Accessible Name",
        explanation: 'An `<a>` element without an accessible name is announced as "link" by screen readers, with no indication of where it leads. This is one of the most common accessibility failures in production applications and directly prevents screen reader users from understanding navigation structure.',
        recovery: 'Add descriptive text content inside the anchor, or add `aria-label="[destination description]"`. If the link contains only an icon, use `aria-label` to describe the destination, not the icon.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-004": {
        code: "FLINT-A11Y-004",
        ruleId: "A11Y-004",
        category: "a11y",
        severity: "critical",
        title: "Input Missing Label",
        explanation: "Form inputs without programmatic labels are inaccessible to screen reader users, who cannot determine what information to enter. Visual placeholder text is not a substitute \u2014 it disappears on focus and is not consistently announced by assistive technologies.",
        recovery: 'Associate a `<label htmlFor="[inputId]">` element, or add `aria-label="[field description]"`, or use `aria-labelledby="[id of visible label]"`. Placeholder text alone does not satisfy this requirement.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-005": {
        code: "FLINT-A11Y-005",
        ruleId: "A11Y-005",
        category: "a11y",
        severity: "critical",
        title: "Select Missing Label",
        explanation: "A `<select>` dropdown without an accessible label leaves screen reader users unable to identify the purpose of the control or the context of its options. This is a Level A failure with high impact on form usability for AT users.",
        recovery: 'Add `aria-label="[field name]"`, pair with a `<label htmlFor="[selectId]">`, or use `aria-labelledby="[id of visible label element]"`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-006": {
        code: "FLINT-A11Y-006",
        ruleId: "A11Y-006",
        category: "a11y",
        severity: "critical",
        title: "Textarea Missing Label",
        explanation: "A `<textarea>` without an accessible label prevents screen reader users from knowing what text to enter. Multi-line text inputs often contain critical information (comments, descriptions, notes) and the purpose must be programmatically determinable.",
        recovery: 'Add `aria-label="[field description]"`, pair with a `<label htmlFor="[textareaId]">`, or use `aria-labelledby="[id of visible label]"`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-007": {
        code: "FLINT-A11Y-007",
        ruleId: "A11Y-007",
        category: "a11y",
        severity: "critical",
        title: "Positive TabIndex Disrupts Tab Order",
        explanation: "A `tabIndex` greater than 0 forces keyboard focus to jump to that element before following the natural DOM order. This creates a confusing and unpredictable focus sequence for keyboard users and violates the principle that the visual and focus order should match.",
        recovery: "Use `tabIndex={0}` to include an element in the natural tab order, or `tabIndex={-1}` to remove it from the flow (but keep it programmatically focusable). Never use positive values. Restructure the DOM if the desired focus order differs from the visual order.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.4.3 Focus Order (Level A)"
      },
      "FLINT-A11Y-008": {
        code: "FLINT-A11Y-008",
        ruleId: "A11Y-008",
        category: "a11y",
        severity: "critical",
        title: "Table Missing Accessible Summary",
        explanation: "Data tables without an accessible summary or caption make it impossible for screen reader users to understand the purpose or structure of the table before navigating its contents. Complex tables especially require context about what data they contain and how it is organized.",
        recovery: 'Add a `<caption>` element as the first child of the table describing its content. Alternatively, use `aria-label="[table description]"` or `aria-labelledby="[id of a heading or description element]"`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-009": {
        code: "FLINT-A11Y-009",
        ruleId: "A11Y-009",
        category: "a11y",
        severity: "critical",
        title: "HTML Missing Lang Attribute",
        explanation: "Screen readers use the `lang` attribute on the `<html>` element to select the correct language voice and pronunciation rules. Without it, content may be read with the wrong accent, mispronounced, or rendered unintelligibly to users whose screen reader defaults to a different language.",
        recovery: 'Add `lang="en"` (or the appropriate BCP 47 language tag) to the root `<html>` element. For multilingual pages, also add `lang` attributes to sections that use different languages.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 3.1.1 Language of Page (Level A)"
      },
      "FLINT-A11Y-010": {
        code: "FLINT-A11Y-010",
        ruleId: "A11Y-010",
        category: "a11y",
        severity: "critical",
        title: "Heading Level Skipped",
        explanation: "Screen reader users navigate pages by jumping between headings. Skipping heading levels (e.g. going from `<h2>` to `<h4>`) breaks the document outline and confuses users who rely on heading hierarchy to understand content structure.",
        recovery: "Use headings in sequential order: `h1` \u2192 `h2` \u2192 `h3`, etc. Do not skip levels for visual styling \u2014 instead, use CSS or Tailwind classes to control the visual appearance while maintaining semantic hierarchy.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-011": {
        code: "FLINT-A11Y-011",
        ruleId: "A11Y-011",
        category: "a11y",
        severity: "critical",
        title: "Image Alt Is Filename",
        explanation: 'Using a filename as the `alt` text of an image (e.g. `alt="hero-image.png"`) provides no meaningful description of the image content. Screen readers will literally announce "hero-image dot png" to the user, which is meaningless and a poor accessibility experience.',
        recovery: 'Replace the filename alt with a concise, descriptive string that conveys the image\'s content and purpose. For decorative images with no informational value, use `alt=""` so screen readers skip them.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.1.1 Non-text Content (Level A)"
      },
      "FLINT-A11Y-012": {
        code: "FLINT-A11Y-012",
        ruleId: "A11Y-012",
        category: "a11y",
        severity: "critical",
        title: "SVG Missing Accessible Name",
        explanation: "SVG elements used as graphics or icons must have an accessible name so screen readers can describe them. Without one, screen readers may announce the raw SVG path data or silently skip the element, leaving users without context for what the graphic represents.",
        recovery: 'For decorative SVGs (purely visual): add `aria-hidden="true"`. For informational SVGs: add `aria-label="[description]"` or a `<title>` child element. Consider pairing with `role="img"` for maximum compatibility.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.1.1 Non-text Content (Level A)"
      },
      "FLINT-A11Y-013": {
        code: "FLINT-A11Y-013",
        ruleId: "A11Y-013",
        category: "a11y",
        severity: "critical",
        title: "Image Input Missing Alt",
        explanation: '`<input type="image">` elements function as submit buttons and must have an `alt` attribute describing the action they trigger. Without alt text, screen readers cannot announce what the button does, blocking form submission for AT users.',
        recovery: 'Add `alt="[action description]"` that describes what clicking the image input will do (e.g. `alt="Submit order"`). For decorative image inputs, use `alt=""`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.1.1 Non-text Content (Level A)"
      },
      "FLINT-A11Y-014": {
        code: "FLINT-A11Y-014",
        ruleId: "A11Y-014",
        category: "a11y",
        severity: "critical",
        title: "Generic Link Text",
        explanation: 'Link text such as "click here", "read more", or "learn more" does not describe the link destination. Screen reader users often navigate pages by reading a list of all links \u2014 generic text makes this list meaningless and forces users to read surrounding context for every link.',
        recovery: 'Replace generic text with descriptive text that makes sense out of context (e.g. "Read the accessibility guide"). If generic text must remain visible, add `aria-label="[descriptive text]"` to provide the accessible name.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.4.4 Link Purpose (In Context) (Level A)"
      },
      "FLINT-A11Y-015": {
        code: "FLINT-A11Y-015",
        ruleId: "A11Y-015",
        category: "a11y",
        severity: "critical",
        title: "List Contains Non-List-Item Children",
        explanation: "The `<ul>` and `<ol>` elements may only contain `<li>` children per the HTML spec. Non-list-item children break the list semantics that screen readers rely on to announce list size and navigate between items.",
        recovery: "Wrap any non-`<li>` direct children of `<ul>` or `<ol>` inside an `<li>` element. If the structure is a deliberate pattern (e.g. group headers), use ARIA role overrides or restructure to nested lists.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-016": {
        code: "FLINT-A11Y-016",
        ruleId: "A11Y-016",
        category: "a11y",
        severity: "critical",
        title: "Definition List Contains Invalid Children",
        explanation: "`<dl>` elements must only contain `<dt>` (term) and `<dd>` (description) children. Invalid children corrupt the definition list semantics that screen readers use to pair terms with their definitions.",
        recovery: "Ensure all direct children of `<dl>` are either `<dt>` or `<dd>` elements. You may group term/description pairs inside `<div>` wrappers for styling purposes.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-017": {
        code: "FLINT-A11Y-017",
        ruleId: "A11Y-017",
        category: "a11y",
        severity: "critical",
        title: "Page Must Have Exactly One H1",
        explanation: "The `<h1>` element defines the main topic of the page and is the first heading screen reader users encounter when navigating by heading. Multiple `<h1>` elements create an ambiguous document outline and confuse AT users about the primary purpose of the page.",
        recovery: "Ensure exactly one `<h1>` exists per page. Secondary section titles should use `<h2>` and below. If you have multiple visually prominent headings, only promote one to `<h1>` semantically.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.4.2 Page Titled (Level A)"
      },
      // ── A11y rules — Keyboard ──────────────────────────────────────────────────
      "FLINT-A11Y-020": {
        code: "FLINT-A11Y-020",
        ruleId: "A11Y-020",
        category: "a11y",
        severity: "critical",
        title: "Non-Interactive Element With Click Handler",
        explanation: "Non-interactive elements (`div`, `span`, etc.) with `onClick` handlers are invisible to keyboard users and assistive technologies unless they also have a semantic role, a tab stop, and a keyboard event handler. Users who cannot use a mouse have no way to activate such elements.",
        recovery: 'Add `role="button"` and `tabIndex={0}` to make the element keyboard-reachable. Add an `onKeyDown` handler that triggers the same action as `onClick` when Enter or Space is pressed. Better yet, replace the element with a native `<button>` which provides all of this by default.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.1.1 Keyboard (Level A)"
      },
      "FLINT-A11Y-021": {
        code: "FLINT-A11Y-021",
        ruleId: "A11Y-021",
        category: "a11y",
        severity: "critical",
        title: "Mouse-Only Event Handler",
        explanation: "Event handlers like `onMouseDown`, `onMouseUp`, and `onMouseOver` only fire for pointer device users. Keyboard users and switch access users who trigger the same functional states will receive no feedback, effectively locking them out of interactive behavior.",
        recovery: "Add keyboard equivalents: `onKeyDown` for `onMouseDown`, `onKeyUp` for `onMouseUp`, `onFocus` for `onMouseOver`. Consider using `onClick` (which fires on Enter/Space for keyboard) as the primary handler for activation actions.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.1.1 Keyboard (Level A)"
      },
      "FLINT-A11Y-022": {
        code: "FLINT-A11Y-022",
        ruleId: "A11Y-022",
        category: "a11y",
        severity: "critical",
        title: "Focus Indicator Removed",
        explanation: "Removing the focus ring via `outline-none` without providing a replacement focus style makes it impossible for keyboard users to determine which element currently has focus. This is one of the most common and highest-impact keyboard accessibility failures in modern Tailwind-based applications.",
        recovery: "Replace `outline-none` with a custom focus indicator using `focus:ring-*`, `focus-visible:ring-*`, or `focus:border-*` classes. The replacement must have a 3:1 contrast ratio with adjacent colors per WCAG 1.4.11.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 2.4.7 Focus Visible (Level AA)"
      },
      // ── A11y rules — Structure ─────────────────────────────────────────────────
      // (A11Y-008 through A11Y-010 and A11Y-015 through A11Y-017 registered above
      //  under their sequential rule numbers)
      // ── A11y rules — ARIA ──────────────────────────────────────────────────────
      "FLINT-A11Y-030": {
        code: "FLINT-A11Y-030",
        ruleId: "A11Y-030",
        category: "a11y",
        severity: "critical",
        title: "Invalid ARIA Role",
        explanation: "The `role` attribute must contain a valid WAI-ARIA 1.2 role name. Invalid roles are ignored by assistive technologies, which then fall back to the native element semantics \u2014 potentially stripping the intended accessible behavior entirely.",
        recovery: 'Check the WAI-ARIA 1.2 role taxonomy and use the correct role name. Common typos: "buttn" \u2192 "button", "dialogbox" \u2192 "dialog". If no standard role fits your pattern, consult the ARIA Authoring Practices Guide (APG).',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-031": {
        code: "FLINT-A11Y-031",
        ruleId: "A11Y-031",
        category: "a11y",
        severity: "critical",
        title: "Required ARIA Children Missing",
        explanation: 'Certain ARIA widget roles require specific child roles to function correctly. For example, `role="listbox"` requires `role="option"` children. Without the required children, assistive technologies cannot navigate or operate the widget.',
        recovery: "Add child elements with the required roles as specified in the WAI-ARIA spec. Check the ARIA Authoring Practices Guide for the correct widget pattern and required child structure.",
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-032": {
        code: "FLINT-A11Y-032",
        ruleId: "A11Y-032",
        category: "a11y",
        severity: "critical",
        title: "Element Outside Required ARIA Parent",
        explanation: 'Certain ARIA roles are only meaningful in specific parent contexts. For example, `role="tab"` must be inside `role="tablist"`. An element with a required-context role outside that context has its semantics undefined or ignored.',
        recovery: 'Wrap the element inside an ancestor with the required parent role. Restructure the component hierarchy to match the ARIA widget pattern. Refer to the WAI-ARIA spec "Required Context Role" for the specific rule.',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-033": {
        code: "FLINT-A11Y-033",
        ruleId: "A11Y-033",
        category: "a11y",
        severity: "critical",
        title: "Required ARIA Attribute Missing",
        explanation: 'Some ARIA roles have required state or property attributes that must be present for the widget to be announced correctly. For example, `role="checkbox"` requires `aria-checked`. Without the required attribute, the widget state is undefined to assistive technologies.',
        recovery: 'Add the required ARIA attribute with an appropriate initial value. Ensure the attribute is dynamically updated when widget state changes. Check the WAI-ARIA spec "Required States and Properties" for the specific role.',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-034": {
        code: "FLINT-A11Y-034",
        ruleId: "A11Y-034",
        category: "a11y",
        severity: "critical",
        title: "Invalid ARIA Attribute Name",
        explanation: "Only ARIA attributes defined in the WAI-ARIA 1.2 specification are valid. Misspelled or invented `aria-*` attributes are silently ignored by browsers and ATs, providing no accessible benefit while misleading developers into thinking accessibility is addressed.",
        recovery: 'Correct the attribute name typo. Common errors: "aria-lable" \u2192 "aria-label", "aria-labelby" \u2192 "aria-labelledby", "aria-describeby" \u2192 "aria-describedby". Flint auto-fix can remove invalid attributes; re-add the corrected version.',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-035": {
        code: "FLINT-A11Y-035",
        ruleId: "A11Y-035",
        category: "a11y",
        severity: "critical",
        title: "Invalid ARIA Attribute Value",
        explanation: 'ARIA state and property attributes have enumerated allowed values. For example, `aria-checked` must be "true", "false", or "mixed". Invalid values are treated as if the attribute were absent, removing the state announcement.',
        recovery: "Correct the attribute value to one of the allowed values specified in the WAI-ARIA spec. Ensure dynamic state updates also use valid values.",
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-036": {
        code: "FLINT-A11Y-036",
        ruleId: "A11Y-036",
        category: "a11y",
        severity: "critical",
        title: "Aria-Hidden On Focusable Element",
        explanation: '`aria-hidden="true"` hides an element from the accessibility tree but does not remove it from the keyboard tab order. A focusable element that is hidden from AT but reachable by keyboard creates a "focus trap" \u2014 keyboard users land on an element that the screen reader cannot describe.',
        recovery: 'Remove `aria-hidden="true"` from focusable elements, or add `tabIndex={-1}` to remove the element from the keyboard flow. If the element should be truly hidden, use CSS `display: none` or the `hidden` attribute.',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-037": {
        code: "FLINT-A11Y-037",
        ruleId: "A11Y-037",
        category: "a11y",
        severity: "critical",
        title: "Duplicate ARIA Attributes",
        explanation: "When the same ARIA attribute appears multiple times on an element, only the last value is used \u2014 but browser behavior is inconsistent. Duplicate attributes typically indicate a coding error where two code paths both set the same attribute without coordination.",
        recovery: "Remove the duplicate attribute declaration. Review the component's render logic to ensure a single, authoritative source sets each ARIA attribute.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      "FLINT-A11Y-038": {
        code: "FLINT-A11Y-038",
        ruleId: "A11Y-038",
        category: "a11y",
        severity: "critical",
        title: "Interactive Element With Presentation Role",
        explanation: '`role="presentation"` and `role="none"` strip all semantics from an element, including its interactive role. Applying these roles to `<button>`, `<input>`, `<a>`, or other interactive elements removes them from the accessibility tree, making them invisible and inoperable for AT users.',
        recovery: 'Remove `role="presentation"` or `role="none"` from interactive elements. These roles are intended only for layout elements that carry no semantic meaning.',
        sourceAuthority: "WCAG 2.1 AA; WAI-ARIA 1.2",
        regulatoryRef: "\xA7 4.1.2 Name, Role, Value (Level A)"
      },
      // ── A11y rules — Landmarks ─────────────────────────────────────────────────
      "FLINT-A11Y-050": {
        code: "FLINT-A11Y-050",
        ruleId: "A11Y-050",
        category: "a11y",
        severity: "critical",
        title: "Missing Main Landmark",
        explanation: "The `<main>` landmark identifies the primary content area of the page, allowing screen reader users to skip navigation and jump directly to the content they came for. Without it, users must tab through every navigation item and header element on every page load.",
        recovery: 'Wrap the primary page content in a `<main>` element or add `role="main"` to the container. There should be exactly one `<main>` per page.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-051": {
        code: "FLINT-A11Y-051",
        ruleId: "A11Y-051",
        category: "a11y",
        severity: "warning",
        title: "Missing Navigation Landmark",
        explanation: "The `<nav>` landmark identifies navigation regions, allowing screen reader users to jump directly to or skip over navigation. Pages with navigation menus but no `<nav>` landmark miss this structural shortcut.",
        recovery: 'Wrap navigation menus in a `<nav>` element or add `role="navigation"`. If multiple `<nav>` elements exist, distinguish them with `aria-label`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-052": {
        code: "FLINT-A11Y-052",
        ruleId: "A11Y-052",
        category: "a11y",
        severity: "critical",
        title: "Multiple Main Landmarks",
        explanation: "The `<main>` landmark must appear at most once per page. Multiple `<main>` elements create an ambiguous document structure \u2014 screen reader users land in unpredictable locations when navigating by landmarks.",
        recovery: 'Ensure only one `<main>` element (or `role="main"`) exists in the document. For SPAs, dynamically swap the `<main>` content rather than rendering multiple.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-053": {
        code: "FLINT-A11Y-053",
        ruleId: "A11Y-053",
        category: "a11y",
        severity: "critical",
        title: "Duplicate Landmark Without Distinct Label",
        explanation: 'When multiple landmarks of the same type exist (e.g. two `<nav>` elements), screen reader users navigating by landmarks cannot distinguish between them without distinct labels. The landmarks list becomes: "navigation, navigation" \u2014 meaningless.',
        recovery: 'Add a unique `aria-label` to each instance of the repeated landmark, describing its purpose. For example: `<nav aria-label="Primary navigation">` and `<nav aria-label="Footer navigation">`.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      // ── A11y rules — Contrast ──────────────────────────────────────────────────
      "FLINT-A11Y-060": {
        code: "FLINT-A11Y-060",
        ruleId: "A11Y-060",
        category: "a11y",
        severity: "critical",
        title: "Normal Text Insufficient Contrast",
        explanation: "Normal-size text must have a contrast ratio of at least 4.5:1 between the text color and background color per WCAG 2.1 AA. Low-contrast text is unreadable for users with low vision, color blindness, or when viewing screens in bright environments.",
        recovery: "Darken the text color or lighten the background (or both) until the 4.5:1 ratio is met. Use the WebAIM Contrast Checker or Flint's token picker to find compliant color pairs. Replace arbitrary color classes with token-backed classes that have been pre-validated for contrast.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.4.3 Contrast (Minimum) (Level AA)"
      },
      "FLINT-A11Y-061": {
        code: "FLINT-A11Y-061",
        ruleId: "A11Y-061",
        category: "a11y",
        severity: "critical",
        title: "Large Text Insufficient Contrast",
        explanation: "Large text (18pt or 14pt bold) has a reduced minimum contrast requirement of 3:1 under WCAG 2.1 AA because the larger letterforms are easier to read at lower contrast. Text that fails even this reduced threshold is inaccessible to low-vision users.",
        recovery: "Adjust the text or background color to achieve at least 3:1 contrast. Large text is defined as 18pt (24px) regular or 14pt (18.67px) bold. Verify the text size when determining which threshold applies.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.4.3 Contrast (Minimum) (Level AA)"
      },
      "FLINT-A11Y-062": {
        code: "FLINT-A11Y-062",
        ruleId: "A11Y-062",
        category: "a11y",
        severity: "critical",
        title: "UI Component Insufficient Contrast",
        explanation: "Interactive UI components (inputs, buttons, custom controls) must have at least 3:1 contrast between their visual boundaries and adjacent colors. This ensures users with low vision can identify form controls and interactive elements.",
        recovery: "Increase the border or outline contrast of the UI component against its background. Replace arbitrary border color classes with token-backed colors validated for 3:1 contrast. Consider adding a focus ring with adequate contrast for the focused state.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.4.11 Non-text Contrast (Level AA)"
      },
      // ── A11y rules — Forms ─────────────────────────────────────────────────────
      "FLINT-A11Y-070": {
        code: "FLINT-A11Y-070",
        ruleId: "A11Y-070",
        category: "a11y",
        severity: "critical",
        title: "Fieldset Missing Legend",
        explanation: '`<fieldset>` groups related form controls and requires a `<legend>` child to describe the group to screen reader users. Without a `<legend>`, users hear each field in isolation without knowing what context connects them (e.g. "address fields", "payment method", "shipping options").',
        recovery: "Add a `<legend>` as the first child of `<fieldset>` with a concise description of the group. If visual design requires hiding the legend, use a visually-hidden CSS class rather than `display: none`.",
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.1 Info and Relationships (Level A)"
      },
      "FLINT-A11Y-071": {
        code: "FLINT-A11Y-071",
        ruleId: "A11Y-071",
        category: "a11y",
        severity: "critical",
        title: "Required Input Missing aria-required",
        explanation: 'The HTML `required` attribute prevents form submission but does not reliably communicate the required nature of the field to all screen readers. `aria-required="true"` provides a consistent signal to assistive technologies that the field must be filled before the form can be submitted.',
        recovery: 'Add `aria-required="true"` alongside the `required` attribute. Ensure error messages are announced when required fields are left empty on submit.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 3.3.2 Labels or Instructions (Level A)"
      },
      "FLINT-A11Y-072": {
        code: "FLINT-A11Y-072",
        ruleId: "A11Y-072",
        category: "a11y",
        severity: "critical",
        title: "Invalid Input Missing Error Description",
        explanation: '`aria-invalid="true"` signals to assistive technologies that a field contains an error, but it does not describe what the error is. Without `aria-describedby` pointing to an error message element, screen reader users know a field is invalid but not why.',
        recovery: 'Add an error message element with a unique `id` and set `aria-describedby="[error-element-id]"` on the input. Show the error message element when the field is invalid and hide it otherwise.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 3.3.1 Error Identification (Level A)"
      },
      "FLINT-A11Y-073": {
        code: "FLINT-A11Y-073",
        ruleId: "A11Y-073",
        category: "a11y",
        severity: "critical",
        title: "Invalid Autocomplete Value",
        explanation: "The `autocomplete` attribute helps browsers and password managers autofill form fields correctly, and is required by WCAG 1.3.5 to identify input purpose. Invalid values are silently ignored, disabling browser autofill and failing the criterion.",
        recovery: 'Replace the invalid value with a standard HTML5 autofill detail token such as "name", "email", "tel", "current-password", or "street-address". See the full list of valid tokens in the HTML Living Standard.',
        sourceAuthority: "WCAG 2.1 AA",
        regulatoryRef: "\xA7 1.3.5 Identify Input Purpose (Level AA)"
      },
      // ── Session rules (GOV.3) ──────────────────────────────────────────────────
      "FLINT-SES-001": {
        code: "FLINT-SES-001",
        ruleId: "SES-001",
        category: "session",
        severity: "error",
        title: "Duplicate Flint Node IDs",
        explanation: "Flint uses `data-flint-id` attributes to track individual AST nodes across edits. Duplicate IDs cause the mutation engine to target the wrong node during AST operations, producing incorrect or destructive code edits.",
        recovery: "Re-run `injectFlintIds` on the affected file to regenerate unique IDs. Duplicate IDs typically arise from copy-paste operations that bypass the AST surgery layer. Use the Flint undo system to restore the pre-duplicate state if needed.",
        sourceAuthority: "Flint Commandment 7 (ID Preservation)"
      },
      "FLINT-SES-002": {
        code: "FLINT-SES-002",
        ruleId: "SES-002",
        category: "session",
        severity: "warning",
        title: "Orphaned Nodes",
        explanation: "Orphaned nodes are AST elements with `data-flint-id` attributes that are not registered in the Flint node index. They accumulate from structural operations (delete, move) that did not clean up stale IDs, bloating the session state without providing useful tracking.",
        recovery: "Reload the file in Flint to rebuild the node index from the current AST. If orphaned nodes persist, run a full session reset to clear stale index entries.",
        sourceAuthority: "Flint Commandment 7 (ID Preservation)"
      },
      "FLINT-SES-003": {
        code: "FLINT-SES-003",
        ruleId: "SES-003",
        category: "session",
        severity: "warning",
        title: "Stale Imports",
        explanation: "Stale imports are `import` statements that reference components or utilities no longer used in the file. They accumulate during cross-file move and delete operations and inflate bundle size. They also confuse the Import Synthesizer when generating context for new component insertions.",
        recovery: "Run `flint_fix` with the import cleanup option to remove unused imports automatically. The Import Synthesizer (`synthesizeImports`) will remove stale entries when the next mutation batch is applied.",
        sourceAuthority: "Flint Commandment 1 (Code is Truth)"
      },
      "FLINT-SES-004": {
        code: "FLINT-SES-004",
        ruleId: "SES-004",
        category: "session",
        severity: "error",
        title: "Missing Flint IDs",
        explanation: "JSX elements without `data-flint-id` attributes cannot be targeted by Flint's mutation engine. They become invisible to the visual layer and cannot be selected, moved, or mutated via Flint's AST surgery operations.",
        recovery: "Run `injectFlintIds` on the affected file to assign IDs to all eligible JSX elements. This happens automatically on file load and after every structural mutation \u2014 if IDs are missing, the file may have been edited outside Flint.",
        sourceAuthority: "Flint Commandment 7 (ID Preservation)"
      },
      // ── CR-SEAL: Registry constraint rules ────────────────────────────────────
      "FLINT-REG-001": {
        code: "FLINT-REG-001",
        ruleId: "REG-001",
        category: "governance",
        severity: "warning",
        title: "Unregistered Component Usage",
        explanation: "A component was used that is not part of your project's registered component library. When a library is configured, Flint ensures all generated and existing code uses only approved components \u2014 this prevents design system drift and unauthorized component usage.",
        recovery: "Add this component to your Armory (project registry), or replace it with a registered alternative from your component library.",
        sourceAuthority: "Flint CR.2 (Constrained Registry)"
      }
    };
  }
});

// flint-mcp/src/core/sync/colorMath.ts
function hexToRgb(hex) {
  const s = hex.trim().replace(/^#/, "");
  const expanded = s.length === 3 ? s[0] + s[0] + s[1] + s[1] + s[2] + s[2] : s;
  if (!/^[0-9a-fA-F]{6}$/.test(expanded)) return null;
  return [
    parseInt(expanded.slice(0, 2), 16),
    parseInt(expanded.slice(2, 4), 16),
    parseInt(expanded.slice(4, 6), 16)
  ];
}
function srgbToLinear(c) {
  const n = c / 255;
  return n <= 0.04045 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
}
function linearRgbToXyz(r, g, b) {
  return [
    r * 0.4124564 + g * 0.3575761 + b * 0.1804375,
    r * 0.2126729 + g * 0.7151522 + b * 0.072175,
    r * 0.0193339 + g * 0.119192 + b * 0.9503041
  ];
}
function xyzToLab(x, y, z) {
  const Xn = 0.95047, Yn = 1, Zn = 1.08883;
  const epsilon = 8856e-6;
  const kappa = 903.3;
  function f(val) {
    return val > epsilon ? Math.pow(val, 1 / 3) : (kappa * val + 16) / 116;
  }
  const fx = f(x / Xn), fy = f(y / Yn), fz = f(z / Zn);
  return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}
function hexToLab(hex) {
  const rgb = hexToRgb(hex);
  if (rgb === null) return null;
  const [lr, lg, lb] = rgb.map(srgbToLinear);
  const [x, y, z] = linearRgbToXyz(lr, lg, lb);
  return xyzToLab(x, y, z);
}
function deltaE2000(lab1, lab2) {
  const [L1, a1, b1] = lab1;
  const [L2, a2, b2] = lab2;
  const C1 = Math.sqrt(a1 * a1 + b1 * b1);
  const C2 = Math.sqrt(a2 * a2 + b2 * b2);
  const avgC7 = Math.pow((C1 + C2) / 2, 7);
  const G = 0.5 * (1 - Math.sqrt(avgC7 / (avgC7 + Math.pow(25, 7))));
  const a1p = a1 * (1 + G);
  const a2p = a2 * (1 + G);
  const C1p = Math.sqrt(a1p * a1p + b1 * b1);
  const C2p = Math.sqrt(a2p * a2p + b2 * b2);
  let h1p = Math.atan2(b1, a1p) / RAD;
  if (h1p < 0) h1p += 360;
  let h2p = Math.atan2(b2, a2p) / RAD;
  if (h2p < 0) h2p += 360;
  const dLp = L2 - L1;
  const dCp = C2p - C1p;
  let dhp;
  if (C1p * C2p === 0) {
    dhp = 0;
  } else if (Math.abs(h2p - h1p) <= 180) {
    dhp = h2p - h1p;
  } else {
    dhp = h2p > h1p ? h2p - h1p - 360 : h2p - h1p + 360;
  }
  const dHp = 2 * Math.sqrt(C1p * C2p) * Math.sin(dhp / 2 * RAD);
  const avgLp = (L1 + L2) / 2;
  const avgCp = (C1p + C2p) / 2;
  const avgCp7 = Math.pow(avgCp, 7);
  let avghp;
  if (C1p * C2p === 0) {
    avghp = h1p + h2p;
  } else if (Math.abs(h1p - h2p) <= 180) {
    avghp = (h1p + h2p) / 2;
  } else {
    avghp = h1p + h2p < 360 ? (h1p + h2p + 360) / 2 : (h1p + h2p - 360) / 2;
  }
  const T = 1 - 0.17 * Math.cos((avghp - 30) * RAD) + 0.24 * Math.cos(2 * avghp * RAD) + 0.32 * Math.cos((3 * avghp + 6) * RAD) - 0.2 * Math.cos((4 * avghp - 63) * RAD);
  const SL = 1 + 0.015 * (avgLp - 50) * (avgLp - 50) / Math.sqrt(20 + (avgLp - 50) * (avgLp - 50));
  const SC = 1 + 0.045 * avgCp;
  const SH = 1 + 0.015 * avgCp * T;
  const dTheta = 30 * Math.exp(-Math.pow((avghp - 275) / 25, 2));
  const RC = 2 * Math.sqrt(avgCp7 / (avgCp7 + Math.pow(25, 7)));
  const RT = -Math.sin(2 * dTheta * RAD) * RC;
  return Math.sqrt(
    Math.pow(dLp / SL, 2) + Math.pow(dCp / SC, 2) + Math.pow(dHp / SH, 2) + RT * (dCp / SC) * (dHp / SH)
  );
}
var MITHRIL_THRESHOLD, RAD;
var init_colorMath = __esm({
  "flint-mcp/src/core/sync/colorMath.ts"() {
    "use strict";
    MITHRIL_THRESHOLD = 2;
    RAD = Math.PI / 180;
  }
});

// flint-mcp/src/core/sync/syncViolationChecker.ts
function checkSyncViolations(localTokens, db, projectRoot, threshold = MITHRIL_THRESHOLD) {
  const warnings = [];
  const rows = db.prepare("SELECT token_name, token_value, source, figma_variable_id FROM token_source WHERE project_root = ?").all(projectRoot);
  const baselineMap = /* @__PURE__ */ new Map();
  for (const row of rows) {
    baselineMap.set(row.token_name, row);
  }
  for (const token of localTokens) {
    const baseline = baselineMap.get(token.token_path);
    if (!baseline || baseline.source !== "figma") {
      warnings.push({
        id: `sync-orphan::${token.token_path}`,
        type: "sync",
        severity: "advisory",
        value: 0,
        message: `SYNC-002: Token '${token.token_path}' has no Figma variable mapping`,
        nearestToken: null,
        nearestTokenValue: null,
        ruleId: "SYNC-002"
      });
      continue;
    }
    if (token.token_type === "color") {
      const localLab = hexToLab(token.token_value);
      const baselineLab = hexToLab(baseline.token_value);
      if (localLab && baselineLab) {
        const dE = deltaE2000(localLab, baselineLab);
        if (dE > threshold) {
          warnings.push({
            id: `sync-drift::${token.token_path}`,
            type: "sync",
            severity: "amber",
            value: dE,
            message: `SYNC-001: Token '${token.token_path}' color diverged from Figma source (\u0394E ${dE.toFixed(1)})`,
            nearestToken: token.token_path,
            nearestTokenValue: baseline.token_value,
            ruleId: "SYNC-001"
          });
        }
      }
    } else {
      if (token.token_value !== baseline.token_value) {
        warnings.push({
          id: `sync-drift::${token.token_path}`,
          type: "sync",
          severity: "amber",
          value: 1,
          message: `SYNC-001: Token '${token.token_path}' value '${token.token_value}' differs from Figma source '${baseline.token_value}'`,
          nearestToken: token.token_path,
          nearestTokenValue: baseline.token_value,
          ruleId: "SYNC-001"
        });
      }
    }
  }
  return warnings;
}
var init_syncViolationChecker = __esm({
  "flint-mcp/src/core/sync/syncViolationChecker.ts"() {
    "use strict";
    init_colorMath();
  }
});

// flint-mcp/src/core/htmlIntrinsics.ts
var HTML_INTRINSIC_TAGS, REACT_BUILTINS, REGISTRY_PASSTHROUGH;
var init_htmlIntrinsics = __esm({
  "flint-mcp/src/core/htmlIntrinsics.ts"() {
    "use strict";
    HTML_INTRINSIC_TAGS = /* @__PURE__ */ new Set([
      "div",
      "span",
      "p",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "a",
      "button",
      "img",
      "input",
      "textarea",
      "select",
      "option",
      "form",
      "label",
      "ul",
      "ol",
      "li",
      "table",
      "tr",
      "td",
      "th",
      "thead",
      "tbody",
      "tfoot",
      "nav",
      "header",
      "footer",
      "main",
      "section",
      "article",
      "aside",
      "figure",
      "figcaption",
      "details",
      "summary",
      "dialog",
      "svg",
      "path",
      "circle",
      "rect",
      "line",
      "polyline",
      "polygon",
      "video",
      "audio",
      "source",
      "canvas",
      "pre",
      "code",
      "blockquote",
      "hr",
      "br",
      "strong",
      "em",
      "small",
      "sub",
      "sup",
      "mark",
      "del",
      "ins",
      "abbr",
      "time"
    ]);
    REACT_BUILTINS = /* @__PURE__ */ new Set([
      "React",
      "Fragment",
      "Suspense",
      "StrictMode",
      "Profiler"
    ]);
    REGISTRY_PASSTHROUGH = /* @__PURE__ */ new Set([
      ...HTML_INTRINSIC_TAGS,
      ...REACT_BUILTINS
    ]);
  }
});

// flint-mcp/src/core/MithrilLinter.ts
var MithrilLinter_exports = {};
__export(MithrilLinter_exports, {
  INLINE_COLOR_PROPS: () => INLINE_COLOR_PROPS,
  INLINE_SHADOW_PROPS: () => INLINE_SHADOW_PROPS,
  INLINE_SPACING_PROPS: () => INLINE_SPACING_PROPS,
  INLINE_TYPOGRAPHY_PROPS: () => INLINE_TYPOGRAPHY_PROPS,
  MITHRIL_THRESHOLD: () => MITHRIL_THRESHOLD2,
  auditAll: () => auditAll,
  buildTokenCoverage: () => buildTokenCoverage,
  checkStyleProps: () => checkStyleProps,
  parseCssColorToHex: () => parseCssColorToHex,
  visitClassNames: () => visitClassNames,
  visitInlineStyles: () => visitInlineStyles,
  visitLocalTokenObjects: () => visitLocalTokenObjects,
  visitOpacity: () => visitOpacity,
  visitRegistryUsage: () => visitRegistryUsage,
  visitShadows: () => visitShadows,
  visitSpacing: () => visitSpacing,
  visitTypography: () => visitTypography
});
import _traverse2 from "@babel/traverse";
import * as t2 from "@babel/types";
function hexToRgb2(hex) {
  const s = hex.trim().replace(/^#/, "");
  const expanded = s.length === 3 ? s[0] + s[0] + s[1] + s[1] + s[2] + s[2] : s;
  if (!/^[0-9a-fA-F]{6}$/.test(expanded)) return null;
  return [
    parseInt(expanded.slice(0, 2), 16),
    parseInt(expanded.slice(2, 4), 16),
    parseInt(expanded.slice(4, 6), 16)
  ];
}
function srgbToLinear2(c) {
  const n = c / 255;
  return n <= 0.04045 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
}
function linearRgbToXyz2(r, g, b) {
  return [
    r * 0.4124564 + g * 0.3575761 + b * 0.1804375,
    r * 0.2126729 + g * 0.7151522 + b * 0.072175,
    r * 0.0193339 + g * 0.119192 + b * 0.9503041
  ];
}
function xyzToLab2(x, y, z) {
  const Xn = 0.95047, Yn = 1, Zn = 1.08883;
  const epsilon = 8856e-6;
  const kappa = 903.3;
  function f(val) {
    return val > epsilon ? Math.pow(val, 1 / 3) : (kappa * val + 16) / 116;
  }
  const fx = f(x / Xn), fy = f(y / Yn), fz = f(z / Zn);
  return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
}
function hexToLab2(hex) {
  const rgb = hexToRgb2(hex);
  if (rgb === null) return null;
  const [lr, lg, lb] = rgb.map(srgbToLinear2);
  const [x, y, z] = linearRgbToXyz2(lr, lg, lb);
  return xyzToLab2(x, y, z);
}
function deltaE20002(lab1, lab2) {
  const [L1, a1, b1] = lab1;
  const [L2, a2, b2] = lab2;
  const C1 = Math.sqrt(a1 * a1 + b1 * b1);
  const C2 = Math.sqrt(a2 * a2 + b2 * b2);
  const avgC7 = Math.pow((C1 + C2) / 2, 7);
  const G = 0.5 * (1 - Math.sqrt(avgC7 / (avgC7 + Math.pow(25, 7))));
  const a1p = a1 * (1 + G);
  const a2p = a2 * (1 + G);
  const C1p = Math.sqrt(a1p * a1p + b1 * b1);
  const C2p = Math.sqrt(a2p * a2p + b2 * b2);
  let h1p = Math.atan2(b1, a1p) / RAD2;
  if (h1p < 0) h1p += 360;
  let h2p = Math.atan2(b2, a2p) / RAD2;
  if (h2p < 0) h2p += 360;
  const dLp = L2 - L1;
  const dCp = C2p - C1p;
  let dhp;
  if (C1p * C2p === 0) {
    dhp = 0;
  } else if (Math.abs(h2p - h1p) <= 180) {
    dhp = h2p - h1p;
  } else {
    dhp = h2p > h1p ? h2p - h1p - 360 : h2p - h1p + 360;
  }
  const dHp = 2 * Math.sqrt(C1p * C2p) * Math.sin(dhp / 2 * RAD2);
  const avgLp = (L1 + L2) / 2;
  const avgCp = (C1p + C2p) / 2;
  const avgCp7 = Math.pow(avgCp, 7);
  let avghp;
  if (C1p * C2p === 0) {
    avghp = h1p + h2p;
  } else if (Math.abs(h1p - h2p) <= 180) {
    avghp = (h1p + h2p) / 2;
  } else {
    avghp = h1p + h2p < 360 ? (h1p + h2p + 360) / 2 : (h1p + h2p - 360) / 2;
  }
  const T = 1 - 0.17 * Math.cos((avghp - 30) * RAD2) + 0.24 * Math.cos(2 * avghp * RAD2) + 0.32 * Math.cos((3 * avghp + 6) * RAD2) - 0.2 * Math.cos((4 * avghp - 63) * RAD2);
  const SL = 1 + 0.015 * (avgLp - 50) * (avgLp - 50) / Math.sqrt(20 + (avgLp - 50) * (avgLp - 50));
  const SC = 1 + 0.045 * avgCp;
  const SH = 1 + 0.015 * avgCp * T;
  const dTheta = 30 * Math.exp(-Math.pow((avghp - 275) / 25, 2));
  const RC = 2 * Math.sqrt(avgCp7 / (avgCp7 + Math.pow(25, 7)));
  const RT = -Math.sin(2 * dTheta * RAD2) * RC;
  return Math.sqrt(
    Math.pow(dLp / SL, 2) + Math.pow(dCp / SC, 2) + Math.pow(dHp / SH, 2) + RT * (dCp / SC) * (dHp / SH)
  );
}
function findClosestToken(hexValue, tokens) {
  const targetLab = hexToLab2(hexValue);
  if (targetLab === null) return null;
  const colorTokens = tokens.filter((tok) => tok.token_type === "color");
  if (colorTokens.length === 0) return null;
  let best = null;
  for (const token of colorTokens) {
    const tokenLab = hexToLab2(token.token_value);
    if (tokenLab === null) continue;
    const deltaE = deltaE20002(targetLab, tokenLab);
    if (best === null || deltaE < best.deltaE) {
      best = { tokenPath: token.token_path, tokenValue: token.token_value, deltaE };
    }
  }
  return best;
}
function taxonomyFields(ruleId) {
  const entry = getErrorEntryByRuleId(ruleId);
  if (entry === null) return {};
  return { explanation: entry.explanation, recovery: entry.recovery };
}
function getFlintId(openEl) {
  const attr = openEl.attributes.find(
    (a) => t2.isJSXAttribute(a) && t2.isJSXIdentifier(a.name, { name: "data-flint-id" })
  );
  if (attr === void 0 || !t2.isStringLiteral(attr.value)) return null;
  return attr.value.value;
}
function getClassString(classAttr) {
  const valNode = classAttr.value;
  if (t2.isStringLiteral(valNode)) return valNode.value;
  if (t2.isJSXExpressionContainer(valNode) && t2.isStringLiteral(valNode.expression)) {
    return valNode.expression.value;
  }
  return null;
}
function severity(delta, criticalThreshold = 10) {
  return delta > criticalThreshold ? "critical" : "amber";
}
function parseCssColorToHex(value) {
  const trimmed = value.trim();
  if (/^#[0-9a-fA-F]{3,8}$/.test(trimmed)) return trimmed;
  const rgbMatch = /^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)/i.exec(trimmed);
  if (rgbMatch !== null) {
    const r = parseInt(rgbMatch[1], 10).toString(16).padStart(2, "0");
    const g = parseInt(rgbMatch[2], 10).toString(16).padStart(2, "0");
    const b = parseInt(rgbMatch[3], 10).toString(16).padStart(2, "0");
    return `#${r}${g}${b}`;
  }
  return null;
}
function checkStyleProps(entries, nodeId, tokens, options) {
  const threshold = options?.deltaE_threshold ?? MITHRIL_THRESHOLD2;
  const criticalThreshold = options?.deltaE_critical_threshold ?? 10;
  for (const { prop, stringValue, numericValue } of entries) {
    const rawVal = stringValue ?? (numericValue !== null ? String(numericValue) : null);
    if (rawVal === null) continue;
    if (INLINE_COLOR_PROPS.has(prop) && stringValue !== null) {
      const colMode = options?.ruleModes?.["MITHRIL-IST-COL"];
      if (colMode === "off") continue;
      const hexVal = parseCssColorToHex(stringValue);
      if (hexVal === null) continue;
      const match = findClosestToken(hexVal, tokens);
      if (match === null) continue;
      if (match.deltaE <= threshold) continue;
      const colSeverity = colMode === "advisory" ? "advisory" : severity(match.deltaE, criticalThreshold);
      return {
        id: nodeId,
        type: "inline-style-drift",
        severity: colSeverity,
        value: match.deltaE,
        message: `MITHRIL-IST-COL: inline \`${prop}: ${stringValue}\` \u0394E ${match.deltaE.toFixed(1)} \u2014 use token ${match.tokenPath}`,
        nearestToken: match.tokenPath,
        nearestTokenValue: match.tokenValue,
        ruleId: "MITHRIL-IST-COL",
        ...taxonomyFields("MITHRIL-IST-COL")
      };
    }
    const typTokenType = INLINE_TYPOGRAPHY_PROPS[prop];
    if (typTokenType !== void 0) {
      const typMode = options?.ruleModes?.["MITHRIL-IST-TYP"];
      if (typMode === "off") continue;
      const typeTokens = tokens.filter((tok) => tok.token_type === typTokenType);
      const hasMatch = typeTokens.some(
        (tok) => tok.token_value.toLowerCase() === rawVal.toLowerCase() || tok.token_value === rawVal.replace("px", "") || `${tok.token_value}px` === rawVal
      );
      if (hasMatch) continue;
      const suggestion = typeTokens[0]?.token_path ?? null;
      return {
        id: nodeId,
        type: "inline-style-drift",
        severity: typMode === "advisory" ? "advisory" : "amber",
        value: 1,
        message: suggestion !== null ? `MITHRIL-IST-TYP: inline \`${prop}: ${rawVal}\` not in ${typTokenType} tokens \u2014 use ${suggestion}` : `MITHRIL-IST-TYP: inline \`${prop}: ${rawVal}\` \u2014 no ${typTokenType} tokens defined`,
        nearestToken: suggestion,
        nearestTokenValue: suggestion !== null ? typeTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
        ruleId: "MITHRIL-IST-TYP",
        ...taxonomyFields("MITHRIL-IST-TYP")
      };
    }
    if (INLINE_SPACING_PROPS.has(prop)) {
      const spcMode = options?.ruleModes?.["MITHRIL-IST-SPC"];
      if (spcMode === "off") continue;
      if (rawVal === "0" || numericValue === 0) continue;
      const dimTokens = tokens.filter((tok) => tok.token_type === "dimension");
      const hasMatch = dimTokens.some(
        (tok) => tok.token_value === rawVal || tok.token_value === rawVal.replace("px", "") || `${tok.token_value}px` === rawVal
      );
      if (hasMatch) continue;
      const suggestion = dimTokens[0]?.token_path ?? null;
      return {
        id: nodeId,
        type: "inline-style-drift",
        severity: spcMode === "advisory" ? "advisory" : "amber",
        value: 1,
        message: suggestion !== null ? `MITHRIL-IST-SPC: inline \`${prop}: ${rawVal}\` not in dimension tokens \u2014 use ${suggestion}` : `MITHRIL-IST-SPC: inline \`${prop}: ${rawVal}\` \u2014 no dimension tokens defined`,
        nearestToken: suggestion,
        nearestTokenValue: suggestion !== null ? dimTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
        ruleId: "MITHRIL-IST-SPC",
        ...taxonomyFields("MITHRIL-IST-SPC")
      };
    }
    if (INLINE_SHADOW_PROPS.has(prop) && stringValue !== null) {
      const shdMode = options?.ruleModes?.["MITHRIL-IST-SHD"];
      if (shdMode === "off") continue;
      const shadowTokens = tokens.filter((tok) => tok.token_type === "shadow");
      if (shadowTokens.length === 0) continue;
      const hasMatch = shadowTokens.some((tok) => tok.token_value === stringValue);
      if (hasMatch) continue;
      const suggestion = shadowTokens[0]?.token_path ?? null;
      return {
        id: nodeId,
        type: "inline-style-drift",
        severity: shdMode === "advisory" ? "advisory" : "amber",
        value: 1,
        message: suggestion !== null ? `MITHRIL-IST-SHD: inline \`${prop}\` not in shadow tokens \u2014 use ${suggestion}` : `MITHRIL-IST-SHD: inline \`${prop}\` \u2014 add a shadow token`,
        nearestToken: suggestion,
        nearestTokenValue: suggestion !== null ? shadowTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
        ruleId: "MITHRIL-IST-SHD",
        ...taxonomyFields("MITHRIL-IST-SHD")
      };
    }
    if (prop === "opacity") {
      const opcMode = options?.ruleModes?.["MITHRIL-IST-OPC"];
      if (opcMode === "off") continue;
      if (numericValue === 0 || numericValue === 1 || rawVal === "0" || rawVal === "1") continue;
      const opacityTokens = tokens.filter((tok) => tok.token_type === "opacity");
      if (opacityTokens.length === 0) continue;
      const hasMatch = opacityTokens.some(
        (tok) => tok.token_value === rawVal || numericValue !== null && parseFloat(tok.token_value) === numericValue
      );
      if (hasMatch) continue;
      const suggestion = opacityTokens[0]?.token_path ?? null;
      return {
        id: nodeId,
        type: "inline-style-drift",
        severity: opcMode === "advisory" ? "advisory" : "amber",
        value: 1,
        message: suggestion !== null ? `MITHRIL-IST-OPC: inline \`opacity: ${rawVal}\` \u2014 use ${suggestion}` : `MITHRIL-IST-OPC: inline \`opacity: ${rawVal}\` \u2014 add an opacity token`,
        nearestToken: suggestion,
        nearestTokenValue: suggestion !== null ? opacityTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
        ruleId: "MITHRIL-IST-OPC",
        ...taxonomyFields("MITHRIL-IST-OPC")
      };
    }
  }
  return null;
}
function visitClassNames(ast, tokens, options) {
  const colMode = options?.ruleModes?.["MITHRIL-COL"];
  if (colMode === "off") return /* @__PURE__ */ new Map();
  const threshold = options?.deltaE_threshold ?? MITHRIL_THRESHOLD2;
  const criticalThreshold = options?.deltaE_critical_threshold ?? 10;
  const colorTokens = tokens.filter((tok) => tok.token_type === "color");
  const warnings = /* @__PURE__ */ new Map();
  if (colorTokens.length === 0) return warnings;
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "className" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      const classStr = getClassString(path9.node);
      if (classStr === null) return;
      let worstDelta = 0;
      let worstMatch = null;
      for (const cls of classStr.split(/\s+/)) {
        const m = ARBITRARY_COLOR_RE.exec(cls);
        if (m?.groups?.hex === void 0) continue;
        const match = findClosestToken(m.groups.hex, colorTokens);
        if (match !== null && match.deltaE > worstDelta) {
          worstDelta = match.deltaE;
          worstMatch = match;
        }
      }
      if (worstDelta <= threshold) return;
      const tokenLabel = worstMatch?.tokenPath ?? null;
      const colSeverity = colMode === "advisory" ? "advisory" : severity(worstDelta, criticalThreshold);
      const loc = path9.node.loc?.start;
      warnings.set(nodeId, {
        id: nodeId,
        type: "color-drift",
        severity: colSeverity,
        value: worstDelta,
        ...loc !== void 0 ? { line: loc.line, column: loc.column } : {},
        message: tokenLabel !== null ? `MITHRIL-COL: \u0394E ${worstDelta.toFixed(1)} \u2013 use ${tokenLabel}` : `MITHRIL-COL: \u0394E ${worstDelta.toFixed(1)} \u2013 no matching token`,
        nearestToken: tokenLabel,
        nearestTokenValue: worstMatch?.tokenValue ?? null,
        ruleId: "MITHRIL-COL",
        ...taxonomyFields("MITHRIL-COL")
      });
    }
  });
  return warnings;
}
function visitTypography(ast, tokens, options) {
  const warnings = /* @__PURE__ */ new Map();
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "className" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      const classStr = getClassString(path9.node);
      if (classStr === null) return;
      for (const cls of classStr.split(/\s+/)) {
        for (const { rule, re, tokenType } of TYP_REGEXES) {
          const ruleMode = options?.ruleModes?.[rule];
          if (ruleMode === "off") continue;
          const m = re.exec(cls);
          if (m?.groups?.val === void 0) continue;
          const rawVal = m.groups.val;
          const typeTokens = tokens.filter((tok) => tok.token_type === tokenType);
          const hasMatch = typeTokens.some(
            (tok) => tok.token_value.toLowerCase() === rawVal.toLowerCase()
          );
          if (hasMatch) continue;
          const suggestion = typeTokens[0]?.token_path ?? null;
          const msg = suggestion !== null ? `${rule}: arbitrary '${rawVal}' not in token set \u2014 use ${suggestion}` : `${rule}: arbitrary '${rawVal}' not in token set \u2014 add a ${tokenType} token`;
          if (!warnings.has(nodeId)) {
            const typLoc = path9.node.loc?.start;
            warnings.set(nodeId, {
              id: nodeId,
              type: "typography-drift",
              severity: ruleMode === "advisory" ? "advisory" : "amber",
              value: 1,
              ...typLoc !== void 0 ? { line: typLoc.line, column: typLoc.column } : {},
              message: msg,
              nearestToken: suggestion,
              nearestTokenValue: suggestion !== null ? typeTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
              ruleId: rule,
              ...taxonomyFields(rule)
            });
          }
        }
      }
    }
  });
  return warnings;
}
function visitSpacing(ast, tokens, options) {
  const spcMode = options?.ruleModes?.["MITHRIL-SPC-001"];
  if (spcMode === "off") return /* @__PURE__ */ new Map();
  const dimTokens = tokens.filter((tok) => tok.token_type === "dimension");
  const warnings = /* @__PURE__ */ new Map();
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "className" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      const classStr = getClassString(path9.node);
      if (classStr === null) return;
      for (const cls of classStr.split(/\s+/)) {
        const m = SPACING_RE.exec(cls);
        if (m?.groups?.val === void 0) continue;
        const rawVal = m.groups.val;
        const hasMatch = dimTokens.some(
          (tok) => tok.token_value === rawVal || tok.token_value === rawVal.replace("px", "")
        );
        if (hasMatch) continue;
        const suggestion = dimTokens[0]?.token_path ?? null;
        if (!warnings.has(nodeId)) {
          const spcLoc = path9.node.loc?.start;
          warnings.set(nodeId, {
            id: nodeId,
            type: "spacing-drift",
            severity: spcMode === "advisory" ? "advisory" : "amber",
            value: 1,
            ...spcLoc !== void 0 ? { line: spcLoc.line, column: spcLoc.column } : {},
            message: suggestion !== null ? `MITHRIL-SPC-001: arbitrary '${rawVal}' not in dimension tokens \u2014 use ${suggestion}` : `MITHRIL-SPC-001: arbitrary '${rawVal}' \u2014 no dimension tokens defined`,
            nearestToken: suggestion,
            nearestTokenValue: suggestion !== null ? dimTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
            ruleId: "MITHRIL-SPC-001",
            ...taxonomyFields("MITHRIL-SPC-001")
          });
        }
      }
    }
  });
  return warnings;
}
function visitShadows(ast, tokens, options) {
  const shdMode = options?.ruleModes?.["MITHRIL-SHD-001"];
  if (shdMode === "off") return /* @__PURE__ */ new Map();
  const shadowTokens = tokens.filter((tok) => tok.token_type === "shadow");
  const warnings = /* @__PURE__ */ new Map();
  if (shadowTokens.length === 0) return warnings;
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "className" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      const classStr = getClassString(path9.node);
      if (classStr === null) return;
      for (const cls of classStr.split(/\s+/)) {
        const m = SHADOW_RE.exec(cls);
        if (m?.groups?.val === void 0) continue;
        const rawVal = m.groups.val.replace(/_/g, " ");
        const hasMatch = shadowTokens.some((tok) => tok.token_value === rawVal);
        if (hasMatch) continue;
        const suggestion = shadowTokens[0]?.token_path ?? null;
        if (!warnings.has(nodeId)) {
          const shdLoc = path9.node.loc?.start;
          warnings.set(nodeId, {
            id: nodeId,
            type: "shadow-drift",
            severity: shdMode === "advisory" ? "advisory" : "amber",
            value: 1,
            ...shdLoc !== void 0 ? { line: shdLoc.line, column: shdLoc.column } : {},
            message: suggestion !== null ? `MITHRIL-SHD-001: arbitrary shadow not in token set \u2014 use ${suggestion}` : `MITHRIL-SHD-001: arbitrary shadow \u2014 add a shadow token`,
            nearestToken: suggestion,
            nearestTokenValue: suggestion !== null ? shadowTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
            ruleId: "MITHRIL-SHD-001",
            ...taxonomyFields("MITHRIL-SHD-001")
          });
        }
      }
    }
  });
  return warnings;
}
function visitOpacity(ast, tokens, options) {
  const opcMode = options?.ruleModes?.["MITHRIL-OPC-001"];
  if (opcMode === "off") return /* @__PURE__ */ new Map();
  const opacityTokens = tokens.filter((tok) => tok.token_type === "opacity");
  const warnings = /* @__PURE__ */ new Map();
  if (opacityTokens.length === 0) return warnings;
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "className" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      const classStr = getClassString(path9.node);
      if (classStr === null) return;
      for (const cls of classStr.split(/\s+/)) {
        const m = OPACITY_RE.exec(cls);
        if (m?.groups?.val === void 0) continue;
        const rawVal = m.groups.val;
        const hasMatch = opacityTokens.some((tok) => tok.token_value === rawVal);
        if (hasMatch) continue;
        const suggestion = opacityTokens[0]?.token_path ?? null;
        if (!warnings.has(nodeId)) {
          const opcLoc = path9.node.loc?.start;
          warnings.set(nodeId, {
            id: nodeId,
            type: "opacity-drift",
            severity: opcMode === "advisory" ? "advisory" : "amber",
            value: 1,
            ...opcLoc !== void 0 ? { line: opcLoc.line, column: opcLoc.column } : {},
            message: suggestion !== null ? `MITHRIL-OPC-001: arbitrary opacity '${rawVal}' \u2014 use ${suggestion}` : `MITHRIL-OPC-001: arbitrary opacity '${rawVal}' \u2014 add an opacity token`,
            nearestToken: suggestion,
            nearestTokenValue: suggestion !== null ? opacityTokens.find((tk) => tk.token_path === suggestion)?.token_value ?? null : null,
            ruleId: "MITHRIL-OPC-001",
            ...taxonomyFields("MITHRIL-OPC-001")
          });
        }
      }
    }
  });
  return warnings;
}
function visitInlineStyles(ast, tokens, options) {
  const warnings = /* @__PURE__ */ new Map();
  let inlinePropsScanned = 0;
  let inlinePropsSkipped = 0;
  let inlineViolations = 0;
  traverse2(ast, {
    JSXAttribute(path9) {
      if (!t2.isJSXIdentifier(path9.node.name, { name: "style" })) return;
      const openEl = path9.parentPath?.node;
      if (!t2.isJSXOpeningElement(openEl)) return;
      const nodeId = getFlintId(openEl);
      if (nodeId === null) return;
      if (warnings.has(nodeId)) return;
      const val = path9.node.value;
      if (!t2.isJSXExpressionContainer(val)) return;
      const expr = val.expression;
      if (!t2.isObjectExpression(expr)) return;
      const styleLoc = path9.node.loc?.start;
      const entries = [];
      for (const prop of expr.properties) {
        if (!t2.isObjectProperty(prop)) continue;
        if (!t2.isIdentifier(prop.key) && !t2.isStringLiteral(prop.key)) continue;
        const propName = t2.isIdentifier(prop.key) ? prop.key.name : prop.key.value;
        const propValue = prop.value;
        if (t2.isStringLiteral(propValue)) {
          inlinePropsScanned++;
          entries.push({ prop: propName, stringValue: propValue.value, numericValue: null });
        } else if (t2.isNumericLiteral(propValue)) {
          inlinePropsScanned++;
          entries.push({ prop: propName, stringValue: null, numericValue: propValue.value });
        } else {
          inlinePropsSkipped++;
        }
      }
      if (entries.length === 0) return;
      const warning = checkStyleProps(entries, nodeId, tokens, options);
      if (warning !== null) {
        if (styleLoc !== void 0) {
          warning.line = styleLoc.line;
          warning.column = styleLoc.column;
        }
        warnings.set(nodeId, warning);
        inlineViolations++;
      }
    }
  });
  return { warnings, coverage: { inlinePropsScanned, inlinePropsSkipped, inlineViolations } };
}
function buildTokenCoverage(tokens, inlineStats) {
  const colorTokens = tokens.filter((t3) => t3.token_type === "color").length;
  const dimensionTokens = tokens.filter((t3) => t3.token_type === "dimension").length;
  const shadowTokens = tokens.filter((t3) => t3.token_type === "shadow").length;
  const fontWeightTokens = tokens.filter((t3) => t3.token_type === "fontWeight").length;
  return {
    colorTokens,
    dimensionTokens,
    shadowTokens,
    fontWeightTokens,
    inlinePropsScanned: inlineStats.inlinePropsScanned,
    inlinePropsSkipped: inlineStats.inlinePropsSkipped,
    inlineViolations: inlineStats.inlineViolations
  };
}
function isTokenLike(value) {
  if (typeof value === "string") {
    if (HEX_COLOR_RE.test(value)) return true;
    if (PX_VALUE_RE.test(value)) return true;
    return false;
  }
  return Number.isInteger(value) && value >= 100 && value <= 900 && value % 100 === 0;
}
function matchesFlintToken(value, tokens, threshold) {
  const strVal = String(value);
  for (const tok of tokens) {
    if (tok.token_type === "color" && typeof value === "string") {
      const hexVal = parseCssColorToHex(value);
      const tokHex = parseCssColorToHex(tok.token_value);
      if (hexVal !== null && tokHex !== null) {
        const lab1 = hexToLab2(hexVal);
        const lab2 = hexToLab2(tokHex);
        if (lab1 !== null && lab2 !== null && deltaE20002(lab1, lab2) <= threshold) return true;
      }
      continue;
    }
    if (tok.token_type === "dimension") {
      if (tok.token_value === strVal || tok.token_value === strVal.replace("px", "") || `${tok.token_value}px` === strVal) return true;
      continue;
    }
    if (tok.token_type === "fontWeight") {
      if (tok.token_value === strVal) return true;
      continue;
    }
  }
  return false;
}
function visitLocalTokenObjects(ast, tokens, options) {
  const dtoMode = options?.ruleModes?.["MITHRIL-DTO-001"];
  if (dtoMode === "off") return /* @__PURE__ */ new Map();
  if (tokens.length === 0) return /* @__PURE__ */ new Map();
  const threshold = options?.deltaE_threshold ?? MITHRIL_THRESHOLD2;
  const warnings = /* @__PURE__ */ new Map();
  traverse2(ast, {
    VariableDeclarator(path9) {
      const init = path9.node.init;
      if (!t2.isObjectExpression(init)) return;
      const parentDecl = path9.parentPath?.node;
      if (!t2.isVariableDeclaration(parentDecl)) return;
      const grandParent = path9.parentPath?.parentPath?.node;
      const isModuleScope = t2.isProgram(grandParent) || t2.isExportNamedDeclaration(grandParent);
      if (!isModuleScope) return;
      if (!t2.isIdentifier(path9.node.id)) return;
      const varName = path9.node.id.name;
      let matchCount = 0;
      let unregisteredCount = 0;
      for (const prop of init.properties) {
        if (!t2.isObjectProperty(prop)) continue;
        const propValue = prop.value;
        let rawValue = null;
        if (t2.isStringLiteral(propValue)) {
          rawValue = propValue.value;
        } else if (t2.isNumericLiteral(propValue)) {
          rawValue = propValue.value;
        }
        if (rawValue === null) continue;
        if (!isTokenLike(rawValue)) continue;
        if (matchesFlintToken(rawValue, tokens, threshold)) {
          matchCount++;
        } else {
          unregisteredCount++;
        }
      }
      if (matchCount < 2) return;
      const nodeId = `dto-${varName}-${path9.node.loc?.start.line ?? 0}`;
      const loc = path9.node.loc?.start;
      let message = `Local token object "${varName}" shadows ${matchCount} Flint design tokens. Remove this local copy and reference tokens via CSS variables or Tailwind classes to prevent drift.`;
      if (unregisteredCount >= 1) {
        message += ` ${unregisteredCount} values have no matching Flint token \u2014 register them in design-tokens.json.`;
      }
      const severity2 = dtoMode === "advisory" ? "advisory" : "amber";
      const warning = {
        id: nodeId,
        type: "inline-style-drift",
        severity: severity2,
        value: matchCount,
        message,
        nearestToken: null,
        nearestTokenValue: null,
        ruleId: "MITHRIL-DTO-001",
        ...taxonomyFields("MITHRIL-DTO-001"),
        ...loc !== void 0 ? { line: loc.line, column: loc.column } : {}
      };
      if (!warnings.has(nodeId)) {
        warnings.set(nodeId, warning);
      }
    }
  });
  return warnings;
}
function visitRegistryUsage(ast, registry, options) {
  const warnings = /* @__PURE__ */ new Map();
  const mode = options?.ruleModes?.["REG-001"];
  if (mode === "off") return warnings;
  if (!registry || Object.keys(registry).length === 0) return warnings;
  const registryNames = new Set(Object.keys(registry));
  const seen = /* @__PURE__ */ new Set();
  const taxonomyEntry = getErrorEntryByRuleId("REG-001");
  traverse2(ast, {
    JSXOpeningElement(path9) {
      const nameNode = path9.node.name;
      let name;
      if (t2.isJSXIdentifier(nameNode)) {
        name = nameNode.name;
      } else if (t2.isJSXMemberExpression(nameNode)) {
        let cursor = nameNode;
        while (t2.isJSXMemberExpression(cursor)) {
          cursor = cursor.object;
        }
        if (!t2.isJSXIdentifier(cursor)) return;
        name = cursor.name;
      } else {
        return;
      }
      if (HTML_INTRINSIC_TAGS.has(name)) return;
      if (name[0] === name[0]?.toLowerCase()) return;
      if (REACT_BUILTINS.has(name)) return;
      if (seen.has(name)) return;
      seen.add(name);
      if (registryNames.has(name)) return;
      const loc = nameNode.loc?.start;
      const warningId = `reg-${name}-${loc?.line ?? 0}`;
      const severity2 = mode === "advisory" ? "advisory" : "amber";
      const prefix = name.toLowerCase().slice(0, 4);
      const suggestions = [...registryNames].filter((r) => r.toLowerCase().includes(prefix)).slice(0, 5);
      const suggestionNote = suggestions.length > 0 ? ` Try: ${suggestions.join(", ")}.` : "";
      warnings.set(warningId, {
        id: warningId,
        type: "registry",
        severity: severity2,
        value: 0,
        message: `<${name}> is not in your project's component library.${suggestionNote}`,
        nearestToken: null,
        nearestTokenValue: null,
        ruleId: "REG-001",
        fixable: false,
        explanation: taxonomyEntry?.explanation ?? "Only components from your project's registered library are allowed. This ensures design system consistency and prevents unauthorized component drift.",
        recovery: taxonomyEntry?.recovery ?? "Add this component to your Armory (project registry), or replace it with a registered alternative.",
        line: loc?.line,
        column: loc?.column
      });
    }
  });
  return warnings;
}
function auditAll(ast, tokens, options) {
  const merged = /* @__PURE__ */ new Map();
  for (const visit of [
    () => visitClassNames(ast, tokens, options),
    () => visitTypography(ast, tokens, options),
    () => visitSpacing(ast, tokens, options),
    () => visitShadows(ast, tokens, options),
    () => visitOpacity(ast, tokens, options)
  ]) {
    for (const [id, warning] of visit()) {
      if (!merged.has(id)) merged.set(id, warning);
    }
  }
  const { warnings: inlineWarnings } = visitInlineStyles(ast, tokens, options);
  for (const [id, warning] of inlineWarnings) {
    if (!merged.has(id)) merged.set(id, warning);
  }
  const dtoWarnings = visitLocalTokenObjects(ast, tokens, options);
  for (const [id, warning] of dtoWarnings) {
    if (!merged.has(id)) merged.set(id, warning);
  }
  if (options?.registry && Object.keys(options.registry).length > 0) {
    const regWarnings = visitRegistryUsage(ast, options.registry, options);
    for (const [id, warning] of regWarnings) {
      if (!merged.has(id)) merged.set(id, warning);
    }
  }
  if (options?.syncDb && options.projectRoot) {
    const syncMode = options.ruleModes?.["SYNC-001"];
    const orphanMode = options.ruleModes?.["SYNC-002"];
    if (syncMode !== "off" || orphanMode !== "off") {
      const localTokens = tokens.map((t3) => ({
        token_path: t3.token_path,
        token_type: t3.token_type,
        token_value: t3.token_value
      }));
      const syncWarnings = checkSyncViolations(
        localTokens,
        options.syncDb,
        options.projectRoot,
        options.deltaE_threshold
      );
      for (const warning of syncWarnings) {
        if (warning.ruleId === "SYNC-001" && syncMode === "off") continue;
        if (warning.ruleId === "SYNC-002" && orphanMode === "off") continue;
        if (warning.ruleId === "SYNC-001" && syncMode === "advisory") {
          warning.severity = "advisory";
        }
        if (warning.ruleId === "SYNC-002" && orphanMode === "advisory") {
          warning.severity = "advisory";
        }
        if (!merged.has(warning.id)) merged.set(warning.id, warning);
      }
    }
  }
  return merged;
}
var traverse2, MITHRIL_THRESHOLD2, RAD2, INLINE_COLOR_PROPS, INLINE_TYPOGRAPHY_PROPS, INLINE_SPACING_PROPS, INLINE_SHADOW_PROPS, ARBITRARY_COLOR_RE, TYP_REGEXES, SPACING_RE, SHADOW_RE, OPACITY_RE, HEX_COLOR_RE, PX_VALUE_RE;
var init_MithrilLinter = __esm({
  "flint-mcp/src/core/MithrilLinter.ts"() {
    "use strict";
    init_errorTaxonomy();
    init_syncViolationChecker();
    init_htmlIntrinsics();
    traverse2 = typeof _traverse2 === "function" ? _traverse2 : _traverse2.default;
    MITHRIL_THRESHOLD2 = 2;
    RAD2 = Math.PI / 180;
    INLINE_COLOR_PROPS = /* @__PURE__ */ new Set([
      "color",
      "backgroundColor",
      "borderColor",
      "borderTopColor",
      "borderRightColor",
      "borderBottomColor",
      "borderLeftColor",
      "borderInlineColor",
      "borderBlockColor",
      "outlineColor",
      "caretColor",
      "fill",
      "stroke",
      "textDecorationColor",
      "columnRuleColor",
      "accentColor",
      "scrollbarColor"
    ]);
    INLINE_TYPOGRAPHY_PROPS = {
      fontSize: "dimension",
      fontWeight: "fontWeight",
      lineHeight: "lineHeight",
      letterSpacing: "letterSpacing",
      fontFamily: "fontFamily"
    };
    INLINE_SPACING_PROPS = /* @__PURE__ */ new Set([
      "margin",
      "marginTop",
      "marginRight",
      "marginBottom",
      "marginLeft",
      "marginInline",
      "marginInlineStart",
      "marginInlineEnd",
      "marginBlock",
      "marginBlockStart",
      "marginBlockEnd",
      "padding",
      "paddingTop",
      "paddingRight",
      "paddingBottom",
      "paddingLeft",
      "paddingInline",
      "paddingInlineStart",
      "paddingInlineEnd",
      "paddingBlock",
      "paddingBlockStart",
      "paddingBlockEnd",
      "gap",
      "rowGap",
      "columnGap",
      "width",
      "height",
      "minWidth",
      "maxWidth",
      "minHeight",
      "maxHeight",
      "inlineSize",
      "blockSize",
      "minInlineSize",
      "maxInlineSize",
      "minBlockSize",
      "maxBlockSize",
      "top",
      "right",
      "bottom",
      "left",
      "inset",
      "insetInline",
      "insetInlineStart",
      "insetInlineEnd",
      "insetBlock",
      "insetBlockStart",
      "insetBlockEnd",
      "flexBasis",
      "borderWidth",
      "borderTopWidth",
      "borderRightWidth",
      "borderBottomWidth",
      "borderLeftWidth",
      "borderRadius",
      "borderTopLeftRadius",
      "borderTopRightRadius",
      "borderBottomRightRadius",
      "borderBottomLeftRadius",
      "borderStartStartRadius",
      "borderStartEndRadius",
      "borderEndStartRadius",
      "borderEndEndRadius",
      "outlineWidth",
      "outlineOffset"
    ]);
    INLINE_SHADOW_PROPS = /* @__PURE__ */ new Set(["boxShadow", "textShadow"]);
    ARBITRARY_COLOR_RE = /^(?:[\w-]+:)*[\w-]+-\[(?<hex>#[0-9a-fA-F]{3,8})\]$/;
    TYP_REGEXES = [
      { rule: "MITHRIL-TYP-001", re: /^(?:[\w-]+:)*font-\[(?<val>[^\]]+)\]$/, tokenType: "fontFamily" },
      { rule: "MITHRIL-TYP-002", re: /^(?:[\w-]+:)*text-\[(?<val>[\d.]+(?:px|rem|em|%|vw|vh))\]$/, tokenType: "dimension" },
      { rule: "MITHRIL-TYP-003", re: /^(?:[\w-]+:)*font-\[(?<val>\d{3})\]$/, tokenType: "fontWeight" },
      { rule: "MITHRIL-TYP-004", re: /^(?:[\w-]+:)*leading-\[(?<val>[^\]]+)\]$/, tokenType: "lineHeight" },
      { rule: "MITHRIL-TYP-005", re: /^(?:[\w-]+:)*tracking-\[(?<val>[^\]]+)\]$/, tokenType: "letterSpacing" }
    ];
    SPACING_RE = /^(?:[\w-]+:)*(?:p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|gap|space-x|space-y|w|h|min-w|min-h|max-w|max-h)-\[(?<val>[\d.]+(?:px|rem|em|%|vw|vh))\]$/;
    SHADOW_RE = /^(?:[\w-]+:)*shadow-\[(?<val>[^\]]+)\]$/;
    OPACITY_RE = /^(?:[\w-]+:)*opacity-\[(?<val>[\d.]+%?)\]$/;
    HEX_COLOR_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
    PX_VALUE_RE = /^\d+(\.\d+)?px$/;
  }
});

// flint-mcp/src/core/a11y/helpers.ts
function getJsxAttr(opening, attrName) {
  return opening.attributes.find(
    (a) => a.type === "JSXAttribute" && a.name.type === "JSXIdentifier" && a.name.name === attrName
  );
}
function getAttributeValue(attr) {
  if (!attr) return null;
  if (attr.type !== "JSXAttribute") return null;
  const { value } = attr;
  if (!value) return "";
  if (value.type === "StringLiteral") return value.value;
  if (value.type === "JSXExpressionContainer" && value.expression.type === "StringLiteral") {
    return value.expression.value;
  }
  return null;
}
function getAttributeStringValue(opening, name) {
  return getAttributeValue(getJsxAttr(opening, name));
}
function hasNonEmptyAttr(opening, name) {
  const val = getAttributeValue(getJsxAttr(opening, name));
  return typeof val === "string" && val.trim() !== "";
}
function hasDynamicLabel(opening) {
  return ["aria-label", "aria-labelledby", "title"].some((name) => {
    const a = getJsxAttr(opening, name);
    if (!a) return false;
    if (a.type === "JSXAttribute" && a.value?.type === "JSXExpressionContainer") return true;
    return false;
  });
}
function hasTextChildren(path9) {
  return path9.node.children.some((child) => {
    if (child.type === "JSXText") return /\S/.test(child.value);
    if (child.type === "JSXExpressionContainer") {
      return child.expression.type !== "JSXEmptyExpression";
    }
    if (child.type === "JSXElement") return true;
    return false;
  });
}
function getFlintId2(opening, fallback) {
  const attr = getJsxAttr(opening, "data-flint-id");
  if (!attr || attr.type !== "JSXAttribute") return fallback;
  const val = attr.value;
  if (val?.type === "StringLiteral") return val.value;
  if (val?.type === "JSXExpressionContainer" && val.expression.type === "StringLiteral") {
    return val.expression.value;
  }
  return fallback;
}
function getTagName(path9) {
  const nameNode = path9.node.openingElement.name;
  if (nameNode.type === "JSXIdentifier") return nameNode.name.toLowerCase();
  return null;
}
function hasDirectChildTag(path9, tagName) {
  return path9.node.children.some(
    (child) => child.type === "JSXElement" && child.openingElement.name.type === "JSXIdentifier" && child.openingElement.name.name.toLowerCase() === tagName.toLowerCase()
  );
}
function getExplicitRole(opening) {
  return getAttributeStringValue(opening, "role");
}
function getImplicitRole(tag) {
  const implicitRoles = {
    a: "link",
    area: "link",
    article: "article",
    aside: "complementary",
    button: "button",
    datalist: "listbox",
    details: "group",
    dialog: "dialog",
    fieldset: "group",
    figure: "figure",
    footer: "contentinfo",
    form: "form",
    h1: "heading",
    h2: "heading",
    h3: "heading",
    h4: "heading",
    h5: "heading",
    h6: "heading",
    header: "banner",
    hr: "separator",
    img: "img",
    input: "textbox",
    // simplified — type-specific
    li: "listitem",
    link: "link",
    main: "main",
    math: "math",
    menu: "list",
    nav: "navigation",
    ol: "list",
    option: "option",
    output: "status",
    progress: "progressbar",
    section: "region",
    select: "listbox",
    summary: "button",
    table: "table",
    tbody: "rowgroup",
    td: "cell",
    textarea: "textbox",
    tfoot: "rowgroup",
    th: "columnheader",
    thead: "rowgroup",
    tr: "row",
    ul: "list"
  };
  return implicitRoles[tag] ?? null;
}
function isNativelyFocusable(tag) {
  return ["a", "button", "input", "select", "textarea", "details", "summary"].includes(tag);
}
function hasEventHandler(opening, eventName) {
  return opening.attributes.some(
    (a) => a.type === "JSXAttribute" && a.name.type === "JSXIdentifier" && a.name.name === eventName
  );
}
var init_helpers = __esm({
  "flint-mcp/src/core/a11y/helpers.ts"() {
    "use strict";
  }
});

// flint-mcp/src/core/a11y/contrast-utils.ts
function parseHex(hex) {
  const clean = hex.replace(/^#/, "");
  if (clean.length === 3) {
    const r = parseInt(clean[0] + clean[0], 16);
    const g = parseInt(clean[1] + clean[1], 16);
    const b = parseInt(clean[2] + clean[2], 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
    return [r, g, b];
  }
  if (clean.length === 6 || clean.length === 8) {
    const r = parseInt(clean.slice(0, 2), 16);
    const g = parseInt(clean.slice(2, 4), 16);
    const b = parseInt(clean.slice(4, 6), 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
    return [r, g, b];
  }
  return null;
}
function linearize(c) {
  const cs = c / 255;
  return cs <= 0.04045 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
}
function relativeLuminance(rgb) {
  const [r, g, b] = rgb;
  const R = linearize(r);
  const G = linearize(g);
  const B = linearize(b);
  return 0.2126 * R + 0.7152 * G + 0.0722 * B;
}
function wcagContrastRatio(fg, bg) {
  const fgRgb = parseHex(fg);
  const bgRgb = parseHex(bg);
  if (!fgRgb || !bgRgb) return null;
  const L1 = relativeLuminance(fgRgb);
  const L2 = relativeLuminance(bgRgb);
  const lighter = Math.max(L1, L2);
  const darker = Math.min(L1, L2);
  return (lighter + 0.05) / (darker + 0.05);
}
function meetsAA(ratio, isLargeText2) {
  return ratio >= (isLargeText2 ? 3 : 4.5);
}
function isLargeText(fontSize, fontWeight) {
  if (!fontSize) return false;
  let sizePx = null;
  const tailwindSizeMatch = /^text-(.+)$/.exec(fontSize);
  if (tailwindSizeMatch) {
    const sizeKey = tailwindSizeMatch[1];
    sizePx = TAILWIND_FONT_SIZE_PX[sizeKey] ?? null;
  }
  if (!sizePx) {
    const arbitraryPxMatch = /^text-\[(\d+(?:\.\d+)?)px\]$/.exec(fontSize);
    if (arbitraryPxMatch) {
      sizePx = parseFloat(arbitraryPxMatch[1]);
    }
  }
  if (!sizePx) {
    const rawPxMatch = /^(\d+(?:\.\d+)?)px$/.exec(fontSize);
    if (rawPxMatch) {
      sizePx = parseFloat(rawPxMatch[1]);
    }
  }
  if (!sizePx) {
    const ptMatch = /^(\d+(?:\.\d+)?)pt$/.exec(fontSize);
    if (ptMatch) {
      sizePx = parseFloat(ptMatch[1]) * (4 / 3);
    }
  }
  if (!sizePx) return false;
  if (sizePx >= 24) return true;
  if (sizePx >= 18.67) {
    let weight = null;
    if (fontWeight) {
      const tailwindWeightMatch = /^font-(.+)$/.exec(fontWeight);
      if (tailwindWeightMatch) {
        weight = TAILWIND_FONT_WEIGHT[tailwindWeightMatch[1]] ?? null;
      }
      if (!weight) {
        const numWeight = parseInt(fontWeight, 10);
        if (!isNaN(numWeight)) weight = numWeight;
      }
    }
    if (weight !== null && weight >= 700) return true;
  }
  return false;
}
function extractHexFromArbitraryClass(cls) {
  const match = /\[#([0-9a-fA-F]{3,8})\]/.exec(cls);
  if (match) return `#${match[1]}`;
  return null;
}
function extractColorContext(classNames) {
  let foreground = null;
  let background = null;
  let fontSize = null;
  let fontWeight = null;
  for (const cls of classNames) {
    if (cls.startsWith("text-[#") || cls.startsWith("text-[")) {
      const hex = extractHexFromArbitraryClass(cls);
      if (hex) foreground = hex;
    }
    if (cls.startsWith("bg-[#") || cls.startsWith("bg-[")) {
      const hex = extractHexFromArbitraryClass(cls);
      if (hex) background = hex;
    }
    if (/^text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl|9xl)$/.test(cls)) {
      fontSize = cls;
    }
    if (/^text-\[\d/.test(cls)) {
      fontSize = cls;
    }
    if (/^font-(thin|extralight|light|normal|medium|semibold|bold|extrabold|black)$/.test(cls)) {
      fontWeight = cls;
    }
  }
  return { foreground, background, fontSize, fontWeight };
}
var TAILWIND_FONT_SIZE_PX, TAILWIND_FONT_WEIGHT;
var init_contrast_utils = __esm({
  "flint-mcp/src/core/a11y/contrast-utils.ts"() {
    "use strict";
    TAILWIND_FONT_SIZE_PX = {
      xs: 12,
      sm: 14,
      base: 16,
      lg: 18,
      xl: 20,
      "2xl": 24,
      "3xl": 30,
      "4xl": 36,
      "5xl": 48,
      "6xl": 60,
      "7xl": 72,
      "8xl": 96,
      "9xl": 128
    };
    TAILWIND_FONT_WEIGHT = {
      thin: 100,
      extralight: 200,
      light: 300,
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800,
      black: 900
    };
  }
});

// flint-mcp/src/core/a11y/runner.ts
import _traverse3 from "@babel/traverse";
function registerRules(rules) {
  const existingIds = new Set(registeredRules.map((r) => r.id));
  for (const rule of rules) {
    if (!existingIds.has(rule.id)) {
      registeredRules.push(rule);
      existingIds.add(rule.id);
    }
  }
}
function createContext(options) {
  return {
    filePath: options.filePath,
    headingLevels: [],
    landmarksFound: /* @__PURE__ */ new Set(),
    elementRoles: /* @__PURE__ */ new Map(),
    idToElementMap: /* @__PURE__ */ new Map(),
    labelTargetIds: /* @__PURE__ */ new Set(),
    tokens: options.tokens ?? [],
    colorContext: /* @__PURE__ */ new Map(),
    landmarkInstances: [],
    h1Count: 0,
    totalElements: 0,
    hasPageStructure: false
  };
}
function auditSync(ast, options) {
  const context = createContext(options);
  const allViolations = [];
  const ruleModes = options.ruleModes ?? {};
  const activeRules = registeredRules.filter((rule) => {
    if (ruleModes[rule.id] === "off") return false;
    if (options.criteria && options.criteria.length > 0) {
      if (!options.criteria.includes(rule.wcag)) return false;
    }
    if (options.categories && options.categories.length > 0) {
      if (!options.categories.includes(rule.category)) return false;
    }
    if (options.conformanceLevel) {
      if (options.conformanceLevel === "A" && rule.level !== "A") return false;
      if (options.conformanceLevel === "AA" && rule.level === "AAA") return false;
    }
    return true;
  });
  const advisoryRuleIds = new Set(
    Object.entries(ruleModes).filter(([, mode]) => mode === "advisory").map(([id]) => id)
  );
  const elementVisitorRules = activeRules.filter((r) => r.visitElement != null);
  const documentRules = activeRules.filter((r) => r.auditDocument != null);
  let elementIndex = 0;
  traverse3(ast, {
    JSXElement(path9) {
      const opening = path9.node.openingElement;
      const tag = getTagName(path9);
      if (!tag) return;
      elementIndex++;
      context.totalElements++;
      const PAGE_STRUCTURE_TAGS = /* @__PURE__ */ new Set(["html", "body", "header", "footer", "section", "article", "aside", "main", "nav"]);
      if (PAGE_STRUCTURE_TAGS.has(tag) || /^h[1-6]$/.test(tag)) {
        context.hasPageStructure = true;
      }
      const flintId = getFlintId2(opening, `${tag}-${elementIndex}`);
      const headingMatch = /^h([1-6])$/.exec(tag);
      if (headingMatch) {
        const level = parseInt(headingMatch[1], 10);
        context.headingLevels.push(level);
        if (level === 1) context.h1Count++;
      }
      const explicitRole = getExplicitRole(opening);
      const implicitRole = getImplicitRole(tag);
      const effectiveRole = explicitRole ?? implicitRole;
      if (effectiveRole) {
        context.elementRoles.set(flintId, effectiveRole);
        const landmarkRoles = /* @__PURE__ */ new Set(["main", "navigation", "banner", "contentinfo", "complementary", "search", "form", "region"]);
        if (landmarkRoles.has(effectiveRole)) {
          context.landmarksFound.add(effectiveRole);
          const labelAttr = getAttributeStringValue(opening, "aria-label") ?? getAttributeStringValue(opening, "aria-labelledby");
          context.landmarkInstances.push({
            role: effectiveRole,
            label: labelAttr,
            elementId: flintId
          });
        }
      }
      const idVal = getAttributeStringValue(opening, "id");
      if (idVal) {
        context.idToElementMap.set(idVal, flintId);
      }
      const classNameAttr = getAttributeStringValue(opening, "className");
      if (classNameAttr) {
        const classes = classNameAttr.split(/\s+/).filter(Boolean);
        const colors = extractColorContext(classes);
        context.colorContext.set(flintId, colors);
      }
      for (const rule of elementVisitorRules) {
        try {
          const violation = rule.visitElement(path9, context);
          if (violation) {
            const taxEntry = getErrorEntryByRuleId(violation.ruleId);
            const base = taxEntry !== null ? { ...violation, explanation: taxEntry.explanation, recovery: taxEntry.recovery } : violation;
            allViolations.push(
              advisoryRuleIds.has(base.ruleId) ? { ...base, severity: "advisory" } : base
            );
          }
        } catch {
        }
      }
    }
  });
  for (const rule of documentRules) {
    try {
      const violations = rule.auditDocument(context);
      for (const violation of violations) {
        const taxEntry = getErrorEntryByRuleId(violation.ruleId);
        const base = taxEntry !== null ? { ...violation, explanation: taxEntry.explanation, recovery: taxEntry.recovery } : violation;
        allViolations.push(
          advisoryRuleIds.has(base.ruleId) ? { ...base, severity: "advisory" } : base
        );
      }
    } catch {
    }
  }
  return buildResult(options.filePath, activeRules, allViolations);
}
function buildResult(filePath, activeRules, violations) {
  const totalRules = activeRules.length;
  const failedRuleIds = new Set(violations.map((v) => v.ruleId));
  const passed = totalRules - failedRuleIds.size;
  const failed = failedRuleIds.size;
  const compliancePercent = totalRules === 0 ? 100 : Math.round(passed / totalRules * 100 * 10) / 10;
  const fixableCount = violations.filter((v) => v.fixable).length;
  const criterionMap = /* @__PURE__ */ new Map();
  for (const rule of activeRules) {
    if (!criterionMap.has(rule.wcag)) {
      criterionMap.set(rule.wcag, { violations: [], failedRules: /* @__PURE__ */ new Set() });
    }
  }
  for (const v of violations) {
    const rule = activeRules.find((r) => r.id === v.ruleId);
    if (!rule) continue;
    const entry = criterionMap.get(rule.wcag);
    if (!entry) continue;
    entry.violations.push(v);
    entry.failedRules.add(v.ruleId);
  }
  const criterionResults = [];
  for (const [criterion, data] of criterionMap.entries()) {
    const meta = CRITERION_NAMES[criterion];
    criterionResults.push({
      criterion,
      name: meta?.name ?? criterion,
      level: meta?.level ?? "A",
      passed: data.failedRules.size === 0,
      failedRules: Array.from(data.failedRules),
      violationCount: data.violations.length
    });
  }
  criterionResults.sort((a, b) => a.criterion.localeCompare(b.criterion));
  return {
    filePath,
    totalRules,
    passed,
    failed,
    compliancePercent,
    violations,
    criterionResults,
    fixableCount,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function getRegisteredRules() {
  return [...registeredRules];
}
var traverse3, CRITERION_NAMES, registeredRules;
var init_runner = __esm({
  "flint-mcp/src/core/a11y/runner.ts"() {
    "use strict";
    init_helpers();
    init_contrast_utils();
    init_errorTaxonomy();
    traverse3 = typeof _traverse3 === "function" ? _traverse3 : _traverse3.default;
    CRITERION_NAMES = {
      "1.1.1": { name: "Non-text Content", level: "A" },
      "1.3.1": { name: "Info and Relationships", level: "A" },
      "1.3.5": { name: "Identify Input Purpose", level: "AA" },
      "1.4.3": { name: "Contrast (Minimum)", level: "AA" },
      "1.4.6": { name: "Contrast (Enhanced)", level: "AAA" },
      "1.4.11": { name: "Non-text Contrast", level: "AA" },
      "2.1.1": { name: "Keyboard", level: "A" },
      "2.1.2": { name: "No Keyboard Trap", level: "A" },
      "2.4.1": { name: "Bypass Blocks", level: "A" },
      "2.4.2": { name: "Page Titled", level: "A" },
      "2.4.3": { name: "Focus Order", level: "A" },
      "2.4.4": { name: "Link Purpose (In Context)", level: "A" },
      "2.4.6": { name: "Headings and Labels", level: "AA" },
      "2.4.7": { name: "Focus Visible", level: "AA" },
      "2.4.10": { name: "Section Headings", level: "AAA" },
      "3.1.1": { name: "Language of Page", level: "A" },
      "3.3.1": { name: "Error Identification", level: "A" },
      "3.3.2": { name: "Labels or Instructions", level: "A" },
      "3.3.3": { name: "Error Suggestion", level: "AA" },
      "3.3.4": { name: "Error Prevention (Legal, Financial, Data)", level: "AA" },
      "4.1.2": { name: "Name, Role, Value", level: "A" },
      "4.1.3": { name: "Status Messages", level: "AA" }
    };
    registeredRules = [];
  }
});

// flint-mcp/src/core/a11y/rules/names-labels.ts
var FILENAME_PATTERN, GENERIC_LINK_TEXTS, rule001, rule002, rule003, rule004, rule005, rule006, rule011, rule012, rule013, rule014, rule018, namesLabelsRules;
var init_names_labels = __esm({
  "flint-mcp/src/core/a11y/rules/names-labels.ts"() {
    "use strict";
    init_helpers();
    FILENAME_PATTERN = /\.(png|jpg|jpeg|gif|svg|webp|avif|bmp|ico)$/i;
    GENERIC_LINK_TEXTS = /* @__PURE__ */ new Set([
      "click here",
      "here",
      "read more",
      "more",
      "learn more",
      "link",
      "this link",
      "click",
      "details",
      "info",
      "information"
    ]);
    rule001 = {
      id: "A11Y-001",
      name: "Image Missing Alt Text",
      wcag: "1.1.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<img> elements must have an alt attribute.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "img") return null;
        const opening = path9.node.openingElement;
        const altAttr = getJsxAttr(opening, "alt");
        if (altAttr !== void 0) return null;
        const elementId = getFlintId2(opening, `img-missing-alt`);
        return {
          ruleId: "A11Y-001",
          elementId,
          message: 'A11Y-001: <img> is missing an `alt` attribute. Add alt="" for decorative images or a descriptive string for informational ones.',
          severity: "critical",
          wcag: "1.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added alt="" to decorative <img>.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "alt",
                value: ""
              }
            }
          ]
        };
      }
    };
    rule002 = {
      id: "A11Y-002",
      name: "Button Missing Accessible Name",
      wcag: "4.1.2",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<button> elements must have an accessible name.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "button") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasTitle = hasNonEmptyAttr(opening, "title");
        const hasText = hasTextChildren(path9);
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        if (hasAriaLabel || hasTitle || hasText || hasAriaLabelledBy) return null;
        const elementId = getFlintId2(opening, "button-no-name");
        return {
          ruleId: "A11Y-002",
          elementId,
          message: 'A11Y-002: <button> has no accessible name. Add text content, aria-label="\u2026", or title="\u2026".',
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder aria-label to <button>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-label",
                value: "[NEEDS LABEL]"
              }
            }
          ]
        };
      }
    };
    rule003 = {
      id: "A11Y-003",
      name: "Link Missing Accessible Name",
      wcag: "4.1.2",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<a> elements must have an accessible name.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "a") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasTitle = hasNonEmptyAttr(opening, "title");
        const hasText = hasTextChildren(path9);
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        if (hasAriaLabel || hasTitle || hasText || hasAriaLabelledBy) return null;
        const elementId = getFlintId2(opening, "a-no-name");
        return {
          ruleId: "A11Y-003",
          elementId,
          message: 'A11Y-003: <a> has no accessible name. Add text content, aria-label="\u2026", or title="\u2026".',
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder aria-label to <a>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-label",
                value: "[NEEDS LABEL]"
              }
            }
          ]
        };
      }
    };
    rule004 = {
      id: "A11Y-004",
      name: "Input Missing Label",
      wcag: "1.3.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<input> elements must have a programmatic label.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasId = hasNonEmptyAttr(opening, "id");
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasTitle = hasNonEmptyAttr(opening, "title");
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        if (hasId || hasAriaLabel || hasTitle || hasAriaLabelledBy) return null;
        const elementId = getFlintId2(opening, "input-no-label");
        return {
          ruleId: "A11Y-004",
          elementId,
          message: 'A11Y-004: <input> has no programmatic label. Add id="\u2026" (+ a matching <label htmlFor>), aria-label="\u2026", or aria-labelledby="\u2026".',
          severity: "critical",
          wcag: "1.3.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder aria-label to <input>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-label",
                value: "[NEEDS LABEL]"
              }
            }
          ]
        };
      }
    };
    rule005 = {
      id: "A11Y-005",
      name: "Select Missing Label",
      wcag: "1.3.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<select> elements must have an accessible label.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "select") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        const hasTitle = hasNonEmptyAttr(opening, "title");
        if (hasAriaLabel || hasAriaLabelledBy || hasTitle) return null;
        const elementId = getFlintId2(opening, "select-no-label");
        return {
          ruleId: "A11Y-005",
          elementId,
          message: 'A11Y-005: <select> has no accessible label. Add aria-label="\u2026", aria-labelledby="\u2026", or pair with a <label htmlFor>.',
          severity: "critical",
          wcag: "1.3.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder aria-label to <select>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-label",
                value: "[NEEDS LABEL]"
              }
            }
          ]
        };
      }
    };
    rule006 = {
      id: "A11Y-006",
      name: "Textarea Missing Label",
      wcag: "1.3.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<textarea> elements must have an accessible label.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "textarea") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        const hasTitle = hasNonEmptyAttr(opening, "title");
        if (hasAriaLabel || hasAriaLabelledBy || hasTitle) return null;
        const elementId = getFlintId2(opening, "textarea-no-label");
        return {
          ruleId: "A11Y-006",
          elementId,
          message: 'A11Y-006: <textarea> has no accessible label. Add aria-label="\u2026", aria-labelledby="\u2026", or pair with a <label htmlFor>.',
          severity: "critical",
          wcag: "1.3.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder aria-label to <textarea>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-label",
                value: "[NEEDS LABEL]"
              }
            }
          ]
        };
      }
    };
    rule011 = {
      id: "A11Y-011",
      name: "Image Alt Is Filename",
      wcag: "1.1.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<img> alt attribute must not be a filename.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "img") return null;
        const opening = path9.node.openingElement;
        const altVal = getAttributeValue(getJsxAttr(opening, "alt"));
        if (altVal === null) return null;
        if (!altVal) return null;
        if (!FILENAME_PATTERN.test(altVal.trim())) return null;
        const elementId = getFlintId2(opening, "img-filename-alt");
        return {
          ruleId: "A11Y-011",
          elementId,
          message: `A11Y-011: <img> alt="${altVal}" looks like a filename. Replace with a descriptive string or use alt="" for decorative images.`,
          severity: "critical",
          wcag: "1.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Replaced filename alt with empty alt (decorative).",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "alt",
                value: ""
              }
            }
          ]
        };
      }
    };
    rule012 = {
      id: "A11Y-012",
      name: "SVG Missing Accessible Name",
      wcag: "1.1.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: '<svg> elements must have a <title>, aria-label, or role="img" + aria-label.',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "svg") return null;
        const opening = path9.node.openingElement;
        const ariaHidden = getAttributeStringValue(opening, "aria-hidden");
        if (ariaHidden === "true") return null;
        const ariaLabelAttr = getJsxAttr(opening, "aria-label");
        if (ariaLabelAttr?.type === "JSXAttribute" && ariaLabelAttr.value?.type === "JSXExpressionContainer") return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasTitle = path9.node.children.some(
          (child) => child.type === "JSXElement" && child.openingElement.name.type === "JSXIdentifier" && child.openingElement.name.name.toLowerCase() === "title"
        );
        if (hasAriaLabel || hasTitle) return null;
        const elementId = getFlintId2(opening, "svg-no-name");
        return {
          ruleId: "A11Y-012",
          elementId,
          message: 'A11Y-012: <svg> has no accessible name. Add aria-hidden="true" for decorative SVGs, or aria-label="\u2026" / <title> for informational ones.',
          severity: "critical",
          wcag: "1.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added aria-hidden="true" to decorative <svg>.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-hidden",
                value: "true"
              }
            }
          ]
        };
      }
    };
    rule013 = {
      id: "A11Y-013",
      name: "Image Input Missing Alt",
      wcag: "1.1.1",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: '<input type="image"> must have an alt attribute.',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        const typeVal = getAttributeStringValue(opening, "type");
        if (typeVal !== "image") return null;
        const altAttr = getJsxAttr(opening, "alt");
        if (altAttr !== void 0) return null;
        const elementId = getFlintId2(opening, "input-image-no-alt");
        return {
          ruleId: "A11Y-013",
          elementId,
          message: 'A11Y-013: <input type="image"> is missing an `alt` attribute. Add alt="" for decorative inputs or a descriptive string for informational ones.',
          severity: "critical",
          wcag: "1.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added alt="" to <input type="image">.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "alt",
                value: ""
              }
            }
          ]
        };
      }
    };
    rule014 = {
      id: "A11Y-014",
      name: "Generic Link Text",
      wcag: "2.4.4",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: 'Link text must not be generic ("click here", "read more", etc.).',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "a") return null;
        const opening = path9.node.openingElement;
        if (hasNonEmptyAttr(opening, "aria-label")) return null;
        if (hasDynamicLabel(opening)) return null;
        const textContent = path9.node.children.filter((c) => c.type === "JSXText").map((c) => c.value.trim()).join(" ").trim().toLowerCase();
        if (!textContent) return null;
        if (!GENERIC_LINK_TEXTS.has(textContent)) return null;
        const elementId = getFlintId2(opening, "a-generic-text");
        return {
          ruleId: "A11Y-014",
          elementId,
          message: `A11Y-014: <a> link text "${textContent}" is generic and does not describe the link destination. Replace with descriptive text or add aria-label="\u2026" with context.`,
          severity: "critical",
          wcag: "2.4.4",
          fixable: false
        };
      }
    };
    rule018 = {
      id: "A11Y-018",
      name: "IFrame Missing Title",
      wcag: "4.1.2",
      level: "A",
      category: "names-labels",
      severity: "critical",
      description: "<iframe> elements must have a title attribute describing the embedded content.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "iframe") return null;
        const opening = path9.node.openingElement;
        const titleAttr = getJsxAttr(opening, "title");
        if (titleAttr?.type === "JSXAttribute" && titleAttr.value?.type === "JSXExpressionContainer") return null;
        if (hasNonEmptyAttr(opening, "title")) return null;
        const elementId = getFlintId2(opening, "iframe-no-title");
        return {
          ruleId: "A11Y-018",
          elementId,
          message: 'A11Y-018: <iframe> is missing a title attribute. Screen readers use the title to describe the embedded content to users. Add title="Description of embedded content".',
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added placeholder title to <iframe>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "title",
                value: "[NEEDS TITLE]"
              }
            }
          ]
        };
      }
    };
    namesLabelsRules = [
      rule001,
      rule002,
      rule003,
      rule004,
      rule005,
      rule006,
      rule011,
      rule012,
      rule013,
      rule014,
      rule018
    ];
  }
});

// flint-mcp/src/core/a11y/rules/keyboard.ts
var NON_INTERACTIVE_TAGS, rule007, rule020, MOUSE_ONLY_HANDLERS, KEYBOARD_EQUIVALENTS, rule021, rule022, keyboardRules;
var init_keyboard = __esm({
  "flint-mcp/src/core/a11y/rules/keyboard.ts"() {
    "use strict";
    init_helpers();
    NON_INTERACTIVE_TAGS = /* @__PURE__ */ new Set(["div", "span", "p", "li", "td", "th", "section", "article", "aside", "header", "footer", "main", "nav"]);
    rule007 = {
      id: "A11Y-007",
      name: "Positive TabIndex",
      wcag: "2.4.3",
      level: "A",
      category: "keyboard",
      severity: "critical",
      description: "tabIndex > 0 disrupts the natural tab order.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const tabIndexAttr = getJsxAttr(opening, "tabIndex");
        if (!tabIndexAttr || tabIndexAttr.type !== "JSXAttribute") return null;
        const val = tabIndexAttr.value;
        let numericVal = null;
        if (val?.type === "StringLiteral") {
          numericVal = parseInt(val.value, 10);
        } else if (val?.type === "JSXExpressionContainer" && val.expression.type === "NumericLiteral") {
          numericVal = val.expression.value;
        } else if (val?.type === "JSXExpressionContainer" && val.expression.type === "StringLiteral") {
          numericVal = parseInt(val.expression.value, 10);
        }
        if (numericVal === null || numericVal <= 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-tabindex-positive`);
        return {
          ruleId: "A11Y-007",
          elementId,
          message: `A11Y-007: tabIndex="${numericVal}" disrupts natural tab order. Use tabIndex={0} to include in natural order, or tabIndex={-1} to remove from flow.`,
          severity: "critical",
          wcag: "2.4.3",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Set tabIndex to 0 to restore natural tab order.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "tabIndex",
                value: "0"
              }
            }
          ]
        };
      }
    };
    rule020 = {
      id: "A11Y-020",
      name: "Non-Interactive Element With Click Handler",
      wcag: "2.1.1",
      level: "A",
      category: "keyboard",
      severity: "critical",
      description: "Non-interactive elements (div, span, etc.) with onClick must have role, tabIndex, and onKeyDown for keyboard accessibility.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (!tag || !NON_INTERACTIVE_TAGS.has(tag)) return null;
        const opening = path9.node.openingElement;
        const hasOnClick = hasEventHandler(opening, "onClick");
        if (!hasOnClick) return null;
        const hasRole = hasNonEmptyAttr(opening, "role");
        const hasTabIndex = getJsxAttr(opening, "tabIndex") !== void 0;
        const hasOnKeyDown = hasEventHandler(opening, "onKeyDown");
        const hasOnKeyPress = hasEventHandler(opening, "onKeyPress");
        if (hasRole && hasTabIndex && (hasOnKeyDown || hasOnKeyPress)) return null;
        const elementId = getFlintId2(opening, `${tag}-click-no-keyboard`);
        const missing = [];
        if (!hasRole) missing.push("role");
        if (!hasTabIndex) missing.push("tabIndex");
        if (!hasOnKeyDown && !hasOnKeyPress) missing.push("onKeyDown");
        return {
          ruleId: "A11Y-020",
          elementId,
          message: `A11Y-020: <${tag}> has onClick but is missing: ${missing.join(", ")}. Non-interactive elements with click handlers must be keyboard accessible. Add role="button" tabIndex={0} and onKeyDown for keyboard support.`,
          severity: "critical",
          wcag: "2.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added role="button" and tabIndex={0} to make clickable element keyboard accessible.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "role",
                value: "button"
              }
            },
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "tabIndex",
                value: "0"
              }
            }
          ]
        };
      }
    };
    MOUSE_ONLY_HANDLERS = ["onMouseDown", "onMouseUp", "onMouseOver"];
    KEYBOARD_EQUIVALENTS = {
      onMouseDown: "onKeyDown",
      onMouseUp: "onKeyUp",
      onMouseOver: "onFocus"
    };
    rule021 = {
      id: "A11Y-021",
      name: "Mouse-Only Event Handler",
      wcag: "2.1.1",
      level: "A",
      category: "keyboard",
      severity: "critical",
      description: "Mouse-only event handlers must have keyboard equivalents.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const violatingHandlers = [];
        for (const handler of MOUSE_ONLY_HANDLERS) {
          if (!hasEventHandler(opening, handler)) continue;
          const keyboardEquiv = KEYBOARD_EQUIVALENTS[handler];
          if (keyboardEquiv && hasEventHandler(opening, keyboardEquiv)) continue;
          violatingHandlers.push(handler);
        }
        if (violatingHandlers.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-mouse-only`);
        const suggestions = violatingHandlers.map((h) => `${h} \u2192 add ${KEYBOARD_EQUIVALENTS[h]}`).join(", ");
        return {
          ruleId: "A11Y-021",
          elementId,
          message: `A11Y-021: <${tag}> has mouse-only handlers (${violatingHandlers.join(", ")}) without keyboard equivalents. Add keyboard handlers: ${suggestions}.`,
          severity: "critical",
          wcag: "2.1.1",
          fixable: false
        };
      }
    };
    rule022 = {
      id: "A11Y-022",
      name: "Focus Indicator Removed",
      wcag: "2.4.7",
      level: "AA",
      category: "keyboard",
      severity: "critical",
      description: "Elements must not remove the focus indicator via outline: none or outline: 0.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const classNameAttr = getAttributeStringValue(opening, "className");
        if (classNameAttr) {
          const classes = classNameAttr.split(/\s+/);
          const hasFocusOutlineNone = classes.some(
            (c) => c === "outline-none" || c === "focus:outline-none" || c === "outline-0" || c === "focus:outline-0"
          );
          if (hasFocusOutlineNone) {
            const hasFocusReplacement = classes.some(
              (c) => c.startsWith("focus:ring") || c.startsWith("focus:border") || c.startsWith("focus:shadow") || c.startsWith("focus-visible:")
            );
            if (!hasFocusReplacement) {
              const tag = getTagName(path9) ?? "element";
              const elementId = getFlintId2(opening, `${tag}-no-focus-indicator`);
              return {
                ruleId: "A11Y-022",
                elementId,
                message: `A11Y-022: <${tag}> removes focus indicator (outline-none) without a replacement. Add focus:ring-* or focus-visible:* styles to provide a visible focus indicator.`,
                severity: "critical",
                wcag: "2.4.7",
                fixable: false
              };
            }
          }
        }
        const styleAttr = getJsxAttr(opening, "style");
        if (styleAttr?.type === "JSXAttribute" && styleAttr.value) {
          if (styleAttr.value.type === "StringLiteral") {
            const style = styleAttr.value.value.toLowerCase();
            if (style.includes("outline") && (style.includes("none") || style.includes(": 0"))) {
              const tag = getTagName(path9) ?? "element";
              const elementId = getFlintId2(opening, `${tag}-style-no-focus`);
              return {
                ruleId: "A11Y-022",
                elementId,
                message: `A11Y-022: <${tag}> may remove focus indicator via inline style. Ensure a visible focus indicator is provided.`,
                severity: "critical",
                wcag: "2.4.7",
                fixable: false
              };
            }
          }
        }
        return null;
      }
    };
    keyboardRules = [rule007, rule020, rule021, rule022];
  }
});

// flint-mcp/src/core/a11y/rules/structure.ts
var rule008, rule009, rule010, rule015, rule016, rule017, structureRules;
var init_structure = __esm({
  "flint-mcp/src/core/a11y/rules/structure.ts"() {
    "use strict";
    init_helpers();
    rule008 = {
      id: "A11Y-008",
      name: "Table Missing Accessible Summary",
      wcag: "1.3.1",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "<table> elements must have an accessible summary.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "table") return null;
        const opening = path9.node.openingElement;
        if (hasDynamicLabel(opening)) return null;
        const hasAriaLabel = hasNonEmptyAttr(opening, "aria-label");
        const hasAriaLabelledBy = hasNonEmptyAttr(opening, "aria-labelledby");
        const hasCaption = hasDirectChildTag(path9, "caption");
        if (hasAriaLabel || hasAriaLabelledBy || hasCaption) return null;
        const elementId = getFlintId2(opening, "table-no-summary");
        return {
          ruleId: "A11Y-008",
          elementId,
          message: 'A11Y-008: <table> has no accessible summary. Add a <caption> child, aria-label="\u2026", or aria-labelledby="\u2026".',
          severity: "critical",
          wcag: "1.3.1",
          fixable: false
        };
      }
    };
    rule009 = {
      id: "A11Y-009",
      name: "HTML Missing Lang Attribute",
      wcag: "3.1.1",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "<html> must have a lang attribute.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "html") return null;
        const opening = path9.node.openingElement;
        const langAttr = getJsxAttr(opening, "lang");
        if (langAttr?.type === "JSXAttribute" && langAttr.value?.type === "JSXExpressionContainer") return null;
        const hasLang = hasNonEmptyAttr(opening, "lang");
        if (hasLang) return null;
        const elementId = getFlintId2(opening, "html-no-lang");
        return {
          ruleId: "A11Y-009",
          elementId,
          message: 'A11Y-009: <html> is missing a `lang` attribute. Add lang="en" (or appropriate BCP 47 language tag) for screen reader language detection.',
          severity: "critical",
          wcag: "3.1.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added lang="en" to <html>.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "lang",
                value: "en"
              }
            }
          ]
        };
      }
    };
    rule010 = {
      id: "A11Y-010",
      name: "Heading Level Skipped",
      wcag: "1.3.1",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "Heading levels must not be skipped.",
      visitElement(path9, context) {
        const tag = getTagName(path9);
        if (!tag) return null;
        const headingMatch = /^h([1-6])$/.exec(tag);
        if (!headingMatch) return null;
        const level = parseInt(headingMatch[1], 10);
        const prevLevels = context.headingLevels.slice(0, -1);
        const last = prevLevels[prevLevels.length - 1] ?? 0;
        if (level <= last + 1) return null;
        const opening = path9.node.openingElement;
        const elementId = getFlintId2(opening, `${tag}-level-skip`);
        return {
          ruleId: "A11Y-010",
          elementId,
          message: `A11Y-010: Heading <${tag}> skips level. Previous heading was <h${last}>. Heading levels must not be skipped \u2014 use sequential levels for screen readers.`,
          severity: "critical",
          wcag: "1.3.1",
          fixable: false
        };
      }
    };
    rule015 = {
      id: "A11Y-015",
      name: "List Contains Non-List-Item Children",
      wcag: "1.3.1",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "<ul> and <ol> direct children must be <li> elements.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "ul" && tag !== "ol") return null;
        const invalidChildren = path9.node.children.filter((child) => {
          if (child.type === "JSXText" && !/\S/.test(child.value)) return false;
          if (child.type === "JSXExpressionContainer") return false;
          if (child.type === "JSXSpreadChild") return false;
          if (child.type === "JSXFragment") return false;
          if (child.type !== "JSXElement") return false;
          const childTag = child.openingElement.name;
          if (childTag.type !== "JSXIdentifier") return false;
          const childTagName = childTag.name.toLowerCase();
          return childTagName !== "li";
        });
        if (invalidChildren.length === 0) return null;
        const opening = path9.node.openingElement;
        const elementId = getFlintId2(opening, `${tag}-invalid-children`);
        return {
          ruleId: "A11Y-015",
          elementId,
          message: `A11Y-015: <${tag}> has non-<li> direct children. All direct children of <ul> and <ol> must be <li> elements.`,
          severity: "critical",
          wcag: "1.3.1",
          fixable: false
        };
      }
    };
    rule016 = {
      id: "A11Y-016",
      name: "Definition List Contains Invalid Children",
      wcag: "1.3.1",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "<dl> direct children must be <dt> or <dd> elements.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "dl") return null;
        const invalidChildren = path9.node.children.filter((child) => {
          if (child.type === "JSXText" && !/\S/.test(child.value)) return false;
          if (child.type === "JSXExpressionContainer") return false;
          if (child.type === "JSXSpreadChild") return false;
          if (child.type === "JSXFragment") return false;
          if (child.type !== "JSXElement") return false;
          const childTag = child.openingElement.name;
          if (childTag.type !== "JSXIdentifier") return false;
          const childTagName = childTag.name.toLowerCase();
          return childTagName !== "dt" && childTagName !== "dd" && childTagName !== "div";
        });
        if (invalidChildren.length === 0) return null;
        const opening = path9.node.openingElement;
        const elementId = getFlintId2(opening, "dl-invalid-children");
        return {
          ruleId: "A11Y-016",
          elementId,
          message: "A11Y-016: <dl> has children that are not <dt> or <dd>. Definition lists must only contain <dt> and <dd> elements as direct children.",
          severity: "critical",
          wcag: "1.3.1",
          fixable: false
        };
      }
    };
    rule017 = {
      id: "A11Y-017",
      name: "Page Must Have Exactly One H1",
      wcag: "2.4.2",
      level: "A",
      category: "structure",
      severity: "critical",
      description: "The page must have exactly one <h1> element.",
      auditDocument(context) {
        if (context.h1Count === 1) return [];
        if (context.h1Count === 0) return [];
        return [
          {
            ruleId: "A11Y-017",
            elementId: "document",
            message: `A11Y-017: Document has ${context.h1Count} <h1> elements. There must be exactly one <h1> per page for proper document structure.`,
            severity: "critical",
            wcag: "2.4.2",
            fixable: false
          }
        ];
      }
    };
    structureRules = [
      rule008,
      rule009,
      rule010,
      rule015,
      rule016,
      rule017
    ];
  }
});

// flint-mcp/src/core/a11y/rules/aria.ts
var VALID_ARIA_ROLES, REQUIRED_CHILDREN, REQUIRED_PARENT, REQUIRED_ATTRS, VALID_ARIA_ATTRS, rule030, rule031, rule032, rule033, rule034, ARIA_VALUE_TYPES, BOOLEAN_VALUES, TRISTATE_VALUES, ARIA_CURRENT_VALUES, ARIA_INVALID_VALUES, rule035, rule036, rule037, INTERACTIVE_TAGS, rule038, ariaRules;
var init_aria = __esm({
  "flint-mcp/src/core/a11y/rules/aria.ts"() {
    "use strict";
    init_helpers();
    VALID_ARIA_ROLES = /* @__PURE__ */ new Set([
      "alert",
      "alertdialog",
      "application",
      "article",
      "banner",
      "blockquote",
      "button",
      "caption",
      "cell",
      "checkbox",
      "code",
      "columnheader",
      "combobox",
      "complementary",
      "contentinfo",
      "definition",
      "deletion",
      "dialog",
      "directory",
      "document",
      "emphasis",
      "feed",
      "figure",
      "form",
      "generic",
      "grid",
      "gridcell",
      "group",
      "heading",
      "img",
      "insertion",
      "link",
      "list",
      "listbox",
      "listitem",
      "log",
      "main",
      "mark",
      "marquee",
      "math",
      "menu",
      "menubar",
      "menuitem",
      "menuitemcheckbox",
      "menuitemradio",
      "meter",
      "navigation",
      "none",
      "note",
      "option",
      "paragraph",
      "presentation",
      "progressbar",
      "radio",
      "radiogroup",
      "region",
      "row",
      "rowgroup",
      "rowheader",
      "scrollbar",
      "search",
      "searchbox",
      "separator",
      "slider",
      "spinbutton",
      "status",
      "strong",
      "subscript",
      "superscript",
      "switch",
      "tab",
      "table",
      "tablist",
      "tabpanel",
      "term",
      "textbox",
      "time",
      "timer",
      "toolbar",
      "tooltip",
      "tree",
      "treegrid",
      "treeitem"
    ]);
    REQUIRED_CHILDREN = {
      list: ["listitem"],
      listbox: ["option"],
      menu: ["menuitem", "menuitemcheckbox", "menuitemradio"],
      menubar: ["menuitem", "menuitemcheckbox", "menuitemradio"],
      radiogroup: ["radio"],
      row: ["cell", "columnheader", "gridcell", "rowheader"],
      rowgroup: ["row"],
      table: ["row", "rowgroup"],
      tablist: ["tab"],
      tree: ["treeitem"],
      treegrid: ["row"]
    };
    REQUIRED_PARENT = {
      caption: ["grid", "table", "treegrid"],
      cell: ["row"],
      columnheader: ["row"],
      gridcell: ["row"],
      listitem: ["list", "directory"],
      menuitem: ["menu", "menubar"],
      menuitemcheckbox: ["menu", "menubar"],
      menuitemradio: ["menu", "menubar"],
      option: ["listbox"],
      row: ["grid", "rowgroup", "table", "treegrid"],
      rowheader: ["row"],
      tab: ["tablist"],
      treeitem: ["group", "tree"]
    };
    REQUIRED_ATTRS = {
      checkbox: [{ attr: "aria-checked", defaultValue: "false" }],
      combobox: [{ attr: "aria-expanded", defaultValue: "false" }],
      heading: [{ attr: "aria-level", defaultValue: "2" }],
      meter: [{ attr: "aria-valuenow", defaultValue: "0" }],
      option: [{ attr: "aria-selected", defaultValue: "false" }],
      radio: [{ attr: "aria-checked", defaultValue: "false" }],
      scrollbar: [
        { attr: "aria-valuenow", defaultValue: "0" },
        { attr: "aria-valuemin", defaultValue: "0" },
        { attr: "aria-valuemax", defaultValue: "100" },
        { attr: "aria-orientation", defaultValue: "vertical" },
        { attr: "aria-controls", defaultValue: "" }
      ],
      separator: [{ attr: "aria-valuenow", defaultValue: "0" }],
      slider: [
        { attr: "aria-valuenow", defaultValue: "0" },
        { attr: "aria-valuemin", defaultValue: "0" },
        { attr: "aria-valuemax", defaultValue: "100" }
      ],
      spinbutton: [{ attr: "aria-valuenow", defaultValue: "0" }],
      switch: [{ attr: "aria-checked", defaultValue: "false" }],
      tab: [{ attr: "aria-selected", defaultValue: "false" }]
    };
    VALID_ARIA_ATTRS = /* @__PURE__ */ new Set([
      "aria-activedescendant",
      "aria-atomic",
      "aria-autocomplete",
      "aria-braillelabel",
      "aria-brailleroledescription",
      "aria-busy",
      "aria-checked",
      "aria-colcount",
      "aria-colindex",
      "aria-colindextext",
      "aria-colspan",
      "aria-controls",
      "aria-current",
      "aria-describedby",
      "aria-description",
      "aria-details",
      "aria-disabled",
      "aria-dropeffect",
      "aria-errormessage",
      "aria-expanded",
      "aria-flowto",
      "aria-grabbed",
      "aria-haspopup",
      "aria-hidden",
      "aria-invalid",
      "aria-keyshortcuts",
      "aria-label",
      "aria-labelledby",
      "aria-level",
      "aria-live",
      "aria-modal",
      "aria-multiline",
      "aria-multiselectable",
      "aria-orientation",
      "aria-owns",
      "aria-placeholder",
      "aria-posinset",
      "aria-pressed",
      "aria-readonly",
      "aria-relevant",
      "aria-required",
      "aria-roledescription",
      "aria-rowcount",
      "aria-rowindex",
      "aria-rowindextext",
      "aria-rowspan",
      "aria-selected",
      "aria-setsize",
      "aria-sort",
      "aria-valuemax",
      "aria-valuemin",
      "aria-valuenow",
      "aria-valuetext"
    ]);
    rule030 = {
      id: "A11Y-030",
      name: "Invalid ARIA Role",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "role attribute must be a valid WAI-ARIA role.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleAttr = getJsxAttr(opening, "role");
        if (!roleAttr) return null;
        if (roleAttr.type !== "JSXAttribute") return null;
        const roleVal = getAttributeValue(roleAttr);
        if (roleVal === null) return null;
        const roles = roleVal.trim().split(/\s+/);
        const invalidRoles = roles.filter((r) => r && !VALID_ARIA_ROLES.has(r));
        if (invalidRoles.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-invalid-role`);
        return {
          ruleId: "A11Y-030",
          elementId,
          message: `A11Y-030: role="${roleVal}" contains invalid WAI-ARIA role(s): ${invalidRoles.join(", ")}. Use a valid WAI-ARIA 1.2 role.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Removed invalid role attribute.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "role",
                value: null
              }
            }
          ]
        };
      }
    };
    rule031 = {
      id: "A11Y-031",
      name: "Required ARIA Children Missing",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "Elements with certain ARIA roles must have required child roles present.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (!roleVal) return null;
        const requiredChildren = REQUIRED_CHILDREN[roleVal.trim()];
        if (!requiredChildren) return null;
        const hasRequiredChild = path9.node.children.some((child) => {
          if (child.type !== "JSXElement") return false;
          const childOpening = child.openingElement;
          const childRole = getAttributeValue(
            childOpening.attributes.find(
              (a) => a.type === "JSXAttribute" && a.name.type === "JSXIdentifier" && a.name.name === "role"
            )
          );
          return childRole && requiredChildren.includes(childRole.trim());
        });
        if (hasRequiredChild) return null;
        const hasDynamicChildren = path9.node.children.some(
          (c) => c.type === "JSXExpressionContainer"
        );
        if (hasDynamicChildren) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-missing-required-children`);
        return {
          ruleId: "A11Y-031",
          elementId,
          message: `A11Y-031: role="${roleVal}" requires child elements with role="${requiredChildren.join('" or "')}" but none were found.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: false
        };
      }
    };
    rule032 = {
      id: "A11Y-032",
      name: "Element Outside Required ARIA Parent",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "Elements with certain ARIA roles must be inside a required parent role.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (!roleVal) return null;
        const requiredParents = REQUIRED_PARENT[roleVal.trim()];
        if (!requiredParents) return null;
        let parentPath = path9.parentPath;
        let hasRequiredParent = false;
        while (parentPath) {
          if (parentPath.node.type === "JSXElement") {
            const parentOpening = parentPath.node.openingElement;
            const parentRole = getAttributeValue(
              parentOpening.attributes.find(
                (a) => a.type === "JSXAttribute" && a.name.type === "JSXIdentifier" && a.name.name === "role"
              )
            );
            if (parentRole && requiredParents.includes(parentRole.trim())) {
              hasRequiredParent = true;
              break;
            }
          }
          const next = parentPath.parentPath;
          if (!next) break;
          parentPath = next;
        }
        if (hasRequiredParent) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-wrong-parent`);
        return {
          ruleId: "A11Y-032",
          elementId,
          message: `A11Y-032: role="${roleVal}" must be inside an element with role="${requiredParents.join('" or "')}".`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: false
        };
      }
    };
    rule033 = {
      id: "A11Y-033",
      name: "Required ARIA Attribute Missing",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "Elements with certain ARIA roles must have required ARIA attributes.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (!roleVal) return null;
        const requiredAttrs = REQUIRED_ATTRS[roleVal.trim()];
        if (!requiredAttrs) return null;
        const missingAttrs = [];
        for (const spec of requiredAttrs) {
          const attr = getJsxAttr(opening, spec.attr);
          if (!attr) {
            missingAttrs.push(spec);
          }
        }
        if (missingAttrs.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-missing-required-attrs`);
        const missing = missingAttrs.map((s) => s.attr).join(", ");
        return {
          ruleId: "A11Y-033",
          elementId,
          message: `A11Y-033: role="${roleVal}" requires attributes: ${missing}. Add the required ARIA attributes to fully describe the widget state.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        const roleMatch = /role="([^"]+)"/.exec(violation.message);
        const role = roleMatch?.[1];
        if (!role) return null;
        const requiredAttrs = REQUIRED_ATTRS[role];
        if (!requiredAttrs) return null;
        return {
          description: `Added required ARIA attributes for role="${role}".`,
          mutations: requiredAttrs.map((spec) => ({
            type: "updateProp",
            args: {
              nodeId: violation.elementId,
              propName: spec.attr,
              value: spec.defaultValue
            }
          }))
        };
      }
    };
    rule034 = {
      id: "A11Y-034",
      name: "Invalid ARIA Attribute Name",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "ARIA attribute names must be valid WAI-ARIA attributes.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const invalidAttrs = [];
        for (const attr of opening.attributes) {
          if (attr.type !== "JSXAttribute") continue;
          if (attr.name.type !== "JSXIdentifier") continue;
          const name = attr.name.name;
          if (!name.startsWith("aria-")) continue;
          if (!VALID_ARIA_ATTRS.has(name)) {
            invalidAttrs.push(name);
          }
        }
        if (invalidAttrs.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-invalid-aria-attr`);
        return {
          ruleId: "A11Y-034",
          elementId,
          message: `A11Y-034: <${tag}> has invalid ARIA attribute(s): ${invalidAttrs.join(", ")}. Check for typos \u2014 common errors: "aria-lable" \u2192 "aria-label", "aria-labelby" \u2192 "aria-labelledby".`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        const attrMatch = /invalid ARIA attribute\(s\): ([^\n.]+)\./.exec(violation.message);
        if (!attrMatch) return null;
        const invalidAttrs = attrMatch[1].split(",").map((s) => s.trim());
        return {
          description: `Removed invalid ARIA attribute(s): ${invalidAttrs.join(", ")}.`,
          mutations: invalidAttrs.map((attrName) => ({
            type: "updateProp",
            args: {
              nodeId: violation.elementId,
              propName: attrName,
              value: null
            }
          }))
        };
      }
    };
    ARIA_VALUE_TYPES = {
      "aria-atomic": "boolean",
      "aria-busy": "boolean",
      "aria-checked": "tristate",
      "aria-current": "token",
      // false | true | page | step | location | date | time
      "aria-disabled": "boolean",
      "aria-expanded": "boolean",
      "aria-grabbed": "boolean",
      "aria-hidden": "boolean",
      "aria-invalid": "token",
      // false | true | grammar | spelling
      "aria-modal": "boolean",
      "aria-multiline": "boolean",
      "aria-multiselectable": "boolean",
      "aria-pressed": "tristate",
      "aria-readonly": "boolean",
      "aria-required": "boolean",
      "aria-selected": "boolean"
    };
    BOOLEAN_VALUES = /* @__PURE__ */ new Set(["true", "false"]);
    TRISTATE_VALUES = /* @__PURE__ */ new Set(["true", "false", "mixed", "undefined"]);
    ARIA_CURRENT_VALUES = /* @__PURE__ */ new Set(["false", "true", "page", "step", "location", "date", "time"]);
    ARIA_INVALID_VALUES = /* @__PURE__ */ new Set(["false", "true", "grammar", "spelling"]);
    rule035 = {
      id: "A11Y-035",
      name: "Invalid ARIA Attribute Value",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "ARIA attribute values must match allowed types.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const violations = [];
        for (const attr of opening.attributes) {
          if (attr.type !== "JSXAttribute") continue;
          if (attr.name.type !== "JSXIdentifier") continue;
          const name = attr.name.name;
          if (!name.startsWith("aria-")) continue;
          const val = getAttributeValue(attr);
          if (val === null) continue;
          const valueType = ARIA_VALUE_TYPES[name];
          if (!valueType) continue;
          if (valueType === "boolean" && !BOOLEAN_VALUES.has(val)) {
            violations.push(`${name}="${val}" (must be "true" or "false")`);
          } else if (valueType === "tristate" && !TRISTATE_VALUES.has(val)) {
            violations.push(`${name}="${val}" (must be "true", "false", "mixed", or "undefined")`);
          } else if (name === "aria-current" && !ARIA_CURRENT_VALUES.has(val)) {
            violations.push(`${name}="${val}" (must be page | step | location | date | time | true | false)`);
          } else if (name === "aria-invalid" && !ARIA_INVALID_VALUES.has(val)) {
            violations.push(`${name}="${val}" (must be true | false | grammar | spelling)`);
          }
        }
        if (violations.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-invalid-aria-value`);
        return {
          ruleId: "A11Y-035",
          elementId,
          message: `A11Y-035: <${tag}> has invalid ARIA attribute value(s): ${violations.join("; ")}.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: false
        };
      }
    };
    rule036 = {
      id: "A11Y-036",
      name: "Aria-Hidden On Focusable Element",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: 'aria-hidden="true" must not be applied to focusable elements.',
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const ariaHiddenVal = getAttributeValue(getJsxAttr(opening, "aria-hidden"));
        if (ariaHiddenVal !== "true") return null;
        const tag = getTagName(path9) ?? "";
        const isNativeFocusable = isNativelyFocusable(tag);
        const hasTabIndex = getJsxAttr(opening, "tabIndex") !== void 0;
        const hasHref = getJsxAttr(opening, "href") !== void 0;
        if (!isNativeFocusable && !hasTabIndex && !hasHref) return null;
        const tabIndexAttr = getJsxAttr(opening, "tabIndex");
        if (tabIndexAttr?.type === "JSXAttribute") {
          const val = getAttributeValue(tabIndexAttr);
          if (val === "-1") return null;
          const attrVal = tabIndexAttr.value;
          if (attrVal?.type === "JSXExpressionContainer" && attrVal.expression.type === "UnaryExpression" && attrVal.expression.operator === "-" && attrVal.expression.argument.type === "NumericLiteral" && attrVal.expression.argument.value === 1) {
            return null;
          }
          if (attrVal?.type === "JSXExpressionContainer" && attrVal.expression.type === "NumericLiteral" && attrVal.expression.value === -1) {
            return null;
          }
        }
        const elementId = getFlintId2(opening, `${tag}-aria-hidden-focusable`);
        return {
          ruleId: "A11Y-036",
          elementId,
          message: `A11Y-036: <${tag}> has aria-hidden="true" but is a focusable element. Focusable elements with aria-hidden will still be reachable by keyboard users but invisible to AT. Remove aria-hidden or add tabIndex={-1}.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Removed aria-hidden from focusable element.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-hidden",
                value: null
              }
            }
          ]
        };
      }
    };
    rule037 = {
      id: "A11Y-037",
      name: "Duplicate ARIA Attributes",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: "Elements must not have duplicate ARIA attributes.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const seen = /* @__PURE__ */ new Map();
        for (const attr of opening.attributes) {
          if (attr.type !== "JSXAttribute") continue;
          if (attr.name.type !== "JSXIdentifier") continue;
          const name = attr.name.name;
          if (!name.startsWith("aria-")) continue;
          seen.set(name, (seen.get(name) ?? 0) + 1);
        }
        const duplicates = Array.from(seen.entries()).filter(([, count]) => count > 1).map(([name]) => name);
        if (duplicates.length === 0) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-duplicate-aria`);
        return {
          ruleId: "A11Y-037",
          elementId,
          message: `A11Y-037: <${tag}> has duplicate ARIA attribute(s): ${duplicates.join(", ")}. Remove duplicate attributes \u2014 only the last value will be used by ATs.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        const attrMatch = /duplicate ARIA attribute\(s\): ([^\n.]+)\./.exec(violation.message);
        if (!attrMatch) return null;
        const duplicates = attrMatch[1].split(",").map((s) => s.trim());
        return {
          description: `Removed duplicate ARIA attribute(s): ${duplicates.join(", ")}.`,
          mutations: duplicates.map((attrName) => ({
            type: "updateProp",
            args: {
              nodeId: violation.elementId,
              propName: attrName,
              value: null
            }
          }))
        };
      }
    };
    INTERACTIVE_TAGS = /* @__PURE__ */ new Set(["input", "select", "textarea", "button", "a"]);
    rule038 = {
      id: "A11Y-038",
      name: "Interactive Element With Presentation Role",
      wcag: "4.1.2",
      level: "A",
      category: "aria",
      severity: "critical",
      description: 'Interactive elements must not have role="presentation" or role="none".',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (!tag || !INTERACTIVE_TAGS.has(tag)) return null;
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (!roleVal) return null;
        if (roleVal !== "presentation" && roleVal !== "none") return null;
        const elementId = getFlintId2(opening, `${tag}-presentation-role`);
        return {
          ruleId: "A11Y-038",
          elementId,
          message: `A11Y-038: <${tag}> has role="${roleVal}" but is an interactive element. Interactive elements must not use role="presentation" or role="none" as it removes their semantic meaning from the accessibility tree.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Removed presentation/none role from interactive element.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "role",
                value: null
              }
            }
          ]
        };
      }
    };
    ariaRules = [
      rule030,
      rule031,
      rule032,
      rule033,
      rule034,
      rule035,
      rule036,
      rule037,
      rule038
    ];
  }
});

// flint-mcp/src/core/a11y/rules/landmarks.ts
var rule050, rule051, rule052, rule053, landmarksRules;
var init_landmarks = __esm({
  "flint-mcp/src/core/a11y/rules/landmarks.ts"() {
    "use strict";
    rule050 = {
      id: "A11Y-050",
      name: "Missing Main Landmark",
      wcag: "1.3.1",
      level: "A",
      category: "landmarks",
      severity: "critical",
      description: 'The page must have a <main> element or an element with role="main".',
      auditDocument(context) {
        if (context.totalElements === 0) return [];
        if (!context.hasPageStructure) return [];
        if (context.landmarksFound.has("main")) return [];
        return [
          {
            ruleId: "A11Y-050",
            elementId: "document",
            message: 'A11Y-050: No <main> landmark found. Add a <main> element or role="main" to identify the main content area.',
            severity: "critical",
            wcag: "1.3.1",
            fixable: false
          }
        ];
      }
    };
    rule051 = {
      id: "A11Y-051",
      name: "Missing Navigation Landmark",
      wcag: "1.3.1",
      level: "A",
      category: "landmarks",
      severity: "warning",
      description: 'The page should have a <nav> element or an element with role="navigation".',
      auditDocument(context) {
        if (context.totalElements === 0) return [];
        if (!context.hasPageStructure) return [];
        if (context.landmarksFound.has("navigation")) return [];
        return [
          {
            ruleId: "A11Y-051",
            elementId: "document",
            message: "A11Y-051: No <nav> landmark found. Consider adding a <nav> element for the primary navigation to improve structure for screen reader users.",
            severity: "warning",
            wcag: "1.3.1",
            fixable: false
          }
        ];
      }
    };
    rule052 = {
      id: "A11Y-052",
      name: "Multiple Main Landmarks",
      wcag: "1.3.1",
      level: "A",
      category: "landmarks",
      severity: "critical",
      description: "<main> must not appear more than once per page.",
      auditDocument(context) {
        if (context.totalElements === 0) return [];
        if (!context.hasPageStructure) return [];
        const mainInstances = context.landmarkInstances.filter((l) => l.role === "main");
        if (mainInstances.length <= 1) return [];
        return [
          {
            ruleId: "A11Y-052",
            elementId: "document",
            message: `A11Y-052: Found ${mainInstances.length} <main> landmarks. A page must have at most one <main> element.`,
            severity: "critical",
            wcag: "1.3.1",
            fixable: false
          }
        ];
      }
    };
    rule053 = {
      id: "A11Y-053",
      name: "Duplicate Landmark Without Distinct Label",
      wcag: "1.3.1",
      level: "A",
      category: "landmarks",
      severity: "critical",
      description: "Multiple landmarks of the same type must have distinct aria-labels.",
      auditDocument(context) {
        if (context.totalElements === 0) return [];
        if (!context.hasPageStructure) return [];
        const violations = [];
        const byRole = /* @__PURE__ */ new Map();
        for (const instance of context.landmarkInstances) {
          const existing = byRole.get(instance.role) ?? [];
          existing.push({ label: instance.label, elementId: instance.elementId });
          byRole.set(instance.role, existing);
        }
        for (const [role, instances] of byRole.entries()) {
          if (instances.length <= 1) continue;
          const labels = instances.map((i) => i.label);
          const hasUnlabeled = labels.some((l) => !l);
          const uniqueLabels = new Set(labels.filter(Boolean));
          const hasDuplicateLabels = uniqueLabels.size < instances.filter((i) => i.label).length;
          if (hasUnlabeled || hasDuplicateLabels) {
            violations.push({
              ruleId: "A11Y-053",
              elementId: instances[0].elementId,
              message: `A11Y-053: Multiple "${role}" landmarks found (${instances.length}) without distinct aria-labels. Add aria-label="\u2026" to each <${role === "navigation" ? "nav" : role}> to distinguish them for screen reader users.`,
              severity: "critical",
              wcag: "1.3.1",
              fixable: false
            });
          }
        }
        return violations;
      }
    };
    landmarksRules = [rule050, rule051, rule052, rule053];
  }
});

// flint-mcp/src/core/a11y/rules/contrast.ts
var TEXT_TAGS, UI_COMPONENT_TAGS, rule060, rule061, rule062, contrastRules;
var init_contrast = __esm({
  "flint-mcp/src/core/a11y/rules/contrast.ts"() {
    "use strict";
    init_helpers();
    init_contrast_utils();
    TEXT_TAGS = /* @__PURE__ */ new Set([
      "p",
      "span",
      "h1",
      "h2",
      "h3",
      "h4",
      "h5",
      "h6",
      "a",
      "label",
      "li",
      "td",
      "th",
      "caption",
      "dt",
      "dd",
      "button",
      "strong",
      "em",
      "small",
      "cite",
      "code",
      "abbr"
    ]);
    UI_COMPONENT_TAGS = /* @__PURE__ */ new Set([
      "input",
      "select",
      "textarea",
      "button"
    ]);
    rule060 = {
      id: "A11Y-060",
      name: "Normal Text Insufficient Contrast",
      wcag: "1.4.3",
      level: "AA",
      category: "contrast",
      severity: "critical",
      description: "Normal text must have a contrast ratio of at least 4.5:1.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (!tag || !TEXT_TAGS.has(tag)) return null;
        const opening = path9.node.openingElement;
        const classNameAttr = getAttributeStringValue(opening, "className");
        if (!classNameAttr) return null;
        const classes = classNameAttr.split(/\s+/).filter(Boolean);
        const colors = extractColorContext(classes);
        if (!colors.foreground || !colors.background) return null;
        const ratio = wcagContrastRatio(colors.foreground, colors.background);
        if (ratio === null) return null;
        const large = isLargeText(colors.fontSize, colors.fontWeight);
        if (large) return null;
        if (meetsAA(ratio, false)) return null;
        const elementId = getFlintId2(opening, `${tag}-contrast-normal`);
        return {
          ruleId: "A11Y-060",
          elementId,
          message: `A11Y-060: <${tag}> text contrast ratio is ${ratio.toFixed(2)}:1 (${colors.foreground} on ${colors.background}). Normal text requires at least 4.5:1 per WCAG 2.x AA.`,
          severity: "critical",
          wcag: "1.4.3",
          fixable: false
        };
      }
    };
    rule061 = {
      id: "A11Y-061",
      name: "Large Text Insufficient Contrast",
      wcag: "1.4.3",
      level: "AA",
      category: "contrast",
      severity: "critical",
      description: "Large text must have a contrast ratio of at least 3:1.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (!tag || !TEXT_TAGS.has(tag)) return null;
        const opening = path9.node.openingElement;
        const classNameAttr = getAttributeStringValue(opening, "className");
        if (!classNameAttr) return null;
        const classes = classNameAttr.split(/\s+/).filter(Boolean);
        const colors = extractColorContext(classes);
        if (!colors.foreground || !colors.background) return null;
        const large = isLargeText(colors.fontSize, colors.fontWeight);
        if (!large) return null;
        const ratio = wcagContrastRatio(colors.foreground, colors.background);
        if (ratio === null) return null;
        if (meetsAA(ratio, true)) return null;
        const elementId = getFlintId2(opening, `${tag}-contrast-large`);
        return {
          ruleId: "A11Y-061",
          elementId,
          message: `A11Y-061: <${tag}> large text contrast ratio is ${ratio.toFixed(2)}:1 (${colors.foreground} on ${colors.background}). Large text requires at least 3:1 per WCAG 2.x AA.`,
          severity: "critical",
          wcag: "1.4.3",
          fixable: false
        };
      }
    };
    rule062 = {
      id: "A11Y-062",
      name: "UI Component Insufficient Contrast",
      wcag: "1.4.11",
      level: "AA",
      category: "contrast",
      severity: "critical",
      description: "UI components must have a non-text contrast ratio of at least 3:1.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (!tag || !UI_COMPONENT_TAGS.has(tag)) return null;
        const opening = path9.node.openingElement;
        const classNameAttr = getAttributeStringValue(opening, "className");
        if (!classNameAttr) return null;
        const classes = classNameAttr.split(/\s+/).filter(Boolean);
        let borderColor = null;
        let bgColor = null;
        for (const cls of classes) {
          if (cls.startsWith("border-[#") || cls.startsWith("border-[")) {
            const match = /\[#([0-9a-fA-F]{3,8})\]/.exec(cls);
            if (match) borderColor = `#${match[1]}`;
          }
          if (cls.startsWith("bg-[#") || cls.startsWith("bg-[")) {
            const match = /\[#([0-9a-fA-F]{3,8})\]/.exec(cls);
            if (match) bgColor = `#${match[1]}`;
          }
        }
        if (!borderColor || !bgColor) return null;
        const ratio = wcagContrastRatio(borderColor, bgColor);
        if (ratio === null) return null;
        if (ratio >= 3) return null;
        const elementId = getFlintId2(opening, `${tag}-non-text-contrast`);
        return {
          ruleId: "A11Y-062",
          elementId,
          message: `A11Y-062: <${tag}> UI component contrast ratio is ${ratio.toFixed(2)}:1 (border ${borderColor} on background ${bgColor}). UI components require at least 3:1 per WCAG 1.4.11.`,
          severity: "critical",
          wcag: "1.4.11",
          fixable: false
        };
      }
    };
    contrastRules = [rule060, rule061, rule062];
  }
});

// flint-mcp/src/core/a11y/rules/forms.ts
var VALID_AUTOCOMPLETE_VALUES, rule070, rule071, rule072, rule073, rule074, rule075, formsRules;
var init_forms = __esm({
  "flint-mcp/src/core/a11y/rules/forms.ts"() {
    "use strict";
    init_helpers();
    VALID_AUTOCOMPLETE_VALUES = /* @__PURE__ */ new Set([
      "off",
      "on",
      "name",
      "honorific-prefix",
      "given-name",
      "additional-name",
      "family-name",
      "honorific-suffix",
      "nickname",
      "email",
      "username",
      "new-password",
      "current-password",
      "one-time-code",
      "organization-title",
      "organization",
      "street-address",
      "shipping",
      "billing",
      "address-line1",
      "address-line2",
      "address-line3",
      "address-level4",
      "address-level3",
      "address-level2",
      "address-level1",
      "country",
      "country-name",
      "postal-code",
      "cc-name",
      "cc-given-name",
      "cc-additional-name",
      "cc-family-name",
      "cc-number",
      "cc-exp",
      "cc-exp-month",
      "cc-exp-year",
      "cc-csc",
      "cc-type",
      "transaction-currency",
      "transaction-amount",
      "language",
      "bday",
      "bday-day",
      "bday-month",
      "bday-year",
      "sex",
      "tel",
      "tel-country-code",
      "tel-national",
      "tel-area-code",
      "tel-local",
      "tel-extension",
      "impp",
      "url",
      "photo",
      "webauthn"
    ]);
    rule070 = {
      id: "A11Y-070",
      name: "Fieldset Missing Legend",
      wcag: "1.3.1",
      level: "A",
      category: "forms",
      severity: "critical",
      description: "<fieldset> elements must contain a <legend> child.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "fieldset") return null;
        const hasLegend = hasDirectChildTag(path9, "legend");
        if (hasLegend) return null;
        const hasDynamicChildren = path9.node.children.some(
          (c) => c.type === "JSXExpressionContainer"
        );
        if (hasDynamicChildren) return null;
        const opening = path9.node.openingElement;
        const elementId = getFlintId2(opening, "fieldset-no-legend");
        return {
          ruleId: "A11Y-070",
          elementId,
          message: "A11Y-070: <fieldset> has no <legend> child. Add a <legend> element as the first child to describe the group of form controls.",
          severity: "critical",
          wcag: "1.3.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Injected empty <legend>[NEEDS LABEL]</legend> into <fieldset>.",
          mutations: [
            {
              type: "inject",
              args: {
                targetNodeId: violation.elementId,
                jsxSnippet: "<legend>[NEEDS LABEL]</legend>",
                importSnippet: null
              }
            }
          ]
        };
      }
    };
    rule071 = {
      id: "A11Y-071",
      name: "Required Input Missing aria-required",
      wcag: "3.3.2",
      level: "A",
      category: "forms",
      severity: "critical",
      description: '<input> with required attribute must also have aria-required="true".',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        const requiredAttr = getJsxAttr(opening, "required");
        if (!requiredAttr) return null;
        if (requiredAttr.type === "JSXAttribute" && requiredAttr.value?.type === "JSXExpressionContainer") return null;
        const ariaRequiredVal = getAttributeStringValue(opening, "aria-required");
        if (ariaRequiredVal === "true") return null;
        const elementId = getFlintId2(opening, "input-required-no-aria");
        return {
          ruleId: "A11Y-071",
          elementId,
          message: 'A11Y-071: <input> has the required attribute but no aria-required="true". Add aria-required="true" so assistive technologies can announce the field as required.',
          severity: "warning",
          wcag: "3.3.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added aria-required="true" to required <input>.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-required",
                value: "true"
              }
            }
          ]
        };
      }
    };
    rule072 = {
      id: "A11Y-072",
      name: "Invalid Input Missing Error Description",
      wcag: "3.3.1",
      level: "A",
      category: "forms",
      severity: "critical",
      description: "<input> with aria-invalid must have aria-describedby pointing to an error message.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        const ariaInvalidAttr = getJsxAttr(opening, "aria-invalid");
        if (!ariaInvalidAttr) return null;
        const ariaInvalidVal = getAttributeValue(ariaInvalidAttr);
        if (ariaInvalidVal === null) return null;
        if (ariaInvalidVal !== "true" && ariaInvalidVal !== "grammar" && ariaInvalidVal !== "spelling") return null;
        const hasAriaDescribedBy = hasNonEmptyAttr(opening, "aria-describedby");
        if (hasAriaDescribedBy) return null;
        const elementId = getFlintId2(opening, "input-invalid-no-describedby");
        return {
          ruleId: "A11Y-072",
          elementId,
          message: 'A11Y-072: <input> has aria-invalid but no aria-describedby. Add aria-describedby="[error-element-id]" pointing to an element that describes the error.',
          severity: "critical",
          wcag: "3.3.1",
          fixable: false
        };
      }
    };
    rule073 = {
      id: "A11Y-073",
      name: "Invalid Autocomplete Value",
      wcag: "1.3.5",
      level: "AA",
      category: "forms",
      severity: "critical",
      description: "The autocomplete attribute must use valid HTML5 autofill detail tokens.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        const autocompleteAttr = getJsxAttr(opening, "autoComplete");
        if (!autocompleteAttr) return null;
        const val = getAttributeValue(autocompleteAttr);
        if (val === null) return null;
        const tokens = val.trim().split(/\s+/);
        const invalidTokens = tokens.filter((t3) => t3 && !VALID_AUTOCOMPLETE_VALUES.has(t3));
        if (invalidTokens.length === 0) return null;
        const elementId = getFlintId2(opening, "input-invalid-autocomplete");
        return {
          ruleId: "A11Y-073",
          elementId,
          message: `A11Y-073: <input> has invalid autocomplete value(s): "${invalidTokens.join('", "')}" Use valid HTML5 autocomplete tokens like "name", "email", "tel", "current-password", etc.`,
          severity: "critical",
          wcag: "1.3.5",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Removed invalid autocomplete value.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "autoComplete",
                value: null
              }
            }
          ]
        };
      }
    };
    rule074 = {
      id: "A11Y-074",
      name: "Password Input Missing Autocomplete",
      wcag: "1.3.5",
      level: "AA",
      category: "forms",
      severity: "warning",
      description: '<input type="password"> must have an autocomplete attribute of "current-password" or "new-password" so password managers and ATs can correctly identify the field.',
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "input") return null;
        const opening = path9.node.openingElement;
        const typeVal = getAttributeStringValue(opening, "type");
        if (typeVal !== "password") return null;
        const autocompleteAttr = getJsxAttr(opening, "autoComplete");
        if (!autocompleteAttr) {
          const elementId2 = getFlintId2(opening, "input-password-no-autocomplete");
          return {
            ruleId: "A11Y-074",
            elementId: elementId2,
            message: 'A11Y-074: <input type="password"> is missing an autoComplete attribute. Add autoComplete="current-password" or autoComplete="new-password" so password managers and assistive technologies can identify the field purpose.',
            severity: "warning",
            wcag: "1.3.5",
            fixable: true
          };
        }
        const autocompleteVal = getAttributeValue(autocompleteAttr);
        if (autocompleteVal === null) return null;
        if (autocompleteVal === "current-password" || autocompleteVal === "new-password") return null;
        const elementId = getFlintId2(opening, "input-password-wrong-autocomplete");
        return {
          ruleId: "A11Y-074",
          elementId,
          message: `A11Y-074: <input type="password"> has autoComplete="${autocompleteVal}" which does not identify the password purpose. Use autoComplete="current-password" for login forms or autoComplete="new-password" for registration.`,
          severity: "warning",
          wcag: "1.3.5",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added autoComplete="current-password" to password input.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "autoComplete",
                value: "current-password"
              }
            }
          ]
        };
      }
    };
    rule075 = {
      id: "A11Y-075",
      name: "Output Element Missing Association",
      wcag: "1.3.1",
      level: "A",
      category: "forms",
      severity: "critical",
      description: "<output> elements should be associated with form controls via htmlFor, or must have aria-live to announce dynamic results.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "output") return null;
        const opening = path9.node.openingElement;
        if (hasNonEmptyAttr(opening, "htmlFor")) return null;
        const ariaLiveAttr = getJsxAttr(opening, "aria-live");
        if (ariaLiveAttr?.type === "JSXAttribute" && ariaLiveAttr.value?.type === "JSXExpressionContainer") return null;
        if (hasNonEmptyAttr(opening, "aria-live")) return null;
        const htmlForAttr = getJsxAttr(opening, "htmlFor");
        if (htmlForAttr?.type === "JSXAttribute" && htmlForAttr.value?.type === "JSXExpressionContainer") return null;
        const elementId = getFlintId2(opening, "output-no-association");
        return {
          ruleId: "A11Y-075",
          elementId,
          message: 'A11Y-075: <output> element has no htmlFor association and no aria-live attribute. Add htmlFor="[control-id]" to associate with a form control, or aria-live="polite" so screen readers announce result changes.',
          severity: "critical",
          wcag: "1.3.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added aria-live="polite" to <output> element.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-live",
                value: "polite"
              }
            }
          ]
        };
      }
    };
    formsRules = [rule070, rule071, rule072, rule073, rule074, rule075];
  }
});

// flint-mcp/src/core/a11y/rules/live-regions.ts
var rule080, rule081, rule082, rule083, liveRegionsRules;
var init_live_regions = __esm({
  "flint-mcp/src/core/a11y/rules/live-regions.ts"() {
    "use strict";
    init_helpers();
    rule080 = {
      id: "A11Y-080",
      name: "Alert Role With Wrong aria-live",
      wcag: "4.1.3",
      level: "AA",
      category: "live-regions",
      severity: "critical",
      description: 'Elements with role="alert" must not set aria-live="polite". role="alert" implies aria-live="assertive". Elements with role="status" must not set aria-live="assertive".',
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (!roleVal) return null;
        const ariaLiveVal = getAttributeStringValue(opening, "aria-live");
        if (!ariaLiveVal) return null;
        const tag = getTagName(path9) ?? "element";
        if (roleVal === "alert" && ariaLiveVal === "polite") {
          const elementId = getFlintId2(opening, `${tag}-alert-polite-conflict`);
          return {
            ruleId: "A11Y-080",
            elementId,
            message: 'A11Y-080: role="alert" already implies aria-live="assertive". Setting aria-live="polite" overrides this and reduces urgency. Remove aria-live or set it to "assertive".',
            severity: "critical",
            wcag: "4.1.3",
            fixable: true
          };
        }
        if (roleVal === "status" && ariaLiveVal === "assertive") {
          const elementId = getFlintId2(opening, `${tag}-status-assertive-conflict`);
          return {
            ruleId: "A11Y-080",
            elementId,
            message: 'A11Y-080: role="status" implies aria-live="polite". Setting aria-live="assertive" overrides this and interrupts the user. Remove aria-live or change to "polite".',
            severity: "critical",
            wcag: "4.1.3",
            fixable: true
          };
        }
        return null;
      },
      fix(violation, _ast) {
        return {
          description: "Removed conflicting aria-live attribute.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-live",
                value: null
              }
            }
          ]
        };
      }
    };
    rule081 = {
      id: "A11Y-081",
      name: "Dialog Missing aria-modal",
      wcag: "4.1.2",
      level: "A",
      category: "live-regions",
      severity: "critical",
      description: 'Elements with role="dialog" or role="alertdialog" must have aria-modal="true".',
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (roleVal !== "dialog" && roleVal !== "alertdialog") return null;
        const ariaModalVal = getAttributeStringValue(opening, "aria-modal");
        if (ariaModalVal === "true") return null;
        const ariaModalAttr = getJsxAttr(opening, "aria-modal");
        if (ariaModalAttr?.type === "JSXAttribute" && ariaModalAttr.value?.type === "JSXExpressionContainer") return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-dialog-no-modal`);
        return {
          ruleId: "A11Y-081",
          elementId,
          message: `A11Y-081: role="${roleVal}" element is missing aria-modal="true". Without aria-modal, screen readers may allow users to navigate content behind the dialog. Add aria-modal="true" to confine the AT virtual cursor to the dialog.`,
          severity: "critical",
          wcag: "4.1.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added aria-modal="true" to dialog element.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-modal",
                value: "true"
              }
            }
          ]
        };
      }
    };
    rule082 = {
      id: "A11Y-082",
      name: "Unnecessary Assertive Live Region",
      wcag: "4.1.3",
      level: "AA",
      category: "live-regions",
      severity: "warning",
      description: 'aria-live="assertive" on non-alert elements interrupts the user. Use aria-live="polite" or role="status" for non-urgent updates.',
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const ariaLiveVal = getAttributeStringValue(opening, "aria-live");
        if (ariaLiveVal !== "assertive") return null;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (roleVal === "alert" || roleVal === "alertdialog") return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-assertive-overuse`);
        return {
          ruleId: "A11Y-082",
          elementId,
          message: `A11Y-082: <${tag}> uses aria-live="assertive" without role="alert". Assertive regions interrupt ongoing AT speech. Use aria-live="polite" for non-urgent status updates, or add role="alert" only for critical errors.`,
          severity: "warning",
          wcag: "4.1.3",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Changed aria-live="assertive" to aria-live="polite".',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-live",
                value: "polite"
              }
            }
          ]
        };
      }
    };
    rule083 = {
      id: "A11Y-083",
      name: "Live Region Missing aria-atomic",
      wcag: "4.1.3",
      level: "AA",
      category: "live-regions",
      severity: "warning",
      description: "Elements with aria-live should set aria-atomic to clarify whether the whole region or only changed nodes should be announced.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const ariaLiveVal = getAttributeStringValue(opening, "aria-live");
        if (!ariaLiveVal || ariaLiveVal === "off") return null;
        const ariaLiveAttr = getJsxAttr(opening, "aria-live");
        if (ariaLiveAttr?.type === "JSXAttribute" && ariaLiveAttr.value?.type === "JSXExpressionContainer") return null;
        if (hasNonEmptyAttr(opening, "aria-atomic")) return null;
        const roleVal = getAttributeValue(getJsxAttr(opening, "role"));
        if (roleVal === "alert" || roleVal === "status") return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-live-no-atomic`);
        return {
          ruleId: "A11Y-083",
          elementId,
          message: `A11Y-083: <${tag}> has aria-live="${ariaLiveVal}" but no aria-atomic. Add aria-atomic="true" to announce the entire region on change, or aria-atomic="false" to announce only the changed nodes.`,
          severity: "warning",
          wcag: "4.1.3",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: 'Added aria-atomic="true" to live region.',
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "aria-atomic",
                value: "true"
              }
            }
          ]
        };
      }
    };
    liveRegionsRules = [rule080, rule081, rule082, rule083];
  }
});

// flint-mcp/src/core/a11y/rules/motion.ts
var rule090, rule091, rule092, motionRules;
var init_motion = __esm({
  "flint-mcp/src/core/a11y/rules/motion.ts"() {
    "use strict";
    init_helpers();
    rule090 = {
      id: "A11Y-090",
      name: "Animation Without Reduced-Motion Guard",
      wcag: "2.3.3",
      level: "AAA",
      category: "motion",
      severity: "warning",
      description: "Tailwind animate-* classes must be guarded with motion-safe: or motion-reduce: to respect the prefers-reduced-motion media query.",
      visitElement(path9, _context) {
        const opening = path9.node.openingElement;
        const classNameAttr = getAttributeStringValue(opening, "className");
        if (!classNameAttr) return null;
        const classes = classNameAttr.split(/\s+/).filter(Boolean);
        const animateClasses = classes.filter(
          (c) => (c.startsWith("animate-") || c.startsWith("transition-") || c.startsWith("duration-")) && !c.startsWith("motion-safe:") && !c.startsWith("motion-reduce:")
        );
        if (animateClasses.length === 0) return null;
        const hasMotionGuard = classes.some(
          (c) => c.startsWith("motion-safe:") || c.startsWith("motion-reduce:")
        );
        if (hasMotionGuard) return null;
        const tag = getTagName(path9) ?? "element";
        const elementId = getFlintId2(opening, `${tag}-unguarded-animation`);
        return {
          ruleId: "A11Y-090",
          elementId,
          message: `A11Y-090: <${tag}> has animation class(es) (${animateClasses.slice(0, 3).join(", ")}) without a prefers-reduced-motion guard. Wrap with motion-safe:animate-* or add motion-reduce:animate-none for users who prefer reduced motion.`,
          severity: "warning",
          wcag: "2.3.3",
          fixable: false
        };
      }
    };
    rule091 = {
      id: "A11Y-091",
      name: "Video Missing Controls",
      wcag: "1.2.2",
      level: "A",
      category: "motion",
      severity: "critical",
      description: "<video> elements must have a controls attribute unless they are purely decorative (muted + autoplay, no audio track).",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "video") return null;
        const opening = path9.node.openingElement;
        const controlsAttr = getJsxAttr(opening, "controls");
        if (controlsAttr !== void 0) return null;
        const mutedAttr = getJsxAttr(opening, "muted");
        const autoPlayAttr = getJsxAttr(opening, "autoPlay") ?? getJsxAttr(opening, "autoplay");
        if (mutedAttr !== void 0 && autoPlayAttr !== void 0) return null;
        const elementId = getFlintId2(opening, "video-no-controls");
        return {
          ruleId: "A11Y-091",
          elementId,
          message: "A11Y-091: <video> is missing the controls attribute. Users must be able to pause, stop, and control the volume of media. Add controls, or use muted+autoPlay for purely decorative background video.",
          severity: "critical",
          wcag: "1.2.2",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added controls attribute to <video>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "controls",
                value: ""
              }
            }
          ]
        };
      }
    };
    rule092 = {
      id: "A11Y-092",
      name: "Audio Missing Controls",
      wcag: "1.2.1",
      level: "A",
      category: "motion",
      severity: "critical",
      description: "<audio> elements must have a controls attribute.",
      visitElement(path9, _context) {
        const tag = getTagName(path9);
        if (tag !== "audio") return null;
        const opening = path9.node.openingElement;
        const controlsAttr = getJsxAttr(opening, "controls");
        if (controlsAttr !== void 0) return null;
        const elementId = getFlintId2(opening, "audio-no-controls");
        return {
          ruleId: "A11Y-092",
          elementId,
          message: "A11Y-092: <audio> is missing the controls attribute. Users must be able to control audio playback. Add controls to the element.",
          severity: "critical",
          wcag: "1.2.1",
          fixable: true
        };
      },
      fix(violation, _ast) {
        return {
          description: "Added controls attribute to <audio>.",
          mutations: [
            {
              type: "updateProp",
              args: {
                nodeId: violation.elementId,
                propName: "controls",
                value: ""
              }
            }
          ]
        };
      }
    };
    motionRules = [rule090, rule091, rule092];
  }
});

// flint-mcp/src/core/A11yLinter.ts
var A11yLinter_exports = {};
__export(A11yLinter_exports, {
  A11yLinter: () => A11yLinter
});
function ensureRulesRegistered() {
  if (getRegisteredRules().length > 0) return;
  registerRules([
    ...namesLabelsRules,
    ...keyboardRules,
    ...structureRules,
    ...ariaRules,
    ...landmarksRules,
    ...contrastRules,
    ...formsRules,
    ...liveRegionsRules,
    ...motionRules
  ]);
}
var A11yLinter;
var init_A11yLinter = __esm({
  "flint-mcp/src/core/A11yLinter.ts"() {
    "use strict";
    init_runner();
    init_names_labels();
    init_keyboard();
    init_structure();
    init_aria();
    init_landmarks();
    init_contrast();
    init_forms();
    init_live_regions();
    init_motion();
    A11yLinter = {
      /**
       * Backward-compatible audit that returns violations in the original
       * `Record<flintId, string[]>` format.
       *
       * Traverses the provided Babel AST and returns every accessibility violation
       * grouped by `data-flint-id` (or positional fallback key).
       *
       * @param ast  A Babel `File` node produced by `@babel/parser`.
       * @returns    Record mapping element keys to violation message arrays.
       *             An empty object means the file is fully accessible.
       */
      audit(ast) {
        ensureRulesRegistered();
        const result = auditSync(ast, { filePath: "unknown" });
        const violations = {};
        for (const violation of result.violations) {
          if (!violations[violation.elementId]) {
            violations[violation.elementId] = [];
          }
          violations[violation.elementId].push(violation.message);
        }
        return violations;
      },
      /**
       * Structured audit returning the full A11yAuditResult.
       * New callers should prefer this over `audit()`.
       *
       * @param ast       A Babel `File` node.
       * @param filePath  Optional file path for reporting context.
       */
      auditStructured(ast, filePath = "unknown") {
        ensureRulesRegistered();
        return auditSync(ast, { filePath });
      }
    };
  }
});

// server/services/thumbnailService.ts
var thumbnailService_exports = {};
__export(thumbnailService_exports, {
  createThumbnailService: () => createThumbnailService
});
import path6 from "node:path";
import { existsSync as existsSync5, mkdirSync as mkdirSync2, readFileSync as readFileSync3, statSync, unlinkSync } from "node:fs";
import { readFile as readFile2 } from "node:fs/promises";
function thumbnailsDir(projectRoot) {
  return path6.join(projectRoot, ".flint", THUMBNAIL_DIR);
}
function thumbnailPath(projectRoot, componentName) {
  const safeName = componentName.replace(/[^a-zA-Z0-9_-]/g, "_");
  return path6.join(thumbnailsDir(projectRoot), `${safeName}.png`);
}
function ensureThumbnailsDir(projectRoot) {
  const dir = thumbnailsDir(projectRoot);
  if (!existsSync5(dir)) {
    mkdirSync2(dir, { recursive: true });
  }
}
function isCacheFresh(filePath) {
  try {
    if (!existsSync5(filePath)) return false;
    const { mtimeMs } = statSync(filePath);
    return Date.now() - mtimeMs < CACHE_MAX_AGE_MS;
  } catch {
    return false;
  }
}
function transformForBrowser(source, componentName) {
  let code = source;
  code = code.replace(/^import\s[\s\S]*?from\s+['"][^'"]*['"];?\s*$/gm, "");
  code = code.replace(/^import\s+['"][^'"]*['"];?\s*$/gm, "");
  code = code.replace(/^import\s+type\s[\s\S]*?from\s+['"][^'"]*['"];?\s*$/gm, "");
  code = code.replace(/:\s*React\.\w+(<[^>]*>)?/g, "");
  code = code.replace(/:\s*\w+(\[\])?(\s*\|[^=,)}\n]+)?(?=[,)}\n=])/g, "");
  code = code.replace(/<\w+(\s*,\s*\w+)*>/g, "");
  code = code.replace(/^(export\s+)?(interface|type)\s+\w+[\s\S]*?^}/gm, "");
  code = code.replace(/\bexport\s+default\s+(function|class)\s+/g, "$1 ");
  code = code.replace(/^export\s+default\s+\w+\s*;?\s*$/gm, "");
  code = code.replace(/^export\s+(?!default)/gm, "");
  return code;
}
function buildRenderHarness(componentCode, componentName, width, height) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      width: ${width}px;
      height: ${height}px;
      overflow: hidden;
      background: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    #root {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  </style>
  <script src="${REACT_UMD}"></script>
  <script src="${REACT_DOM_UMD}"></script>
</head>
<body>
  <div id="root"></div>
  <script>
    // Provide common hooks as globals (components may reference them)
    const { useState, useEffect, useRef, useCallback, useMemo, useContext, createContext } = React;

    try {
      ${componentCode}

      // Attempt to render the component
      const Component = typeof ${componentName} === 'function' ? ${componentName} : null;
      if (Component) {
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(React.createElement(Component));
        window.__FLINT_RENDER_OK = true;
      } else {
        document.getElementById('root').innerHTML =
          '<div style="color:#888;font-family:system-ui;font-size:14px;text-align:center">' +
          'Component not found: ${componentName}</div>';
        window.__FLINT_RENDER_OK = false;
      }
    } catch (err) {
      document.getElementById('root').innerHTML =
        '<div style="color:#c00;font-family:system-ui;font-size:12px;padding:16px">' +
        'Render error: ' + err.message + '</div>';
      window.__FLINT_RENDER_OK = false;
    }
  </script>
</body>
</html>`;
}
async function loadPlaywright() {
  try {
    const pw = await import("playwright");
    return pw.chromium ?? null;
  } catch {
    return null;
  }
}
function createThumbnailService() {
  return {
    async generate(options) {
      const {
        filePath,
        componentName,
        projectRoot,
        width = DEFAULT_WIDTH,
        height = DEFAULT_HEIGHT
      } = options;
      const outPath = thumbnailPath(projectRoot, componentName);
      if (isCacheFresh(outPath)) {
        return {
          componentName,
          thumbnailPath: outPath,
          generated: true,
          error: null
        };
      }
      if (!existsSync5(filePath)) {
        return {
          componentName,
          thumbnailPath: "",
          generated: false,
          error: `Source file not found: ${filePath}`
        };
      }
      const chromium = await loadPlaywright();
      if (!chromium) {
        return {
          componentName,
          thumbnailPath: "",
          generated: false,
          error: "Playwright is not installed. Run `npm install playwright` to enable thumbnail generation."
        };
      }
      let browser = null;
      try {
        const source = readFileSync3(filePath, "utf8");
        const transformed = transformForBrowser(source, componentName);
        const html = buildRenderHarness(transformed, componentName, width, height);
        browser = await chromium.launch({
          headless: true,
          args: [
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu"
          ]
        });
        const page = await browser.newPage();
        await page.setViewportSize({ width, height });
        await page.setContent(html, { waitUntil: "networkidle", timeout: 15e3 });
        await page.waitForFunction("window.__FLINT_RENDER_OK !== undefined", { timeout: 1e4 });
        ensureThumbnailsDir(projectRoot);
        await page.screenshot({
          path: outPath,
          type: "png",
          clip: { x: 0, y: 0, width, height }
        });
        console.log(`${LOG_PREFIX4} Thumbnail generated: ${componentName} -> ${outPath}`);
        return {
          componentName,
          thumbnailPath: outPath,
          generated: true,
          error: null
        };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`${LOG_PREFIX4} Thumbnail generation failed for ${componentName}:`, message);
        return {
          componentName,
          thumbnailPath: "",
          generated: false,
          error: message
        };
      } finally {
        if (browser) {
          try {
            await browser.close();
          } catch {
          }
        }
      }
    },
    async generateAll(projectRoot) {
      const manifestPath = path6.join(projectRoot, "flint-manifest.json");
      if (!existsSync5(manifestPath)) {
        return {
          total: 0,
          succeeded: 0,
          failed: 0,
          results: []
        };
      }
      let components = [];
      try {
        const raw = readFileSync3(manifestPath, "utf8");
        const manifest = JSON.parse(raw);
        const comps = manifest.components ?? {};
        components = Object.entries(comps).filter(([, entry]) => {
          const e = entry;
          return typeof e.filePath === "string";
        }).map(([name, entry]) => ({
          name,
          filePath: entry.filePath
        }));
      } catch (err) {
        console.error(`${LOG_PREFIX4} Failed to read manifest:`, err);
        return {
          total: 0,
          succeeded: 0,
          failed: 0,
          results: []
        };
      }
      const results = [];
      for (const comp of components) {
        const result = await this.generate({
          filePath: path6.isAbsolute(comp.filePath) ? comp.filePath : path6.join(projectRoot, comp.filePath),
          componentName: comp.name,
          projectRoot
        });
        results.push(result);
      }
      const succeeded = results.filter((r) => r.generated).length;
      const failed = results.filter((r) => !r.generated).length;
      console.log(
        `${LOG_PREFIX4} Thumbnail generation complete: ${succeeded}/${results.length} succeeded, ${failed} failed`
      );
      return {
        total: results.length,
        succeeded,
        failed,
        results
      };
    },
    async get(componentName, projectRoot) {
      const pngPath = thumbnailPath(projectRoot, componentName);
      if (!existsSync5(pngPath)) {
        return null;
      }
      try {
        const buffer = await readFile2(pngPath);
        return `data:image/png;base64,${buffer.toString("base64")}`;
      } catch {
        return null;
      }
    },
    async invalidate(componentName, projectRoot) {
      const pngPath = thumbnailPath(projectRoot, componentName);
      if (existsSync5(pngPath)) {
        try {
          unlinkSync(pngPath);
          console.log(`${LOG_PREFIX4} Thumbnail invalidated: ${componentName}`);
        } catch (err) {
          console.error(`${LOG_PREFIX4} Failed to invalidate thumbnail for ${componentName}:`, err);
        }
      }
    }
  };
}
var LOG_PREFIX4, DEFAULT_WIDTH, DEFAULT_HEIGHT, THUMBNAIL_DIR, CACHE_MAX_AGE_MS, REACT_UMD, REACT_DOM_UMD;
var init_thumbnailService = __esm({
  "server/services/thumbnailService.ts"() {
    LOG_PREFIX4 = "[Flint]";
    DEFAULT_WIDTH = 400;
    DEFAULT_HEIGHT = 300;
    THUMBNAIL_DIR = "thumbnails";
    CACHE_MAX_AGE_MS = 24 * 60 * 60 * 1e3;
    REACT_UMD = "https://unpkg.com/react@18/umd/react.production.min.js";
    REACT_DOM_UMD = "https://unpkg.com/react-dom@18/umd/react-dom.production.min.js";
  }
});

// server/cli.ts
import path8 from "node:path";
import { existsSync as existsSync7, readFileSync as readFileSync5 } from "node:fs";
import { fileURLToPath as fileURLToPath3 } from "node:url";

// server/index.ts
import express from "express";
import { WebSocketServer, WebSocket } from "ws";
import http2 from "node:http";
import path7 from "node:path";
import os from "node:os";
import fs2 from "node:fs/promises";
import {
  existsSync as existsSync6,
  mkdirSync as mkdirSync3,
  readFileSync as readFileSync4,
  writeFileSync as writeFileSync3,
  rmSync,
  watch as fsWatch
} from "node:fs";
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import Database from "better-sqlite3";
import { transformSync } from "@babel/core";
import {
  jsxAttribute,
  jsxIdentifier,
  stringLiteral
} from "@babel/types";
import { fileURLToPath as fileURLToPath2 } from "node:url";

// server/services/previewServer.ts
import path from "node:path";
import { existsSync } from "node:fs";
var LOG_PREFIX = "[Flint]";
function createPreviewServer() {
  let viteServer = null;
  let serverUrl = null;
  let activeRoot = null;
  return {
    async start(projectRoot) {
      if (viteServer && serverUrl && activeRoot === projectRoot) {
        return { url: serverUrl };
      }
      if (viteServer) {
        await this.stop();
      }
      if (!existsSync(projectRoot)) {
        return { error: `Project root does not exist: ${projectRoot}` };
      }
      let createServer;
      try {
        const vite = await import("vite");
        createServer = vite.createServer;
      } catch {
        return {
          error: "Vite is not available. Install it with `npm install vite` in your project, or use srcdoc preview mode instead."
        };
      }
      let reactPlugin = null;
      try {
        const reactModule = await import("@vitejs/plugin-react");
        const pluginFactory = reactModule.default ?? reactModule;
        if (typeof pluginFactory === "function") {
          reactPlugin = pluginFactory();
        }
      } catch {
        console.warn(`${LOG_PREFIX} @vitejs/plugin-react not found \u2014 preview will work without JSX transform`);
      }
      const plugins = [];
      if (reactPlugin) {
        plugins.push(reactPlugin);
      }
      try {
        const server = await createServer({
          root: projectRoot,
          configFile: false,
          plugins,
          server: {
            port: 0,
            // Let the OS assign an available port
            strictPort: false,
            host: "127.0.0.1",
            // Allow the main web server origin to embed the preview in an iframe
            cors: true,
            hmr: true
          },
          // Resolve .tsx/.ts/.jsx/.js files
          resolve: {
            extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
            alias: {
              "@": path.join(projectRoot, "src")
            }
          },
          // Suppress the Vite banner and most logs
          logLevel: "warn",
          // Optimize dependencies for faster startup
          optimizeDeps: {
            include: ["react", "react-dom"]
          }
        });
        await server.listen();
        viteServer = server;
        const urls = server.resolvedUrls;
        if (urls && urls.local.length > 0) {
          serverUrl = urls.local[0];
        } else if (server.httpServer) {
          const addr = server.httpServer.address();
          if (addr && typeof addr === "object") {
            serverUrl = `http://127.0.0.1:${addr.port}`;
          }
        }
        if (!serverUrl) {
          await server.close();
          viteServer = null;
          activeRoot = null;
          return { error: "Vite server started but could not determine URL" };
        }
        activeRoot = projectRoot;
        console.log(`${LOG_PREFIX} Preview server running at ${serverUrl}`);
        return { url: serverUrl };
      } catch (err) {
        viteServer = null;
        serverUrl = null;
        activeRoot = null;
        const message = err instanceof Error ? err.message : String(err);
        console.error(`${LOG_PREFIX} Preview server failed to start:`, message);
        return { error: `Failed to start preview server: ${message}` };
      }
    },
    async stop() {
      if (!viteServer) return;
      try {
        await viteServer.close();
        console.log(`${LOG_PREFIX} Preview server stopped.`);
      } catch (err) {
        console.error(`${LOG_PREFIX} Error stopping preview server:`, err);
      } finally {
        viteServer = null;
        serverUrl = null;
        activeRoot = null;
      }
    },
    getUrl() {
      return serverUrl;
    }
  };
}

// server/index.ts
var execFileAsync = promisify(execFile);
var __filename = fileURLToPath2(import.meta.url);
var __dirname2 = path7.dirname(__filename);
var BRAND2 = {
  product: "Flint",
  configDir: ".flint",
  manifestFile: "flint-manifest.json",
  logPrefix: "[Flint]",
  ipcPrefix: "flint:",
  dataIdAttr: "data-flint-id"
};
var EXCLUDED_DIRS2 = /* @__PURE__ */ new Set([
  "node_modules",
  "dist",
  "dist-electron",
  ".git",
  ".next",
  "build",
  "out",
  "coverage",
  ".turbo",
  ".cache"
]);
async function scanDirectory(dirPath) {
  const entries = await fs2.readdir(dirPath, { withFileTypes: true });
  const children = [];
  for (const entry of entries) {
    if (entry.name.startsWith(".")) continue;
    const fullPath = path7.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS2.has(entry.name)) continue;
      const subtree = await scanDirectory(fullPath);
      if ((subtree.children?.length ?? 0) > 0) {
        children.push(subtree);
      }
    } else if (entry.isFile() && /\.(tsx?|jsx?|html?)$/.test(entry.name)) {
      children.push({ name: entry.name, path: fullPath, type: "file" });
    }
  }
  children.sort((a, b) => {
    if (a.type !== b.type) return a.type === "directory" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return { name: path7.basename(dirPath), path: dirPath, type: "directory", children };
}
function isWithinHome(filePath) {
  const home = os.homedir();
  const resolved = path7.resolve(filePath);
  return resolved === home || resolved.startsWith(home + path7.sep);
}
function validateFilePath(filePath, requireSourceExt = true) {
  if (typeof filePath !== "string") {
    throw new TypeError("filePath must be a string");
  }
  if (!path7.isAbsolute(filePath)) {
    throw new Error("filePath must be an absolute path");
  }
  if (requireSourceExt && !/\.(tsx?|jsx?|html?)$/.test(filePath)) {
    throw new Error("filePath must point to a source file (.tsx/.ts/.jsx/.js/.html)");
  }
  if (!isWithinHome(filePath)) {
    throw new Error("path outside user home directory is not permitted");
  }
  return filePath;
}
async function atomicWrite(filePath, content) {
  const tmpPath = filePath + ".tmp";
  await fs2.writeFile(tmpPath, content, "utf-8");
  await fs2.rename(tmpPath, filePath);
}
function injectFlintIdPlugin() {
  return {
    visitor: {
      JSXOpeningElement(nodePath) {
        const loc = nodePath.node.loc;
        if (loc == null) return;
        const nameNode = nodePath.node.name;
        let tagName;
        if (nameNode.type === "JSXIdentifier") {
          tagName = nameNode.name;
        } else if (nameNode.type === "JSXMemberExpression") {
          const obj = nameNode.object.type === "JSXIdentifier" ? nameNode.object.name : "?";
          tagName = `${obj}.${nameNode.property.name}`;
        } else {
          tagName = "unknown";
        }
        const flintId = `${tagName}:${loc.start.line}:${loc.start.column}`;
        const alreadySet = nodePath.node.attributes.some((attr) => {
          if (attr.type !== "JSXAttribute") return false;
          const name = attr.name;
          return name.type === "JSXIdentifier" && name.name === "data-flint-id";
        });
        if (alreadySet) return;
        nodePath.node.attributes.push(
          jsxAttribute(
            jsxIdentifier("data-flint-id"),
            stringLiteral(flintId)
          )
        );
      }
    }
  };
}
function initProjectDatabase(projectRoot) {
  const flintDir = path7.join(projectRoot, BRAND2.configDir);
  mkdirSync3(flintDir, { recursive: true });
  const dbPath = path7.join(flintDir, "flint.db");
  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.exec(`
    CREATE TABLE IF NOT EXISTS project_state (
      key         TEXT    PRIMARY KEY,
      value       TEXT    NOT NULL,
      updated_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );

    CREATE TABLE IF NOT EXISTS assets_cache (
      id          TEXT    PRIMARY KEY,
      base64_data TEXT    NOT NULL,
      created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );

    CREATE TABLE IF NOT EXISTS component_mappings (
      id               TEXT    PRIMARY KEY,
      figma_node_id    TEXT    NOT NULL,
      react_component  TEXT    NOT NULL,
      created_at       INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS design_tokens (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      token_path      TEXT    NOT NULL,
      token_type      TEXT    NOT NULL,
      token_value     TEXT    NOT NULL,
      description     TEXT,
      mode            TEXT    NOT NULL DEFAULT 'default',
      collection_name TEXT    NOT NULL DEFAULT 'default',
      created_at      INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
      updated_at      INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
      version         TEXT,
      last_modified   INTEGER,
      UNIQUE(token_path, mode, collection_name)
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS presence (
      id         TEXT    PRIMARY KEY,
      user_id    TEXT    NOT NULL,
      node_id    TEXT    NOT NULL DEFAULT '',
      x          REAL    NOT NULL DEFAULT 0,
      y          REAL    NOT NULL DEFAULT 0,
      updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS component_overrides (
      flint_id       TEXT    NOT NULL,
      property_key   TEXT    NOT NULL,
      property_value TEXT    NOT NULL,
      updated_at     INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
      PRIMARY KEY (flint_id, property_key)
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS violation_baselines (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      file_path      TEXT    NOT NULL,
      node_id        TEXT    NOT NULL,
      rule_id        TEXT    NOT NULL,
      severity       TEXT    NOT NULL,
      snapshot_value TEXT,
      created_at     INTEGER DEFAULT (strftime('%s', 'now')),
      UNIQUE(file_path, node_id, rule_id)
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS governance_events (
      id          TEXT    PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
      timestamp   TEXT    NOT NULL    DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      event_type  TEXT    NOT NULL,
      rule_id     TEXT    NOT NULL,
      severity    TEXT    NOT NULL,
      node_id     TEXT,
      file_path   TEXT    NOT NULL,
      message     TEXT,
      session_id  TEXT,
      actor       TEXT    NOT NULL    DEFAULT 'system',
      metadata    TEXT    NOT NULL    DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_gov_events_timestamp ON governance_events(timestamp);
    CREATE INDEX IF NOT EXISTS idx_gov_events_rule      ON governance_events(rule_id);
    CREATE INDEX IF NOT EXISTS idx_gov_events_file      ON governance_events(file_path);
    CREATE INDEX IF NOT EXISTS idx_gov_events_type      ON governance_events(event_type);
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS deferred_violations (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      file_path   TEXT    NOT NULL,
      rule_id     TEXT    NOT NULL,
      node_id     TEXT,
      reason      TEXT,
      session_id  TEXT,
      deferred_at TEXT    NOT NULL DEFAULT (datetime('now')),
      resolved_at TEXT,
      UNIQUE(file_path, rule_id, node_id)
    );
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS rag_chunks (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      content     TEXT    NOT NULL,
      source      TEXT    NOT NULL DEFAULT '',
      chunk_type  TEXT    NOT NULL DEFAULT 'documentation',
      created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
    );
  `);
  console.log(`${BRAND2.logPrefix} Project database ready at: ${dbPath}`);
  return db;
}
function initRegistryDatabase() {
  const flintDir = path7.join(os.homedir(), BRAND2.configDir);
  mkdirSync3(flintDir, { recursive: true });
  const dbPath = path7.join(flintDir, "flint-registry.db");
  const registryDb = new Database(dbPath);
  registryDb.pragma("journal_mode = WAL");
  registryDb.exec(`
    CREATE TABLE IF NOT EXISTS recent_projects (
      id          TEXT    PRIMARY KEY,
      name        TEXT    NOT NULL,
      path        TEXT    NOT NULL UNIQUE,
      last_opened INTEGER NOT NULL
    );
  `);
  console.log(`${BRAND2.logPrefix} Registry ready at: ${dbPath}`);
  return registryDb;
}
var previewService = createPreviewServer();
async function startServer(options) {
  const { projectRoot, port = 4201 } = options;
  const resolvedRoot = path7.resolve(projectRoot);
  if (!existsSync6(resolvedRoot)) {
    throw new Error(`Project root does not exist: ${resolvedRoot}`);
  }
  let activeProjectRoot = resolvedRoot;
  let sessionExplicitlyOpened = false;
  const governanceSessionId = randomUUID();
  const db = initProjectDatabase(activeProjectRoot);
  const registryDb = initRegistryDatabase();
  const stmtCreate = db.prepare(`
    INSERT INTO design_tokens
      (token_path, token_type, token_value, description, mode, collection_name)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(token_path, mode, collection_name) DO UPDATE SET
      token_value = excluded.token_value,
      description = excluded.description,
      updated_at  = strftime('%s', 'now')
  `);
  const stmtReadAll = db.prepare(`
    SELECT id, token_path, token_type, token_value, description, mode, collection_name
    FROM design_tokens
    ORDER BY collection_name, mode, token_path
  `);
  const stmtDelete = db.prepare("DELETE FROM design_tokens WHERE id = ?");
  const stmtClearAll = db.prepare("DELETE FROM design_tokens");
  const stmtReadOverrides = db.prepare(`
    SELECT flint_id, property_key, property_value, updated_at
    FROM component_overrides
    ORDER BY updated_at DESC
  `);
  const stmtUpsertPresence = db.prepare(`
    INSERT INTO presence (id, user_id, node_id, x, y, updated_at)
    VALUES (?, ?, ?, ?, ?, strftime('%s', 'now'))
    ON CONFLICT(id) DO UPDATE SET
      user_id    = excluded.user_id,
      node_id    = excluded.node_id,
      x          = excluded.x,
      y          = excluded.y,
      updated_at = strftime('%s', 'now')
  `);
  const stmtReadPresence = db.prepare(`
    SELECT id, user_id, node_id, x, y, updated_at
    FROM presence
    WHERE updated_at > strftime('%s', 'now') - 30
  `);
  const baselineUpsert = db.prepare(`
    INSERT INTO violation_baselines (file_path, node_id, rule_id, severity, snapshot_value)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(file_path, node_id, rule_id) DO UPDATE SET
      severity       = excluded.severity,
      snapshot_value = excluded.snapshot_value,
      created_at     = strftime('%s', 'now')
  `);
  const baselineSelect = db.prepare(
    "SELECT file_path, node_id, rule_id, severity, snapshot_value FROM violation_baselines WHERE file_path = ?"
  );
  const baselineClear = db.prepare("DELETE FROM violation_baselines");
  const baselineIsSet = db.prepare("SELECT COUNT(*) as count FROM violation_baselines");
  const deferViolationUpsert = db.prepare(`
    INSERT INTO deferred_violations (file_path, rule_id, node_id, reason, session_id)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(file_path, rule_id, node_id)
    DO UPDATE SET
      reason      = excluded.reason,
      session_id  = excluded.session_id,
      deferred_at = datetime('now'),
      resolved_at = NULL
  `);
  const deferViolationSelectUnresolved = db.prepare(
    `SELECT id, file_path, rule_id, node_id, reason, session_id, deferred_at
     FROM deferred_violations
     WHERE resolved_at IS NULL
     ORDER BY deferred_at DESC`
  );
  const deferViolationResolve = db.prepare(`
    UPDATE deferred_violations
    SET resolved_at = datetime('now')
    WHERE file_path = ? AND rule_id = ? AND (node_id = ? OR (node_id IS NULL AND ? IS NULL)) AND resolved_at IS NULL
  `);
  const govInsert = db.prepare(`
    INSERT INTO governance_events (event_type, rule_id, severity, file_path, actor, session_id, metadata)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const govOverrideCount = db.prepare(
    "SELECT COUNT(*) as count FROM governance_events WHERE event_type = 'override' AND session_id = ?"
  );
  const registryUpsert = registryDb.prepare(`
    INSERT INTO recent_projects (id, name, path, last_opened)
    VALUES (?, ?, ?, strftime('%s', 'now'))
    ON CONFLICT(path) DO UPDATE SET
      name        = excluded.name,
      last_opened = strftime('%s', 'now')
  `);
  const registryGetRecent = registryDb.prepare(`
    SELECT id, name, path, last_opened
    FROM recent_projects
    ORDER BY last_opened DESC
    LIMIT 10
  `);
  const registryRemove = registryDb.prepare(
    "DELETE FROM recent_projects WHERE id = ?"
  );
  const stmtTokenCount = db.prepare("SELECT COUNT(*) AS count FROM design_tokens");
  const stmtOverrideCount = db.prepare("SELECT COUNT(*) AS count FROM component_overrides");
  const app = express();
  app.use(express.json({ limit: "10mb" }));
  const server = http2.createServer(app);
  const wss = new WebSocketServer({ server, path: "/ws" });
  function broadcast(channel, data) {
    const message = JSON.stringify({ channel, data });
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }
  function broadcastTokensUpdated() {
    broadcast("flint:tokens-updated", {});
  }
  const handlers = /* @__PURE__ */ new Map();
  handlers.set("ping", async () => "pong from Web Server");
  handlers.set("tokens:create", async (token) => {
    if (typeof token !== "object" || token === null || typeof token.token_path !== "string" || typeof token.token_type !== "string" || typeof token.token_value !== "string") {
      throw new Error("tokens:create \u2014 invalid payload shape");
    }
    const t3 = token;
    const mode = typeof t3.mode === "string" && t3.mode.trim() !== "" ? t3.mode : "default";
    const collectionName = typeof t3.collection_name === "string" && t3.collection_name.trim() !== "" ? t3.collection_name : "default";
    const result = stmtCreate.run(
      t3.token_path,
      t3.token_type,
      t3.token_value,
      t3.description ?? null,
      mode,
      collectionName
    );
    broadcastTokensUpdated();
    return { id: result.lastInsertRowid };
  });
  handlers.set("tokens:read-all", async () => stmtReadAll.all());
  handlers.set("tokens:update", async (tokenPath, updates) => {
    if (typeof tokenPath !== "string" || tokenPath.trim() === "") {
      throw new Error("tokens:update \u2014 tokenPath must be a non-empty string");
    }
    if (typeof updates !== "object" || updates === null) {
      throw new Error("tokens:update \u2014 updates must be an object");
    }
    const u = updates;
    const setClauses = [];
    const params = [];
    if (typeof u.token_type === "string") {
      setClauses.push("token_type = ?");
      params.push(u.token_type);
    }
    if (typeof u.token_value === "string") {
      setClauses.push("token_value = ?");
      params.push(u.token_value);
    }
    if ("description" in u) {
      setClauses.push("description = ?");
      params.push(typeof u.description === "string" ? u.description : null);
    }
    if (setClauses.length === 0) {
      throw new Error("tokens:update \u2014 at least one field must be provided");
    }
    setClauses.push("updated_at = strftime('%s', 'now')");
    const sql = `UPDATE design_tokens SET ${setClauses.join(", ")} WHERE token_path = ?`;
    const result = db.prepare(sql).run(...params, tokenPath);
    broadcastTokensUpdated();
    return { changes: result.changes };
  });
  handlers.set("tokens:delete", async (id) => {
    if (typeof id !== "number" || !Number.isInteger(id)) {
      throw new Error("tokens:delete \u2014 id must be an integer");
    }
    const result = stmtDelete.run(id);
    broadcastTokensUpdated();
    return { changes: result.changes };
  });
  handlers.set("tokens:clear-all", async () => {
    const result = stmtClearAll.run();
    console.log(`${BRAND2.logPrefix} tokens:clear-all: removed ${result.changes} tokens`);
    broadcastTokensUpdated();
    return { changes: result.changes };
  });
  handlers.set("tokens:clear-override", async (flintId) => {
    if (typeof flintId !== "string" || flintId.length === 0) return;
    db.prepare("DELETE FROM component_overrides WHERE flint_id = ?").run(flintId);
  });
  handlers.set("tokens:upsert-override", async (flintId, propertyKey, propertyValue) => {
    if (typeof flintId !== "string" || flintId.length === 0 || typeof propertyKey !== "string" || propertyKey.length === 0 || typeof propertyValue !== "string") return;
    db.prepare(
      `INSERT OR REPLACE INTO component_overrides
        (flint_id, property_key, property_value, updated_at)
       VALUES (?, ?, ?, strftime('%s','now'))`
    ).run(flintId, propertyKey, propertyValue);
  });
  handlers.set("tokens:read-overrides", async () => stmtReadOverrides.all());
  handlers.set("file:read", async (filePath) => {
    const validated = validateFilePath(filePath);
    return fs2.readFile(validated, "utf-8");
  });
  handlers.set("ast:save-file", async (filePath, content) => {
    if (typeof content !== "string") {
      throw new TypeError("ast:save-file \u2014 content must be a string");
    }
    const validated = validateFilePath(filePath);
    await atomicWrite(validated, content);
  });
  handlers.set("ast:save-batch", async (batch) => {
    if (typeof batch !== "object" || batch === null || Array.isArray(batch)) {
      throw new TypeError("ast:save-batch \u2014 batch must be a plain object");
    }
    const entries = Object.entries(batch);
    const validated = /* @__PURE__ */ new Map();
    for (const [filePath, content] of entries) {
      if (typeof content !== "string") {
        throw new TypeError(`ast:save-batch \u2014 content for "${filePath}" must be a string`);
      }
      const v = validateFilePath(filePath);
      validated.set(v, content);
    }
    await Promise.all(
      [...validated.entries()].map(([fp, content]) => atomicWrite(fp, content))
    );
  });
  handlers.set("code:transform", async (code) => {
    if (typeof code !== "string") {
      return { js: null, error: "code must be a string" };
    }
    try {
      const result = transformSync(code, {
        filename: "App.tsx",
        plugins: [
          ["@babel/plugin-transform-typescript", { isTSX: true, allExtensions: true }],
          injectFlintIdPlugin,
          ["@babel/plugin-transform-react-jsx", { runtime: "classic" }]
        ],
        configFile: false,
        babelrc: false,
        sourceMaps: false
      });
      if (result === null || result.code == null) {
        return { js: null, error: "Babel returned no output" };
      }
      let js = result.code;
      js = js.replace(/^import\s[^\n]*\n?/gm, "");
      let componentName = null;
      js = js.replace(
        /\bexport\s+default\s+(function|class)\s+(\w+)/,
        (_m, kw, name) => {
          componentName = name;
          return `${kw} ${name}`;
        }
      );
      if (componentName === null) {
        js = js.replace(
          /^export\s+default\s+(\w+)\s*;?\s*$/m,
          (_m, name) => {
            componentName = name;
            return "";
          }
        );
      }
      if (componentName !== null) {
        js += `
window.__AppComponent = ${componentName};`;
      }
      return { js, error: null };
    } catch (err) {
      return { js: null, error: String(err) };
    }
  });
  handlers.set("code:transform-vue", async (code) => {
    if (typeof code !== "string") {
      return { js: null, css: "", error: "code must be a string" };
    }
    try {
      const { compileVueSFC } = await import(path7.resolve(process.cwd(), "electron", "vueCompiler.js"));
      return await compileVueSFC(code);
    } catch (err) {
      return { js: null, css: "", error: `Vue compiler not available: ${String(err)}` };
    }
  });
  handlers.set("code:transform-svelte", async (code) => {
    if (typeof code !== "string") {
      return { js: null, css: "", error: "code must be a string" };
    }
    try {
      const { compileSvelteComponent } = await import(path7.resolve(process.cwd(), "electron", "svelteCompiler.js"));
      return await compileSvelteComponent(code);
    } catch (err) {
      return { js: null, css: "", error: `Svelte compiler not available: ${String(err)}` };
    }
  });
  handlers.set("project:openPath", async (folderPath) => {
    if (typeof folderPath !== "string") return null;
    const normalized = path7.normalize(folderPath);
    if (!isWithinHome(normalized)) return null;
    try {
      const tree = await scanDirectory(normalized);
      const projectName = path7.basename(normalized);
      registryUpsert.run(randomUUID(), projectName, normalized);
      activeProjectRoot = normalized;
      sessionExplicitlyOpened = true;
      return tree;
    } catch {
      return null;
    }
  });
  handlers.set("project:create-scratchpad", async () => {
    const flintProjectsDir = path7.join(os.homedir(), `${BRAND2.product} Projects`);
    await fs2.mkdir(flintProjectsDir, { recursive: true });
    let existing = [];
    try {
      existing = await fs2.readdir(flintProjectsDir);
    } catch {
    }
    let counter = 1;
    while (existing.includes(`Untitled-${counter}`)) counter++;
    const projectName = `Untitled-${counter}`;
    const targetPath = path7.join(flintProjectsDir, projectName);
    await fs2.mkdir(targetPath);
    const templateDir = path7.resolve(__dirname2, "..", "electron", "templates", "base-vite-tailwind");
    if (existsSync6(templateDir)) {
      const { cpSync } = await import("node:fs");
      cpSync(templateDir, targetPath, { recursive: true, force: true });
    }
    const flintDir = path7.join(targetPath, BRAND2.configDir);
    await fs2.mkdir(flintDir, { recursive: true });
    if (!existsSync6(path7.join(flintDir, "design-tokens.json"))) {
      await atomicWrite(path7.join(flintDir, "design-tokens.json"), "[]\n");
    }
    if (!existsSync6(path7.join(flintDir, "policy.json"))) {
      await atomicWrite(path7.join(flintDir, "policy.json"), JSON.stringify({
        version: 1,
        mithril: { deltaE_threshold: 2, deltaE_critical_threshold: 10, mode: "enforce", ignore_patterns: [] },
        a11y: { level: "AA", mode: "enforce", disabled_rules: [] },
        export_gate: { block_on_mithril: true, block_on_a11y: true, block_on_overrides: true },
        baseline: { enabled: false }
      }, null, 2) + "\n");
    }
    registryUpsert.run(randomUUID(), projectName, targetPath);
    activeProjectRoot = targetPath;
    sessionExplicitlyOpened = true;
    void mcp.start(targetPath).catch(() => {
    });
    return scanDirectory(targetPath);
  });
  handlers.set("project:get-last-session", async () => {
    if (!sessionExplicitlyOpened) return null;
    return {
      path: activeProjectRoot,
      name: path7.basename(activeProjectRoot),
      isScratchpad: /Flint Projects\/Untitled/i.test(activeProjectRoot)
    };
  });
  handlers.set("project:initialize", async (payload) => {
    if (typeof payload !== "object" || payload === null || typeof payload.targetPath !== "string" || typeof payload.templateId !== "string") {
      throw new TypeError("project:initialize \u2014 invalid payload shape");
    }
    const { targetPath } = payload;
    validateFilePath(targetPath, false);
    await fs2.mkdir(targetPath, { recursive: true });
    const flintDir = path7.join(targetPath, BRAND2.configDir);
    await fs2.mkdir(flintDir, { recursive: true });
    await atomicWrite(path7.join(flintDir, "design-tokens.json"), "[]\n");
    await atomicWrite(path7.join(flintDir, "policy.json"), JSON.stringify({
      version: 1,
      mithril: { deltaE_threshold: 2, deltaE_critical_threshold: 10, mode: "enforce", ignore_patterns: [] },
      a11y: { level: "AA", mode: "enforce", disabled_rules: [] },
      export_gate: { block_on_mithril: true, block_on_a11y: true, block_on_overrides: true },
      baseline: { enabled: false }
    }, null, 2) + "\n");
    const projectName = path7.basename(targetPath);
    registryUpsert.run(randomUUID(), projectName, targetPath);
    activeProjectRoot = targetPath;
    sessionExplicitlyOpened = true;
    void mcp.start(targetPath).catch(() => {
    });
    return scanDirectory(targetPath);
  });
  handlers.set("project:reset-to-demo", async (targetPath) => {
    if (typeof targetPath !== "string") {
      throw new TypeError("project:reset-to-demo \u2014 targetPath must be a string");
    }
    validateFilePath(targetPath, false);
    const templateDir = path7.resolve(__dirname2, "..", "electron", "templates", "flint-demo");
    if (existsSync6(templateDir)) {
      const { cpSync } = await import("node:fs");
      cpSync(templateDir, targetPath, { recursive: true, force: true });
    }
    const flintDir = path7.join(targetPath, BRAND2.configDir);
    mkdirSync3(flintDir, { recursive: true });
    if (!existsSync6(path7.join(flintDir, "design-tokens.json"))) {
      await atomicWrite(path7.join(flintDir, "design-tokens.json"), "[]\n");
    }
    if (!existsSync6(path7.join(flintDir, "policy.json"))) {
      await atomicWrite(path7.join(flintDir, "policy.json"), JSON.stringify({
        version: 1,
        mithril: { deltaE_threshold: 2, deltaE_critical_threshold: 10, mode: "enforce", ignore_patterns: [] },
        a11y: { level: "AA", mode: "enforce", disabled_rules: [] },
        export_gate: { block_on_mithril: true, block_on_a11y: true, block_on_overrides: true },
        baseline: { enabled: false }
      }, null, 2) + "\n");
    }
    return scanDirectory(targetPath);
  });
  handlers.set("project:reindex", async () => {
    try {
      const { indexComponents: indexComponents2 } = await Promise.resolve().then(() => (init_componentIndexer(), componentIndexer_exports));
      const indexResult = await indexComponents2(activeProjectRoot);
      const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
      let manifest = {};
      try {
        const raw = await fs2.readFile(manifestPath, "utf-8");
        manifest = JSON.parse(raw);
      } catch {
      }
      manifest.components = indexResult.components;
      await atomicWrite(manifestPath, JSON.stringify(manifest, null, 2) + "\n");
      const ragResult = await rag.seedFromProject(activeProjectRoot);
      console.log(
        `${BRAND2.logPrefix} Reindex complete \u2014 ${indexResult.count} components, ${ragResult.ingested} RAG chunks`
      );
      return { components: indexResult.count, ragChunks: ragResult.ingested };
    } catch (err) {
      console.error(`${BRAND2.logPrefix} Reindex failed:`, err);
      return { components: 0, ragChunks: 0 };
    }
  });
  handlers.set("registry:getRecent", async () => registryGetRecent.all());
  handlers.set("registry:upsertProject", async (payload) => {
    if (typeof payload !== "object" || payload === null || typeof payload.name !== "string" || typeof payload.path !== "string") return;
    const { name, path: projectPath } = payload;
    if (!path7.isAbsolute(projectPath)) return;
    registryUpsert.run(randomUUID(), name, projectPath);
  });
  handlers.set("registry:removeProject", async (id) => {
    if (typeof id !== "string" || id.length === 0) return;
    registryRemove.run(id);
  });
  handlers.set("ast:git-show", async (filePath, commitHash) => {
    if (typeof filePath !== "string" || typeof commitHash !== "string") return null;
    if (!/^([0-9a-fA-F]{4,64}|HEAD)$/.test(commitHash)) return null;
    if (!path7.isAbsolute(filePath)) return null;
    if (!isWithinHome(filePath)) return null;
    try {
      const cwd = path7.dirname(filePath);
      const { stdout: rootRaw } = await execFileAsync("git", ["rev-parse", "--show-toplevel"], { cwd });
      const gitRoot = rootRaw.trim();
      const relPath = path7.relative(gitRoot, filePath);
      const { stdout } = await execFileAsync(
        "git",
        ["show", `${commitHash}:${relPath}`],
        { cwd: gitRoot, maxBuffer: 2 * 1024 * 1024 }
      );
      return stdout;
    } catch {
      return null;
    }
  });
  handlers.set("ast:git-log", async (filePath) => {
    if (typeof filePath !== "string") return [];
    if (!path7.isAbsolute(filePath)) return [];
    if (!isWithinHome(filePath)) return [];
    try {
      const cwd = path7.dirname(filePath);
      const { stdout: rootRaw } = await execFileAsync("git", ["rev-parse", "--show-toplevel"], { cwd });
      const gitRoot = rootRaw.trim();
      const relPath = path7.relative(gitRoot, filePath);
      const { stdout } = await execFileAsync(
        "git",
        ["log", "--pretty=format:%h|%s|%at", "-n", "50", "--", relPath],
        { cwd: gitRoot, maxBuffer: 1024 * 1024 }
      );
      const entries = [];
      for (const line of stdout.split("\n")) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        const parts = trimmed.split("|");
        if (parts.length < 3) continue;
        const hash = parts[0];
        const timestamp = parseInt(parts[parts.length - 1], 10);
        const message = parts.slice(1, parts.length - 1).join("|");
        if (hash && !isNaN(timestamp)) {
          entries.push({ hash, message, timestamp });
        }
      }
      return entries;
    } catch {
      return [];
    }
  });
  handlers.set("sync:update-presence", async (payload) => {
    if (typeof payload !== "object" || payload === null || typeof payload.id !== "string" || typeof payload.userId !== "string" || typeof payload.x !== "number" || typeof payload.y !== "number") {
      throw new Error("sync:update-presence \u2014 invalid payload");
    }
    const p = payload;
    stmtUpsertPresence.run(p.id, p.userId, p.nodeId ?? "", p.x, p.y);
  });
  handlers.set("sync:read-presence", async () => stmtReadPresence.all());
  handlers.set("policy:get", async () => {
    const policyPath = path7.join(activeProjectRoot, BRAND2.configDir, "policy.json");
    try {
      const raw = await fs2.readFile(policyPath, "utf-8");
      return JSON.parse(raw);
    } catch {
      return {
        version: 1,
        mithril: { deltaE_threshold: 2, deltaE_critical_threshold: 10, mode: "enforce", ignore_patterns: [] },
        a11y: { level: "AA", mode: "enforce", disabled_rules: [] },
        export_gate: { block_on_mithril: true, block_on_a11y: true, block_on_overrides: true },
        baseline: { enabled: false },
        risk_tiers: { green: { max_score: 30 }, amber: { max_score: 70 }, red: { max_score: 100 } },
        approval_gates: { amber: "warn", red: "block" }
      };
    }
  });
  handlers.set("context:sync", async (context) => {
    if (typeof context !== "object" || context === null) {
      throw new TypeError("context:sync \u2014 payload must be a non-null object");
    }
    const flintDir = path7.join(activeProjectRoot, BRAND2.configDir);
    await fs2.mkdir(flintDir, { recursive: true });
    const contextPath = path7.join(flintDir, "context.json");
    await atomicWrite(contextPath, JSON.stringify(context, null, 2));
  });
  handlers.set("context:get-enriched", async () => {
    const contextPath = path7.join(activeProjectRoot, BRAND2.configDir, "context.json");
    let base = {};
    try {
      const raw = await fs2.readFile(contextPath, "utf-8");
      base = JSON.parse(raw);
    } catch {
      base = { timestamp: Date.now(), activeFile: null };
    }
    const tokenCount = stmtTokenCount.get().count;
    const activeOverrideCount = stmtOverrideCount.get().count;
    return {
      ...base,
      tokenCount,
      activeOverrideCount,
      enrichedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  });
  handlers.set("governance:record-override", async (payload) => {
    if (typeof payload !== "object" || payload === null || typeof payload.ruleId !== "string" || typeof payload.action !== "string" || typeof payload.filePath !== "string") {
      throw new TypeError("governance:record-override \u2014 invalid payload shape");
    }
    const p = payload;
    govInsert.run(
      "override",
      p.ruleId,
      "info",
      p.filePath,
      "user",
      governanceSessionId,
      JSON.stringify({ action: p.action, newValue: p.newValue })
    );
    broadcast("flint:governance-override-recorded", {});
  });
  handlers.set("governance:override-count", async () => {
    const row = govOverrideCount.get(governanceSessionId);
    return row?.count ?? 0;
  });
  handlers.set("governance:compliance-summary", async (_ruleIds) => {
    return { authorities: {}, totalRules: 0, coveredRules: 0 };
  });
  handlers.set("governance:defer-violation", async (filePath, ruleId, nodeId, reason) => {
    if (typeof filePath !== "string" || typeof ruleId !== "string") {
      throw new TypeError("governance:defer-violation \u2014 filePath and ruleId must be strings");
    }
    const nId = typeof nodeId === "string" ? nodeId : null;
    const r = typeof reason === "string" ? reason : null;
    deferViolationUpsert.run(filePath, ruleId, nId, r, governanceSessionId);
  });
  handlers.set("governance:get-deferred-violations", async () => {
    return deferViolationSelectUnresolved.all();
  });
  handlers.set("governance:resolve-deferred-violation", async (filePath, ruleId, nodeId) => {
    if (typeof filePath !== "string" || typeof ruleId !== "string") {
      throw new TypeError("governance:resolve-deferred-violation \u2014 filePath and ruleId must be strings");
    }
    const nId = typeof nodeId === "string" ? nodeId : null;
    deferViolationResolve.run(filePath, ruleId, nId, nId);
  });
  handlers.set("baseline:set", async (violations) => {
    if (!Array.isArray(violations)) {
      throw new TypeError("baseline:set \u2014 violations must be an array");
    }
    const insertMany = db.transaction(
      (rows2) => {
        for (const row of rows2) {
          baselineUpsert.run(row.filePath, row.nodeId, row.ruleId, row.severity, row.value ?? null);
        }
      }
    );
    const rows = violations.filter(
      (v) => typeof v.nodeId === "string" && typeof v.ruleId === "string" && typeof v.severity === "string" && typeof v.filePath === "string"
    ).map((v) => ({
      filePath: v.filePath,
      nodeId: v.nodeId,
      ruleId: v.ruleId,
      severity: v.severity,
      value: typeof v.value === "string" ? v.value : void 0
    }));
    insertMany(rows);
    console.log(`${BRAND2.logPrefix} baseline:set \u2014 ${rows.length} violations baselined`);
  });
  handlers.set("baseline:get", async (filePath) => {
    if (typeof filePath !== "string" || filePath.length === 0) {
      throw new TypeError("baseline:get \u2014 filePath must be a non-empty string");
    }
    return baselineSelect.all(filePath);
  });
  handlers.set("baseline:clear", async () => {
    const result = baselineClear.run();
    console.log(`${BRAND2.logPrefix} baseline:clear \u2014 ${result.changes} rows removed`);
  });
  handlers.set("baseline:is-set", async () => {
    const row = baselineIsSet.get();
    return (row?.count ?? 0) > 0;
  });
  const { MCPClient: MCPClient2 } = await Promise.resolve().then(() => (init_mcpClient(), mcpClient_exports));
  const mcp = new MCPClient2();
  void mcp.start(activeProjectRoot).catch((err) => {
    console.warn(`${BRAND2.logPrefix} MCP client failed to start: ${err.message}`);
    console.warn(`${BRAND2.logPrefix} Ensure flint-mcp is built: cd flint-mcp && npm run build`);
  });
  handlers.set("mcp:call-tool", async (name, args) => {
    return mcp.callTool(
      name,
      args ?? {}
    );
  });
  handlers.set("mcp:read-resource", async (uri) => {
    return mcp.readResource(uri);
  });
  handlers.set("mcp:status", async () => mcp.status());
  handlers.set("mcp:reconnect", async () => mcp.reconnect());
  {
    let getMCPEventsFilePath = function() {
      return path7.join(activeProjectRoot, BRAND2.configDir, "mcp-events.jsonl");
    }, flushMCPEventsBatch = function() {
      if (mcpEventsBatch.length === 0) return;
      const events = mcpEventsBatch.splice(0);
      broadcast("flint:mcp-event", events);
    }, startMCPEventsWatcher = function() {
      const filePath = getMCPEventsFilePath();
      const dir = path7.dirname(filePath);
      const basename = path7.basename(filePath);
      if (!existsSync6(dir)) mkdirSync3(dir, { recursive: true });
      try {
        mcpEventsWatcher = fsWatch(dir, { persistent: false }, (_event, filename) => {
          if (filename === basename) {
            void tailMCPEvents();
          }
        });
        mcpEventsWatcher.on("error", () => {
          if (mcpEventsWatcher) {
            mcpEventsWatcher.close();
            mcpEventsWatcher = null;
          }
        });
      } catch {
      }
      const pollInterval = setInterval(() => void tailMCPEvents(), 1e4);
      const origClose = server.close.bind(server);
      server.close = (callback) => {
        clearInterval(pollInterval);
        if (mcpEventsWatcher) {
          mcpEventsWatcher.close();
          mcpEventsWatcher = null;
        }
        if (mcpEventsBatchTimer !== null) {
          clearTimeout(mcpEventsBatchTimer);
          flushMCPEventsBatch();
        }
        return origClose(callback);
      };
      console.log(`${BRAND2.logPrefix} MCP event push channel active \u2014 watching ${filePath}`);
    };
    let mcpEventsOffset = 0;
    let mcpEventsBatchTimer = null;
    const mcpEventsBatch = [];
    let mcpEventsWatcher = null;
    async function tailMCPEvents() {
      const filePath = getMCPEventsFilePath();
      try {
        const stat = await fs2.stat(filePath);
        const size = stat.size;
        if (size < mcpEventsOffset) {
          mcpEventsOffset = 0;
        }
        if (size === mcpEventsOffset) return;
        const fd = await fs2.open(filePath, "r");
        try {
          const bytesToRead = size - mcpEventsOffset;
          const buf = Buffer.alloc(bytesToRead);
          const { bytesRead } = await fd.read(buf, 0, bytesToRead, mcpEventsOffset);
          mcpEventsOffset += bytesRead;
          const chunk = buf.subarray(0, bytesRead).toString("utf-8");
          for (const line of chunk.split("\n")) {
            const trimmed = line.trim();
            if (!trimmed) continue;
            try {
              const event = JSON.parse(trimmed);
              mcpEventsBatch.push(event);
            } catch {
            }
          }
        } finally {
          await fd.close();
        }
        if (mcpEventsBatch.length > 0) {
          if (mcpEventsBatchTimer !== null) clearTimeout(mcpEventsBatchTimer);
          mcpEventsBatchTimer = setTimeout(() => {
            mcpEventsBatchTimer = null;
            flushMCPEventsBatch();
          }, 500);
        }
      } catch {
      }
    }
    setTimeout(() => startMCPEventsWatcher(), 2e3);
  }
  handlers.set("annotations:read-all", async () => {
    const filePath = path7.join(activeProjectRoot, BRAND2.configDir, "annotations.json");
    try {
      const raw = await fs2.readFile(filePath, "utf-8");
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed;
    } catch {
      return [];
    }
  });
  handlers.set("annotations:resolve", async (id) => {
    if (typeof id !== "string" || id.length === 0) return;
    const filePath = path7.join(activeProjectRoot, BRAND2.configDir, "annotations.json");
    try {
      const raw = await fs2.readFile(filePath, "utf-8");
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;
      let changed = false;
      const updated = parsed.map((a) => {
        if (a.id === id && a.status !== "resolved") {
          changed = true;
          return { ...a, status: "resolved", resolvedAt: (/* @__PURE__ */ new Date()).toISOString() };
        }
        return a;
      });
      if (changed) {
        await atomicWrite(filePath, JSON.stringify(updated, null, 2));
        broadcast("flint:annotations-changed", {});
      }
    } catch {
    }
  });
  handlers.set("setup:detect-ides", async () => {
    const home = os.homedir();
    const claudeSettingsPath = path7.join(home, ".claude", "settings.json");
    const claudeMcpPath = path7.join(home, ".claude", "mcp.json");
    const ides = [
      {
        name: "Claude Code",
        settingsPath: existsSync6(claudeMcpPath) ? claudeMcpPath : claudeSettingsPath,
        detected: existsSync6(claudeSettingsPath) || existsSync6(claudeMcpPath)
      },
      {
        name: "Antigravity",
        settingsPath: path7.join(home, ".gemini", "antigravity", "mcp_config.json"),
        detected: existsSync6(path7.join(home, "Library", "Application Support", "Antigravity", "User", "settings.json"))
      },
      {
        name: "Cursor",
        settingsPath: path7.join(home, "Library", "Application Support", "Cursor", "User", "settings.json"),
        detected: existsSync6(path7.join(home, "Library", "Application Support", "Cursor", "User", "settings.json"))
      },
      {
        name: "VS Code",
        settingsPath: path7.join(home, "Library", "Application Support", "Code", "User", "settings.json"),
        detected: existsSync6(path7.join(home, "Library", "Application Support", "Code", "User", "settings.json"))
      }
    ];
    const mcpServerPath = path7.resolve(__dirname2, "..", "flint-mcp", "dist", "server.js");
    return { ides, mcpServerPath };
  });
  handlers.set("setup:check-first-launch", async () => {
    const setupPath = path7.join(os.homedir(), BRAND2.configDir, "setup.json");
    try {
      const raw = readFileSync4(setupPath, "utf-8");
      const parsed = JSON.parse(raw);
      return { isFirstLaunch: parsed.firstLaunchComplete !== true };
    } catch {
      return { isFirstLaunch: true };
    }
  });
  handlers.set("setup:complete-first-launch", async () => {
    const flintDir = path7.join(os.homedir(), BRAND2.configDir);
    mkdirSync3(flintDir, { recursive: true });
    const setupPath = path7.join(flintDir, "setup.json");
    writeFileSync3(
      setupPath,
      JSON.stringify({ firstLaunchComplete: true, completedAt: Date.now() }, null, 2),
      "utf-8"
    );
  });
  handlers.set("app:reset-state", async () => {
    const setupPath = path7.join(os.homedir(), BRAND2.configDir, "setup.json");
    try {
      if (existsSync6(setupPath)) rmSync(setupPath);
    } catch (err) {
      console.error(`${BRAND2.logPrefix} app:reset-state \u2014 could not delete setup.json:`, err);
    }
  });
  handlers.set("setup:write-mcp-config", async (ideName, configPath, mcpServerPath) => {
    if (typeof configPath !== "string" || typeof mcpServerPath !== "string") {
      return { written: false };
    }
    try {
      let config = {};
      if (existsSync6(configPath)) {
        try {
          config = JSON.parse(readFileSync4(configPath, "utf8"));
        } catch {
        }
      }
      const mcpServers = config.mcpServers ?? {};
      mcpServers["flint"] = {
        command: "node",
        args: [mcpServerPath],
        env: { FLINT_PROJECT_ROOT: activeProjectRoot }
      };
      config.mcpServers = mcpServers;
      await fs2.mkdir(path7.dirname(configPath), { recursive: true });
      writeFileSync3(configPath, JSON.stringify(config, null, 2));
      console.log(`${BRAND2.logPrefix} Wrote MCP config to ${configPath} for ${ideName}`);
      return { written: true };
    } catch (err) {
      console.error(`${BRAND2.logPrefix} setup:write-mcp-config failed:`, err);
      return { written: false };
    }
  });
  const { createIngestionServer: createIngestionServer2 } = await Promise.resolve().then(() => (init_ingestionServer(), ingestionServer_exports));
  const ingestion = createIngestionServer2();
  const sessionSecret = randomUUID();
  void ingestion.start(activeProjectRoot, { secret: sessionSecret }).then(({ port: ingPort }) => {
    console.log(`${BRAND2.logPrefix} Ingestion server listening on port ${ingPort}`);
  }).catch((err) => {
    console.warn(`${BRAND2.logPrefix} Ingestion server failed: ${err.message}`);
  });
  ingestion.onIngest((data) => broadcast("flint:figma-connected", data));
  ingestion.onError((data) => broadcast("flint:figma-error", data));
  handlers.set("server:get-status", async () => {
    const status = ingestion.status();
    return { running: status.running, port: status.port || port };
  });
  handlers.set("figma:status", async () => {
    const status = ingestion.status();
    return {
      running: status.running,
      lastWebhookAt: status.lastWebhookAt,
      tokenCount: status.tokenCount,
      port: status.port
    };
  });
  handlers.set("figma:disconnect", async () => {
    await ingestion.stop();
  });
  const aiConfigPath = path7.join(os.homedir(), BRAND2.configDir, "config.json");
  handlers.set("ai:get-config", async () => {
    try {
      if (existsSync6(aiConfigPath)) {
        const raw = readFileSync4(aiConfigPath, "utf8");
        const cfg = JSON.parse(raw);
        return {
          hasKey: !!(cfg.apiKey || process.env.ANTHROPIC_API_KEY),
          provider: cfg.provider ?? "anthropic",
          model: cfg.model ?? null,
          baseURL: cfg.baseURL ?? null
        };
      }
    } catch {
    }
    return {
      hasKey: !!process.env.ANTHROPIC_API_KEY,
      provider: "anthropic",
      model: null,
      baseURL: null
    };
  });
  handlers.set("ai:save-config", async (config) => {
    const configDir = path7.join(os.homedir(), BRAND2.configDir);
    if (!existsSync6(configDir)) mkdirSync3(configDir, { recursive: true });
    let existing = {};
    try {
      if (existsSync6(aiConfigPath)) {
        existing = JSON.parse(readFileSync4(aiConfigPath, "utf8"));
      }
    } catch {
    }
    const merged = { ...existing, ...config };
    writeFileSync3(aiConfigPath, JSON.stringify(merged, null, 2));
  });
  const { createAIChatService: createAIChatService2 } = await Promise.resolve().then(() => (init_aiChat(), aiChat_exports));
  const aiChat = createAIChatService2(aiConfigPath);
  handlers.set("ai:chat", async (messages, context) => {
    await aiChat.chat(
      messages,
      context,
      (chunk) => broadcast("ai:chunk", chunk)
    );
  });
  handlers.set("ai:apply-batch", async () => ({ ok: true }));
  const { createRAGService: createRAGService2 } = await Promise.resolve().then(() => (init_ragStore(), ragStore_exports));
  const rag = createRAGService2(db);
  handlers.set("ai:query-rag", async (query) => {
    return rag.query(query);
  });
  handlers.set("ai:ingest-rag", async (chunks) => {
    return rag.ingest(chunks);
  });
  handlers.set("ai:clear-rag", async () => {
    await rag.clear();
  });
  handlers.set("ai:rag-count", async () => rag.count());
  handlers.set("ai:seed-rag", async () => {
    return rag.seedFromProject(activeProjectRoot);
  });
  handlers.set("beta:get-info", async () => ({
    buildId: "web",
    expiryDate: null,
    daysRemaining: null,
    isBeta: false
  }));
  handlers.set("beta:submit-feedback", async (feedback) => {
    try {
      const feedbackDir = path7.join(os.homedir(), BRAND2.configDir, "feedback");
      if (!existsSync6(feedbackDir)) mkdirSync3(feedbackDir, { recursive: true });
      const filename = `feedback-${Date.now()}.json`;
      const entry = {
        ...feedback,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        buildId: "web",
        projectRoot: activeProjectRoot
      };
      writeFileSync3(path7.join(feedbackDir, filename), JSON.stringify(entry, null, 2));
      return { saved: true };
    } catch {
      return { saved: false };
    }
  });
  handlers.set("beta:load-demo-project", async () => {
    try {
      const demoSourceDir = path7.resolve(__dirname2, "..", "build-resources", "demo-project");
      if (!existsSync6(demoSourceDir)) {
        return { error: "Demo project bundle not found at " + demoSourceDir };
      }
      const tmpBase = path7.join(os.tmpdir(), "flint-beta-demo");
      mkdirSync3(tmpBase, { recursive: true });
      const projectDir = path7.join(tmpBase, `demo-${Date.now()}`);
      mkdirSync3(projectDir, { recursive: true });
      await fs2.cp(demoSourceDir, projectDir, { recursive: true });
      const tokensSrc = path7.join(projectDir, "design-tokens.json");
      if (existsSync6(tokensSrc)) {
        const flintDir = path7.join(projectDir, BRAND2.configDir);
        mkdirSync3(flintDir, { recursive: true });
        const tokensContent = await fs2.readFile(tokensSrc);
        await fs2.writeFile(path7.join(flintDir, "design-tokens.json"), tokensContent);
      }
      return { projectPath: projectDir };
    } catch (err) {
      return { error: err instanceof Error ? err.message : String(err) };
    }
  });
  handlers.set("beta:capture-screenshot", async () => null);
  let auditAllFn = null;
  let a11yAuditFn = null;
  try {
    const mithrilMod = await Promise.resolve().then(() => (init_MithrilLinter(), MithrilLinter_exports));
    const a11yMod = await Promise.resolve().then(() => (init_A11yLinter(), A11yLinter_exports));
    auditAllFn = mithrilMod.auditAll;
    a11yAuditFn = (ast) => a11yMod.A11yLinter.audit(ast);
    console.log(`${BRAND2.logPrefix} Component health linters loaded successfully`);
  } catch {
    console.warn(`${BRAND2.logPrefix} flint-mcp linters not available \u2014 component health will be null`);
  }
  async function enrichComponentHealth(filePath, tokens, auditAll2, a11yAudit) {
    try {
      const code = await fs2.readFile(filePath, "utf-8");
      const { parse: parse2 } = await import("@babel/parser");
      const ast = parse2(code, { sourceType: "module", plugins: ["typescript", "jsx"] });
      const mithrilWarnings = auditAll2(ast, tokens);
      const mithrilCount = mithrilWarnings.size;
      let maxDeltaE = 0;
      for (const warning of mithrilWarnings.values()) {
        const de = typeof warning.value === "number" ? warning.value : 0;
        if (de > maxDeltaE) maxDeltaE = de;
      }
      const a11yViolations = a11yAudit(ast);
      const a11yCount = Object.values(a11yViolations).reduce(
        (sum, msgs) => sum + msgs.length,
        0
      );
      const violationCount = mithrilCount + a11yCount;
      let grade;
      if (violationCount === 0 && maxDeltaE < 2) grade = "A";
      else if (violationCount <= 2 && maxDeltaE < 5) grade = "B";
      else if (violationCount <= 5 && maxDeltaE < 10) grade = "C";
      else if (violationCount <= 10) grade = "D";
      else grade = "F";
      return { grade, maxDeltaE, violationCount, mithrilCount, a11yCount };
    } catch {
      return null;
    }
  }
  handlers.set("components:list", async () => {
    const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
    try {
      let deriveCategory = function(filePath) {
        const n = filePath.replace(/\\/g, "/");
        if (/\/primitives\//.test(n) || /\/atoms\//.test(n)) return "primitive";
        if (/\/molecules\//.test(n)) return "molecule";
        if (/\/organisms\//.test(n) || /\/templates\//.test(n)) return "organism";
        if (/\/pages\//.test(n)) return "page";
        if (/\/layouts\//.test(n)) return "layout";
        return "uncategorized";
      }, makeComponentId = function(name, importPath) {
        const input = `${name}::${importPath}`;
        let hash = 5381;
        for (let i = 0; i < input.length; i++) {
          hash = (hash << 5) + hash ^ input.charCodeAt(i);
        }
        return (hash >>> 0).toString(16).padStart(8, "0");
      };
      const raw = await fs2.readFile(manifestPath, "utf-8");
      const manifest = JSON.parse(raw);
      const components = manifest.components ?? {};
      let categoryOverrides = {};
      try {
        const overridesPath = path7.join(activeProjectRoot, BRAND2.configDir, "category-overrides.json");
        if (existsSync6(overridesPath)) {
          const raw2 = readFileSync4(overridesPath, "utf-8");
          const parsed = JSON.parse(raw2);
          if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) {
            categoryOverrides = parsed;
          }
        }
      } catch {
      }
      const VALID_CATEGORIES = /* @__PURE__ */ new Set(["primitive", "molecule", "organism", "page", "layout", "uncategorized"]);
      const categoryOrder = {
        primitive: 0,
        molecule: 1,
        organism: 2,
        page: 3,
        layout: 4,
        uncategorized: 5
      };
      const thumbnailBase = path7.join(activeProjectRoot, BRAND2.configDir, "thumbnails");
      let designTokens = [];
      if (auditAllFn) {
        try {
          const rows = stmtReadAll.all();
          designTokens = rows;
        } catch {
          designTokens = [];
        }
      }
      const cards = await Promise.all(Object.entries(components).map(async ([name, entry]) => {
        const e = entry ?? {};
        const importPath = typeof e.importPath === "string" ? e.importPath : "";
        const filePath = typeof e.filePath === "string" ? e.filePath : "";
        const variants = Array.isArray(e.variants) ? e.variants : [];
        const propsRaw = e.props ?? {};
        const id = makeComponentId(name, importPath);
        let thumbnailPath2 = null;
        const tp = path7.join(thumbnailBase, `${id}.png`);
        if (existsSync6(tp)) thumbnailPath2 = tp;
        const props = {};
        for (const [propName, propDef] of Object.entries(propsRaw)) {
          const p = propDef ?? {};
          props[propName] = {
            type: typeof p.type === "string" ? p.type : "unknown",
            required: typeof p.required === "boolean" ? p.required : false
          };
        }
        let health = null;
        if (filePath && auditAllFn && a11yAuditFn) {
          const resolvedPath = path7.isAbsolute(filePath) ? filePath : path7.join(activeProjectRoot, filePath);
          health = await enrichComponentHealth(resolvedPath, designTokens, auditAllFn, a11yAuditFn);
        }
        let category = deriveCategory(filePath);
        const override = categoryOverrides[id];
        if (override && VALID_CATEGORIES.has(override)) category = override;
        return {
          id,
          name,
          importPath,
          filePath,
          category,
          variantCount: variants.length,
          variants,
          props,
          thumbnailPath: thumbnailPath2,
          health,
          tokens: Array.isArray(e.tokens) ? e.tokens : [],
          dependencies: Array.isArray(e.dependencies) ? e.dependencies : [],
          // Pass through any extra manifest fields (description, usageExample, etc.)
          ...typeof e.description === "string" ? { description: e.description } : {},
          ...typeof e.usageExample === "string" ? { usageExample: e.usageExample } : {},
          ...typeof e.compositionNotes === "string" ? { compositionNotes: e.compositionNotes } : {},
          ...typeof e.a11yNotes === "string" ? { a11yNotes: e.a11yNotes } : {},
          ...Array.isArray(e.relatedComponents) ? { relatedComponents: e.relatedComponents } : {}
        };
      }));
      cards.sort((a, b) => {
        const d = (categoryOrder[a.category] ?? 5) - (categoryOrder[b.category] ?? 5);
        return d !== 0 ? d : a.name.localeCompare(b.name);
      });
      return cards;
    } catch {
      return [];
    }
  });
  handlers.set("components:save-positions", async (positions) => {
    if (typeof positions !== "object" || positions === null || Array.isArray(positions)) return;
    const posPath = path7.join(activeProjectRoot, BRAND2.configDir, "card-positions.json");
    await fs2.mkdir(path7.dirname(posPath), { recursive: true });
    await atomicWrite(posPath, JSON.stringify(positions, null, 2));
  });
  handlers.set("components:load-positions", async () => {
    const posPath = path7.join(activeProjectRoot, BRAND2.configDir, "card-positions.json");
    try {
      const raw = await fs2.readFile(posPath, "utf-8");
      const parsed = JSON.parse(raw);
      if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) {
        return parsed;
      }
      return {};
    } catch {
      return {};
    }
  });
  handlers.set("components:set-category", async (payload) => {
    if (typeof payload !== "object" || payload === null) return;
    const p = payload;
    if (typeof p.componentId !== "string" || typeof p.category !== "string") return;
    const overridesPath = path7.join(activeProjectRoot, BRAND2.configDir, "category-overrides.json");
    let overrides = {};
    try {
      const raw = await fs2.readFile(overridesPath, "utf-8");
      overrides = JSON.parse(raw);
    } catch {
    }
    overrides[p.componentId] = p.category;
    await fs2.mkdir(path7.dirname(overridesPath), { recursive: true });
    await atomicWrite(overridesPath, JSON.stringify(overrides, null, 2));
  });
  handlers.set("components:health", async () => {
    const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
    let components = {};
    try {
      const raw = await fs2.readFile(manifestPath, "utf-8");
      const manifest = JSON.parse(raw);
      components = manifest.components ?? {};
    } catch {
      return {};
    }
    const mcpConnected = mcp.status().connected;
    if (!mcpConnected) {
      const result = {};
      for (const name of Object.keys(components)) {
        result[name] = null;
      }
      return result;
    }
    function gradeFromCounts(violationCount, maxDeltaE) {
      if (violationCount === 0 && maxDeltaE < 2) return "A";
      if (violationCount <= 2 && maxDeltaE < 5) return "B";
      if (violationCount <= 5 && maxDeltaE < 10) return "C";
      if (violationCount <= 10) return "D";
      return "F";
    }
    function extractMaxDeltaE(violations) {
      let max = 0;
      for (const v of violations) {
        const m = v.message?.match(/ΔE\s+([\d.]+)/);
        if (m) {
          const val = parseFloat(m[1]);
          if (!isNaN(val) && val > max) max = val;
        }
      }
      return max;
    }
    const healthMap = {};
    for (const [name, entry] of Object.entries(components)) {
      const e = entry ?? {};
      const rawFilePath = typeof e.filePath === "string" ? e.filePath : null;
      if (!rawFilePath) {
        healthMap[name] = null;
        continue;
      }
      const resolvedPath = path7.isAbsolute(rawFilePath) ? rawFilePath : path7.join(activeProjectRoot, rawFilePath);
      try {
        const source = await fs2.readFile(resolvedPath, "utf-8");
        const auditResult = await mcp.callTool("flint_audit", {
          source,
          filePath: resolvedPath
        });
        const text = auditResult.content?.[0]?.text ?? "{}";
        const jsonEnd = text.lastIndexOf("}");
        const jsonText = jsonEnd !== -1 ? text.slice(0, jsonEnd + 1) : text;
        const parsed = JSON.parse(jsonText);
        const mithrilCount = typeof parsed.mithrilCount === "number" ? parsed.mithrilCount : 0;
        const a11yCount = typeof parsed.a11yCount === "number" ? parsed.a11yCount : 0;
        const violations = Array.isArray(parsed.violations) ? parsed.violations : [];
        const violationCount = mithrilCount + a11yCount;
        const maxDeltaE = extractMaxDeltaE(violations);
        const grade = gradeFromCounts(violationCount, maxDeltaE);
        healthMap[name] = { grade, maxDeltaE, violationCount, mithrilCount, a11yCount };
      } catch {
        healthMap[name] = null;
      }
    }
    return healthMap;
  });
  handlers.set("scope:get-registry-and-scope", async () => {
    let registry = [];
    try {
      const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
      if (existsSync6(manifestPath)) {
        const raw = readFileSync4(manifestPath, "utf8");
        const manifest = JSON.parse(raw);
        const components = manifest.components ?? {};
        registry = Object.entries(components).map(([name, entry]) => ({
          name,
          ...entry
        }));
      }
    } catch {
    }
    let scope = null;
    try {
      const policyPath = path7.join(activeProjectRoot, BRAND2.configDir, "policy.json");
      if (existsSync6(policyPath)) {
        const raw = readFileSync4(policyPath, "utf8");
        const policy = JSON.parse(raw);
        if (Array.isArray(policy.componentScope)) {
          scope = policy.componentScope;
        }
      }
    } catch {
    }
    return { registry, scope };
  });
  handlers.set("scope:set-scope", async (update) => {
    const policyPath = path7.join(activeProjectRoot, BRAND2.configDir, "policy.json");
    let policy = {};
    try {
      if (existsSync6(policyPath)) {
        policy = JSON.parse(readFileSync4(policyPath, "utf8"));
      }
    } catch {
    }
    const { scope } = update ?? {};
    if (scope === null) {
      delete policy.componentScope;
    } else {
      policy.componentScope = scope;
    }
    const flintDir = path7.join(activeProjectRoot, BRAND2.configDir);
    if (!existsSync6(flintDir)) mkdirSync3(flintDir, { recursive: true });
    const tmpPath = policyPath + ".tmp";
    writeFileSync3(tmpPath, JSON.stringify(policy, null, 2));
    await fs2.rename(tmpPath, policyPath);
    return { ok: true };
  });
  const availableLibraries = [
    { library: "shadcn", displayName: "shadcn/ui" },
    { library: "mui", displayName: "Material UI (MUI)" },
    { library: "primeng", displayName: "PrimeNG / PrimeReact / PrimeVue" },
    { library: "tailwind", displayName: "Tailwind CSS" }
  ];
  handlers.set("library:get-active", async () => {
    try {
      const policyPath = path7.join(activeProjectRoot, BRAND2.configDir, "policy.json");
      if (existsSync6(policyPath)) {
        const policy = JSON.parse(readFileSync4(policyPath, "utf8"));
        return { library: policy.selectedLibrary ?? null, availableLibraries };
      }
    } catch {
    }
    return { library: null, availableLibraries };
  });
  handlers.set("library:set-active", async (payload) => {
    if (typeof payload !== "object" || payload === null) {
      return { ok: false, library: null, seeded: 0, error: "Invalid payload" };
    }
    const { library } = payload;
    if (library !== null && typeof library !== "string") {
      return { ok: false, library: null, seeded: 0, error: "library must be a string or null" };
    }
    try {
      const policyPath = path7.join(activeProjectRoot, BRAND2.configDir, "policy.json");
      let policy = {};
      if (existsSync6(policyPath)) {
        try {
          policy = JSON.parse(readFileSync4(policyPath, "utf8"));
        } catch {
        }
      }
      if (!library || library === "none") {
        delete policy.selectedLibrary;
      } else {
        policy.selectedLibrary = library;
      }
      const flintDir = path7.join(activeProjectRoot, BRAND2.configDir);
      if (!existsSync6(flintDir)) mkdirSync3(flintDir, { recursive: true });
      const tmpPath = policyPath + ".tmp";
      writeFileSync3(tmpPath, JSON.stringify(policy, null, 2) + "\n");
      await fs2.rename(tmpPath, policyPath);
      return { ok: true, library, seeded: 0 };
    } catch (err) {
      return { ok: false, library: null, seeded: 0, error: err instanceof Error ? err.message : String(err) };
    }
  });
  handlers.set("enrichment:get-drafts", async () => {
    try {
      const draftsPath = path7.join(activeProjectRoot, BRAND2.configDir, "enrichment-drafts.json");
      let drafts = {};
      if (existsSync6(draftsPath)) {
        try {
          const raw = await fs2.readFile(draftsPath, "utf-8");
          const parsed = JSON.parse(raw);
          drafts = typeof parsed.drafts === "object" && parsed.drafts !== null ? parsed.drafts : parsed;
        } catch {
          drafts = {};
        }
      }
      const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
      let total = 0, enriched = 0;
      if (existsSync6(manifestPath)) {
        try {
          const raw = await fs2.readFile(manifestPath, "utf-8");
          const manifest = JSON.parse(raw);
          const components = manifest.components ?? {};
          for (const entry of Object.values(components)) {
            const e = entry ?? {};
            total++;
            if (typeof e.description === "string" && e.description.length > 0 && typeof e.usageExample === "string" && e.usageExample.length > 0) {
              enriched++;
            }
          }
        } catch {
        }
      }
      const draftCount = Object.keys(drafts).length;
      const bare = Math.max(0, total - enriched - draftCount);
      return { drafts, enrichmentStats: { bare, draft: draftCount, enriched, total } };
    } catch {
      return null;
    }
  });
  handlers.set("enrichment:approve", async (payload) => {
    try {
      if (typeof payload !== "object" || payload === null || !("componentName" in payload) || !("action" in payload)) {
        return { ok: false, remainingDrafts: 0, error: "Invalid payload" };
      }
      const { componentName, action, editedFields } = payload;
      const flintDir = path7.join(activeProjectRoot, BRAND2.configDir);
      if (!existsSync6(flintDir)) mkdirSync3(flintDir, { recursive: true });
      const draftsPath = path7.join(flintDir, "enrichment-drafts.json");
      let draftsWrapper = { drafts: {} };
      let drafts = {};
      if (existsSync6(draftsPath)) {
        try {
          const parsed = JSON.parse(await fs2.readFile(draftsPath, "utf-8"));
          if (typeof parsed.drafts === "object" && parsed.drafts !== null) {
            draftsWrapper = parsed;
            drafts = parsed.drafts;
          } else {
            drafts = parsed;
            draftsWrapper = { drafts: parsed };
          }
        } catch {
          drafts = {};
          draftsWrapper = { drafts: {} };
        }
      }
      if (action === "approve") {
        const draft = drafts[componentName] ?? {};
        const manifestPath = path7.join(activeProjectRoot, BRAND2.manifestFile);
        let manifest = {};
        if (existsSync6(manifestPath)) {
          try {
            manifest = JSON.parse(await fs2.readFile(manifestPath, "utf-8"));
          } catch {
          }
        }
        const components = manifest.components ?? {};
        const existing = components[componentName] ?? {};
        components[componentName] = { ...existing, ...draft, ...editedFields ?? {} };
        manifest.components = components;
        const tmpManifest = manifestPath + ".tmp";
        writeFileSync3(tmpManifest, JSON.stringify(manifest, null, 2) + "\n");
        await fs2.rename(tmpManifest, manifestPath);
      }
      delete drafts[componentName];
      draftsWrapper.drafts = drafts;
      const tmpDrafts = draftsPath + ".tmp";
      writeFileSync3(tmpDrafts, JSON.stringify(draftsWrapper, null, 2) + "\n");
      await fs2.rename(tmpDrafts, draftsPath);
      return { ok: true, remainingDrafts: Object.keys(drafts).length };
    } catch (err) {
      return { ok: false, remainingDrafts: 0, error: err instanceof Error ? err.message : String(err) };
    }
  });
  handlers.set("d2c:apply", async (request) => {
    const EMPTY_TREE = { name: "", path: "", type: "directory", children: [] };
    try {
      if (typeof request !== "object" || request === null || !("pageName" in request) || !("components" in request) || !("page" in request)) {
        return { ok: false, pageFilePath: "", componentFilePaths: [], workspaceTree: EMPTY_TREE, error: "Invalid request" };
      }
      const req = request;
      const home = os.homedir();
      const targetDir = path7.join(activeProjectRoot, "src", "components", "generated", req.pageName);
      await fs2.mkdir(targetDir, { recursive: true });
      const fileBatch = /* @__PURE__ */ new Map();
      const componentFilePaths = [];
      for (const comp of req.components) {
        if (typeof comp.name !== "string" || typeof comp.code !== "string") continue;
        const filePath = path7.join(targetDir, `${comp.name}.tsx`);
        if (!filePath.startsWith(home + path7.sep)) {
          return { ok: false, pageFilePath: "", componentFilePaths: [], workspaceTree: EMPTY_TREE, error: `Path outside home: ${filePath}` };
        }
        fileBatch.set(filePath, comp.code);
        componentFilePaths.push(filePath);
      }
      const pageFilePath = path7.join(targetDir, `${req.page.name}.tsx`);
      let pageCode = req.page.code;
      if (!/export\s+default\b/.test(pageCode)) {
        pageCode = pageCode + `
export default ${req.page.name};
`;
      }
      fileBatch.set(pageFilePath, pageCode);
      for (const [fp, content] of fileBatch) {
        const tmpPath = fp + ".tmp";
        writeFileSync3(tmpPath, content);
        await fs2.rename(tmpPath, fp);
      }
      if (req.themeFile && typeof req.themeFile.filename === "string") {
        const themeFilePath = path7.join(activeProjectRoot, req.themeFile.filename);
        if (themeFilePath.startsWith(home + path7.sep)) {
          const tmpPath = themeFilePath + ".tmp";
          writeFileSync3(tmpPath, req.themeFile.code);
          await fs2.rename(tmpPath, themeFilePath);
        }
      }
      const workspaceTree = await scanDirectory(activeProjectRoot);
      return { ok: true, pageFilePath, componentFilePaths, workspaceTree };
    } catch (err) {
      return { ok: false, pageFilePath: "", componentFilePaths: [], workspaceTree: EMPTY_TREE, error: err instanceof Error ? err.message : String(err) };
    }
  });
  handlers.set("workspace:rescan", async () => {
    if (!activeProjectRoot) return null;
    return scanDirectory(activeProjectRoot);
  });
  handlers.set("preview:start", async (projectRoot2) => {
    if (typeof projectRoot2 !== "string") {
      return { error: "preview:start \u2014 projectRoot must be a string" };
    }
    return previewService.start(projectRoot2);
  });
  handlers.set("preview:stop", async () => {
    await previewService.stop();
  });
  handlers.set("preview:url", async () => {
    return previewService.getUrl();
  });
  let autopilotWatcher = null;
  let autopilotFilePath = null;
  handlers.set("autopilot:enable", async (filePath) => {
    if (typeof filePath !== "string") return;
    autopilotFilePath = filePath;
    if (autopilotWatcher) {
      clearInterval(autopilotWatcher);
      autopilotWatcher = null;
    }
    const runAudit = async () => {
      if (!autopilotFilePath || !mcp.status().connected) return;
      try {
        const result = await mcp.callTool("audit_ui_component", { file: autopilotFilePath });
        const text = result.content?.[0]?.text ?? "{}";
        const parsed = JSON.parse(text);
        broadcast("flint:autopilot-result", {
          filePath: autopilotFilePath,
          governedSource: "",
          fixableCount: parsed.fixableCount ?? 0,
          mithrilCount: parsed.mithrilCount ?? 0,
          a11yCount: parsed.a11yCount ?? 0,
          timestamp: Date.now()
        });
      } catch {
      }
    };
    void runAudit();
    autopilotWatcher = setInterval(() => void runAudit(), 2e3);
  });
  handlers.set("autopilot:disable", async () => {
    if (autopilotWatcher) {
      clearInterval(autopilotWatcher);
      autopilotWatcher = null;
    }
    autopilotFilePath = null;
  });
  handlers.set("dialog:openFolder", async () => null);
  handlers.set("dialog:selectFolder", async () => null);
  handlers.set("import:snap-to-token", async (payload) => {
    if (typeof payload !== "object" || payload === null || typeof payload.nodeId !== "string" || typeof payload.tokenPath !== "string" || typeof payload.className !== "string" || typeof payload.originalClass !== "string") {
      return { ok: false, error: "Invalid payload: missing or wrong-type fields" };
    }
    const contextPath = path7.join(activeProjectRoot, BRAND2.configDir, "context.json");
    let activeFile = null;
    try {
      const raw = await fs2.readFile(contextPath, "utf-8");
      const ctx = JSON.parse(raw);
      if (typeof ctx.activeFile === "string" && ctx.activeFile.length > 0) {
        activeFile = ctx.activeFile;
      }
    } catch {
      return { ok: false, error: "Cannot read context.json \u2014 no active file available" };
    }
    if (!activeFile) {
      return { ok: false, error: "No active file in context.json" };
    }
    if (!isWithinHome(activeFile)) {
      return { ok: false, error: "Active file path is outside home directory" };
    }
    if (!mcp.status().connected) return { ok: false, error: "MCP not connected" };
    try {
      await mcp.callTool("flint_fix", { file: activeFile, dry_run: false });
      return { ok: true };
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) };
    }
  });
  handlers.set("import:undo-all-heals", async () => {
    broadcast("flint:hydro-paste-auto", null);
    return { ok: true };
  });
  handlers.set("flint:hydro-paste", async (payloadStr) => {
    if (!mcp.status().connected) return { error: "MCP not connected" };
    try {
      const result = await mcp.callTool("hydrate_figma_data", { payload: payloadStr });
      const text = result.content?.[0]?.text ?? "{}";
      return JSON.parse(text);
    } catch (err) {
      return { error: err instanceof Error ? err.message : String(err) };
    }
  });
  const { createThumbnailService: createThumbnailService2 } = await Promise.resolve().then(() => (init_thumbnailService(), thumbnailService_exports));
  const thumbnails = createThumbnailService2();
  handlers.set("thumbnails:generate", async (payload) => {
    const p = payload ?? {};
    return thumbnails.generate({ ...p, projectRoot: activeProjectRoot });
  });
  handlers.set("thumbnails:generate-all", async () => {
    return thumbnails.generateAll(activeProjectRoot);
  });
  handlers.set("thumbnails:get", async (componentName) => {
    return thumbnails.get(componentName, activeProjectRoot);
  });
  handlers.set("thumbnails:invalidate", async (componentName) => {
    await thumbnails.invalidate(componentName, activeProjectRoot);
  });
  app.post("/api/ipc", async (req, res) => {
    const { channel, args } = req.body;
    if (typeof channel !== "string") {
      res.json({ result: null, error: "Missing channel" });
      return;
    }
    const handler = handlers.get(channel);
    if (!handler) {
      console.warn(`${BRAND2.logPrefix} Unhandled channel: ${channel}`);
      if (channel.endsWith(":read-all") || channel.endsWith(":list")) {
        res.json({ result: [] });
      } else if (channel.includes("count") || channel.includes("Count")) {
        res.json({ result: 0 });
      } else if (channel.includes("is-") || channel.includes("check")) {
        res.json({ result: false });
      } else if (channel.includes("get") || channel.includes("read") || channel.includes("status")) {
        res.json({ result: null });
      } else {
        res.json({ result: { ok: true } });
      }
      return;
    }
    try {
      const result = await handler(...args || []);
      res.json({ result: result ?? null });
    } catch (e) {
      console.error(`${BRAND2.logPrefix} Handler error [${channel}]:`, e.message);
      res.json({ result: null, error: e.message });
    }
  });
  const distWebPath = path7.resolve(__dirname2, "..", "dist-web");
  if (existsSync6(distWebPath)) {
    app.use(express.static(distWebPath));
    app.get("*path", (req, res) => {
      if (req.path.startsWith("/api/") || req.path.startsWith("/ws")) {
        res.status(404).json({ error: "Not found" });
        return;
      }
      res.sendFile(path7.join(distWebPath, "index.html"));
    });
  }
  return new Promise((resolve) => {
    server.listen(port, () => {
      console.log(`${BRAND2.logPrefix} Flint Glass Web Server running on http://localhost:${port}`);
      console.log(`${BRAND2.logPrefix} Project: ${activeProjectRoot}`);
      console.log(`${BRAND2.logPrefix} WebSocket: ws://localhost:${port}/ws`);
      resolve({
        app,
        server,
        wss,
        close: async () => {
          if (autopilotWatcher) {
            clearInterval(autopilotWatcher);
            autopilotWatcher = null;
          }
          await ingestion.stop().catch(() => {
          });
          await mcp.stop().catch(() => {
          });
          db.close();
          registryDb.close();
          return new Promise((resolveClose) => {
            wss.close(() => {
              server.close(() => resolveClose());
            });
          });
        }
      });
    });
  });
}

// server/cli.ts
function readVersion() {
  try {
    const pkgPath = path8.resolve(path8.dirname(fileURLToPath3(import.meta.url)), "..", "package.json");
    const pkg = JSON.parse(readFileSync5(pkgPath, "utf8"));
    return pkg.version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}
function parseArgs(argv) {
  const result = {
    project: process.cwd(),
    port: 4201,
    open: true,
    // default: auto-open browser
    demo: false,
    help: false,
    version: false
  };
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    switch (arg) {
      case "--project":
      case "-p":
        i++;
        if (i < argv.length) {
          result.project = path8.resolve(argv[i]);
        }
        break;
      case "--port":
        i++;
        if (i < argv.length) {
          const parsed = parseInt(argv[i], 10);
          if (!isNaN(parsed) && parsed > 0 && parsed < 65536) {
            result.port = parsed;
          }
        }
        break;
      case "--open":
      case "-o":
        result.open = true;
        break;
      case "--no-open":
        result.open = false;
        break;
      case "--demo":
      case "-d":
        result.demo = true;
        result.open = true;
        break;
      case "--version":
      case "-v":
        result.version = true;
        break;
      case "--help":
      case "-h":
        result.help = true;
        break;
    }
  }
  return result;
}
function printBanner(projectRoot, port) {
  const lines = [
    "",
    "  \u250C\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510",
    "  \u2502         Flint Glass Web Server           \u2502",
    "  \u2502                                          \u2502",
    `  \u2502  Local:   http://localhost:${String(port).padEnd(14)}\u2502`,
    `  \u2502  WS:      ws://localhost:${String(port).padEnd(13)}/ws \u2502`,
    "  \u2502                                          \u2502",
    `  \u2502  Project: ${projectRoot.length > 28 ? "..." + projectRoot.slice(-25) : projectRoot.padEnd(28)}\u2502`,
    "  \u2502                                          \u2502",
    "  \u2502  Press Ctrl+C to stop                    \u2502",
    "  \u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518",
    ""
  ];
  console.log(lines.join("\n"));
}
function printHelp() {
  console.log(`
Flint Glass Web Server

Runs the Flint Glass observability layer in any browser,
replacing the Electron main process with an Express server.

Usage:
  flint-glass [options]
  npx flint-glass [options]

Options:
  --project, -p <path>   Project directory to open (default: cwd)
  --port <number>        Server port (default: 4201)
  --open, -o             Open browser automatically (default: true)
  --no-open              Suppress automatic browser launch
  --demo, -d             Load demo project (skips --project requirement)
  --version, -v          Print version and exit
  --help, -h             Show this help message

Examples:
  npx flint-glass --demo
  npx flint-glass --project ~/my-app
  npx flint-glass --project ./my-project --port 3000 --no-open
`);
}
async function openBrowser(url) {
  const { exec } = await import("node:child_process");
  const platform = process.platform;
  let cmd;
  if (platform === "darwin") {
    cmd = `open "${url}"`;
  } else if (platform === "win32") {
    cmd = `start "${url}"`;
  } else {
    cmd = `xdg-open "${url}"`;
  }
  exec(cmd, (err) => {
    if (err) {
      console.warn(`[Flint] Could not open browser automatically: ${err.message}`);
      console.warn(`[Flint] Open ${url} in your browser manually.`);
    }
  });
}
async function main() {
  const args = parseArgs(process.argv);
  if (args.version) {
    console.log(readVersion());
    process.exit(0);
  }
  if (args.help) {
    printHelp();
    process.exit(0);
  }
  if (!args.demo && !existsSync7(args.project)) {
    console.error(`[Flint] Error: Project directory does not exist: ${args.project}`);
    console.error(`[Flint] Tip: run with --demo to open the built-in demo project`);
    process.exit(1);
  }
  try {
    const instance = await startServer({
      projectRoot: args.demo ? process.cwd() : args.project,
      port: args.port
    });
    printBanner(args.demo ? "(demo)" : args.project, args.port);
    const browserUrl = args.demo ? `http://localhost:${args.port}/?demo=1` : `http://localhost:${args.port}`;
    if (args.open) {
      await openBrowser(browserUrl);
    }
    const shutdown = async () => {
      console.log("\n[Flint] Shutting down...");
      await instance.close();
      console.log("[Flint] Server stopped.");
      process.exit(0);
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  } catch (err) {
    console.error("[Flint] Failed to start server:", err);
    process.exit(1);
  }
}
main();
